// ================= MODAL HORÁRIOS =================
function abrirModalHorarios() {
    document.getElementById('modalHorarios').style.display = 'flex';
    document.getElementById('resultadoHorarios').innerHTML = '';
    document.body.style.overflow = 'hidden';
}

function fecharModalHorarios() {
    document.getElementById('modalHorarios').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// ================= MODAL SALAS =================
function abrirModalSalas(tipo) {
    document.getElementById('modalSalas').style.display = 'flex';
    const titulo = document.getElementById('tituloSalas');
    const icon = titulo.querySelector('i');
    
    if (tipo === 'livres') {
        titulo.innerHTML = '<i class="fas fa-door-open"></i> Salas Livres Agora';
        icon.className = 'fas fa-door-open';
    } else {
        titulo.innerHTML = '<i class="fas fa-door-closed"></i> Salas Ocupadas Agora';
        icon.className = 'fas fa-door-closed';
    }
    
    document.body.style.overflow = 'hidden';

    fetch('salas_status.php?tipo=' + tipo)
        .then(res => res.text())
        .then(html => {
            document.getElementById('resultadoSalas').innerHTML = html;
        });
}

function fecharModalSalas() {
    document.getElementById('modalSalas').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// ================= MODAL FILTRO =================
function mostrarFiltros() {
    document.getElementById('filtros').style.display = 'grid';
    document.getElementById('resultadoHorarios').innerHTML = '';
}

function buscarHorarios() {
    const tipo = document.getElementById('tipoHorario').value;
    const curso = document.getElementById('curso').value;
    const ano = document.getElementById('ano').value;
    const semestre = document.getElementById('semestre').value;
    const turno = document.getElementById('turno').value;

    const params = new URLSearchParams({
        tipo, curso, ano, semestre, turno
    });

    fetch('listar_horario_visual.php?' + params.toString())
        .then(res => res.text())
        .then(html => {
            document.getElementById('resultadoHorarios').innerHTML = html;
        });
}

// ================= MODAL CALENDÁRIO =================
function abrirModalCalendario() {
    document.getElementById('modalCalendario').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function fecharModalCalendario() {
    document.getElementById('modalCalendario').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Fechar modais ao clicar fora
window.onclick = function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target == modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });
}