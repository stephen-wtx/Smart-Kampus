// =========================================================
// FUNÇÕES PARA MODAIS
// =========================================================

function abrirModal(id) {
    document.getElementById(id).style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function fecharModal(id) {
    document.getElementById(id).style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Fechar modal ao clicar fora
window.onclick = function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target == modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });
}

function abrirModalCancelar(id) {
    document.getElementById('reservaIdCancelar').value = id;
    abrirModal('modalCancelar');
}
