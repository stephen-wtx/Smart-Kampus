<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

require_once __DIR__ . '/../config/google.php';
require_once __DIR__ . '/../config/database.php';

// 1. Verifica se o código OAuth chegou
if (!isset($_GET['code'])) {
    exit('Código OAuth não recebido');
}

// 2. Troca o code pelo token
$token = $client->fetchAccessTokenWithAuthCode($_GET['code']);

if (isset($token['error'])) {
    exit('Erro OAuth: ' . $token['error']);
}

$client->setAccessToken($token);

// 3. Obtem informações do utilizador
$oauth = new Google_Service_Oauth2($client);
$userInfo = $oauth->userinfo->get();

$email = $userInfo->email;

// 4. Valida domínio institucional
if (!preg_match('/@ucm\.ac\.mz$/', $email)) {
    // Página estilizada para email não institucional COM MESMO DESIGN DO LOGIN
    ?>
    <!DOCTYPE html>
    <html lang="pt" class="scroll-smooth">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Acesso Negado - SMART KAMPUS</title>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        
        <!-- Google Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

        <link rel="icon" type="image/x-icon" href="assets/imgs/smartkampus-logo.png">
        <link rel="stylesheet" href="assets/css/callback.css">
    </head>
    <body>
        <!-- Background igual ao login -->
        <div class="bg-overlay"></div>
        <div class="bg-blur"></div>

        <!-- Container principal -->
        <div class="min-h-screen">
            <div class="access-card">
                <!-- Logo -->
                <div class="logo-container">
                    <img src="assets/imgs/smartkampus-logo.png" 
                         alt="SMART KAMPUS Logo" 
                         class="logo-img">
                    <div class="logo-text">SMART KAMPUS</div>
                </div>

                <!-- Ícone de alerta -->
                <div class="icon-alert">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>

                <!-- Títulos -->
                <h1 class="title">Acesso Restrito</h1>
                <p class="subtitle">
                    O SMART KAMPUS é exclusivo para membros da
                    <strong>Universidade Católica de Moçambique</strong>.
                </p>

                <!-- Email detectado -->
                <div class="email-display">
                    <span class="email-label">Email detectado:</span>
                    <span class="email-value"><?php echo htmlspecialchars($email); ?></span>
                </div>

                <!-- Domínio requerido -->
                <div class="domain-box">
                    <div class="domain-title">
                        <i class="fas fa-university"></i>
                        Domínio autorizado
                    </div>
                    <ul class="domain-list">
                        <li><i class="fas fa-check-circle"></i> @ucm.ac.mz</li>
                        <li><i class="fas fa-info-circle"></i> Apenas para comunidade académica UCM</li>
                    </ul>
                </div>

                <!-- Botão voltar -->
                <div class="btn-container">
                    <a href="index.php" class="btn btn-primary">
                        <i class="fas fa-arrow-left"></i>
                        Voltar ao Login
                    </a>
                </div>
            </div>
        </div>

    </body>
    </html>
    <?php
    session_destroy();
    exit();
}

// ... (resto do código permanece igual)
// 5. Procura utilizador na BD
$stmt = $conn->prepare("SELECT id, role FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // Primeiro login → auto-registo
    $role = 'estudante';

    $stmt = $conn->prepare("
        INSERT INTO users (oauth_provider, oauth_uid, name, email, role, picture)
        VALUES ('google', ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param(
        "sssss",
        $userInfo->id,
        $userInfo->name,
        $email,
        $role,
        $userInfo->picture
    );
    $stmt->execute();
    $userId = $stmt->insert_id;
} else {
    // Utilizador existente
    $user = $result->fetch_assoc();
    $userId = $user['id'];
    $role   = $user['role'];

    // Atualiza last_login
    $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
}

// 6. Cria sessão segura
session_regenerate_id(true);

$_SESSION['user'] = [
    'id'    => $userId,
    'name'  => $userInfo->name,
    'email' => $email,
    'role'  => $role,
    'picture' => $userInfo->picture
];

// 7. Redireciona para dashboard principal (todos acessam)
header('Location: dashboard/dashboard.php');
exit;
