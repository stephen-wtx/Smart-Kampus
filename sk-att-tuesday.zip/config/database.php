<?php

$conn = new mysqli(
    'sql101.infinityfree.com',      // MySQL Host
    'if0_41176359',           // Usuário do banco
    'aCxGB1AfrakuNv9',         // Senha do banco
    'if0_41176359_smartkampus' // Nome completo do banco
);

if ($conn->connect_error) {
    die('Erro de conexão: ' . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

?>
