<?php
session_start();
require_once __DIR__ . '/../config/database.php';
if (!isset($_SESSION['user'])) {
    header('Location: /public/index.php');
    exit;
}
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Principal - SMARTKAMPUS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="/public/assets/imgs/smartkampus-logo.png">
    <link rel="stylesheet" href="/public/assets/css/dashboard.css">
    <script src="/public/assets/js/dashboard.js"></script>
</head>
<body>
    <!-- Header (Inalterado conforme solicitado) -->
    <header class="header">
        <div class="header-content">
            <div class="logo-container">
                <img src="/public/assets/imgs/smartkampus-logo.png" alt="Logo" class="logo-img">
                <span class="logo-text">SMARTKAMPUS</span>
            </div>
            <div class="nav-links">
                <i class="fas fa-home"></i>
                <span>Painel principal</span>
                <a href="/public/logout.php" class="nav-button logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Sair</span>
                </a>
            </div>
        </div>
    </header>

    <!-- Conteúdo principal -->
    <main class="container">
        <!-- Welcome card -->
        <div class="welcome-card">
            <?php if (!empty($user['picture'])): ?>
                <div class="user-avatar">
                    <img src="<?= htmlspecialchars($user['picture']) ?>" alt="Foto do usuário">
                </div>
            <?php else: ?>
                <div class="avatar-placeholder">
                    <i class="fas fa-user"></i>
                </div>
            <?php endif; ?>
            <div class="welcome-text">
                <h1>Bem-vindo, <?= htmlspecialchars($user['name']); ?>!</h1>
                <div class="user-email">
                    <i class="fas fa-envelope"></i>
                    <?= htmlspecialchars($user['email']); ?>
                </div>
                <p>Acesse informações acadêmicas e gerencie sua experiência no campus.</p>
            </div>
        </div>

        <!-- Dashboard Grid -->
        <div class="dashboard-grid">
            <!-- Horários -->
            <div class="dashboard-card horarios" onclick="abrirModalHorarios()">
                <div class="card-header">
                    <div class="card-icon horarios">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Ver Horários</h3>
                        <div class="card-stats">
                            <i class="fas fa-search"></i>
                            <span>Consultar horários de aulas, testes e exames</span>
                        </div>
                    </div>
                </div>
                <p class="card-description">
                    Consulte os horários acadêmicos filtrados por curso, ano, semestre e turno.
                </p>
            </div>

            <!-- Salas Livres -->
            <div class="dashboard-card salas-livres" onclick="abrirModalSalas('livres')">
                <div class="card-header">
                    <div class="card-icon salas-livres">
                        <i class="fas fa-door-open"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Salas Livres</h3>
                        <div class="card-stats">
                            <i class="fas fa-check-circle"></i>
                            <span>Disponíveis para uso imediato</span>
                        </div>
                    </div>
                </div>
                <p class="card-description">
                    Visualize quais salas estão disponíveis no momento atual para reservas.
                </p>
            </div>

            <!-- Salas Ocupadas -->
            <div class="dashboard-card salas-ocupadas" onclick="abrirModalSalas('ocupadas')">
                <div class="card-header">
                    <div class="card-icon salas-ocupadas">
                        <i class="fas fa-door-closed"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Salas Ocupadas</h3>
                        <div class="card-stats">
                            <i class="fas fa-exclamation-circle"></i>
                            <span>Em uso no momento</span>
                        </div>
                    </div>
                </div>
                <p class="card-description">
                    Consulte as salas que estão atualmente em uso ou reservadas.
                </p>
            </div>

            <!-- Calendário Académico -->
            <div class="dashboard-card calendario" onclick="abrirModalCalendario()">
                <div class="card-header">
                    <div class="card-icon calendario">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Calendário Académico</h3>
                        <div class="card-stats">
                            <i class="fas fa-calendar-check"></i>
                            <span>Datas importantes do semestre</span>
                        </div>
                    </div>
                </div>
                <p class="card-description">
                    Acesse o calendário oficial com todas as datas acadêmicas importantes.
                </p>
            </div>
        </div>
    </main>

    <!-- ================= MODAL SALAS ================= -->
    <div id="modalSalas" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="tituloSalas">
                    <i class="fas fa-door-open"></i>
                    Salas
                </h2>
                <button class="close-modal" onclick="fecharModalSalas()" aria-label="Fechar modal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div id="resultadoSalas" class="table-container"></div>
            <div style="margin-top: 1.5rem; display: flex; justify-content: flex-end;">
                <button onclick="fecharModalSalas()" class="btn btn-secondary">
                    <i class="fas fa-times"></i>
                    Fechar
                </button>
            </div>
        </div>
    </div>

    <!-- ================= MODAL HORÁRIOS ================= -->
    <div id="modalHorarios" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">
                    <i class="fas fa-clock"></i>
                    Consultar Horários
                </h2>
                <button class="close-modal" onclick="fecharModalHorarios()" aria-label="Fechar modal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="filters-container">
                <div class="filters-grid">
                    <div class="form-group">
                        <label class="form-label">Tipo de Horário</label>
                        <select id="tipoHorario" class="form-select" onchange="mostrarFiltros()">
                            <option value="">-- Selecione o tipo --</option>
                            <option value="aula">Aulas</option>
                            <option value="teste">Testes</option>
                            <option value="exame">Exames</option>
                        </select>
                    </div>
                    <div id="filtros" style="display:none; grid-column: 1 / -1;">
                        <div class="filters-grid">
                            <div class="form-group">
                                <label class="form-label">Curso</label>
                                <select id="curso" class="form-select">
                                    <option value="">Todos os cursos</option>
                                    <option>Administração Pública</option>
                                    <option>Contabilidade & Auditoria</option>
                                    <option>Direito</option>
                                    <option>Economia e Gestão</option>
                                    <option>Gestão de Recursos Humanos</option>
                                    <option>Meio Ambiente</option>
                                    <option>Tecnologia de Informação</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Ano</label>
                                <select id="ano" class="form-select">
                                    <option value="">Todos os anos</option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Semestre</label>
                                <select id="semestre" class="form-select">
                                    <option value="">Ambos semestres</option>
                                    <option>I</option>
                                    <option>II</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Turno</label>
                                <select id="turno" class="form-select">
                                    <option value="">Todos os turnos</option>
                                    <option>Diurno</option>
                                    <option>Noturno</option>
                                </select>
                            </div>
                            <div class="form-group" style="display: flex; align-items: flex-end;">
                                <button onclick="buscarHorarios()" class="btn btn-primary" style="width: 100%;">
                                    <i class="fas fa-search"></i>
                                    Buscar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="resultadoHorarios" class="table-container"></div>
        </div>
    </div>

    <!-- ================= MODAL CALENDÁRIO ACADÉMICO ================= -->
    <div id="modalCalendario" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">
                    <i class="fas fa-calendar-alt"></i>
                    Calendário Académico
                </h2>
                <button class="close-modal" onclick="fecharModalCalendario()" aria-label="Fechar modal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <?php
            // Seleciona o último calendário publicado
            $cal = $conn->query("
                SELECT * FROM calendario_academico
                ORDER BY data_publicacao DESC
                LIMIT 1
            ");
            ?>
            <?php if ($cal && $cal->num_rows > 0):
                $c = $cal->fetch_assoc();
            ?>
                <div class="calendar-info">
                    <div>
                        <h3>Calendário Académico Atual</h3>
                        <p>
                            <i class="fas fa-calendar-check"></i>
                            Publicado em: <?= date('d/m/Y H:i', strtotime($c['data_publicacao'])) ?>
                        </p>
                    </div>
                </div>
                <div class="calendar-preview">
                    <iframe class="calendar-iframe" src="/public/uploads/calendario/<?= $c['caminho'] ?>" title="Calendário Académico"></iframe>
                </div>
                <div class="calendar-mobile-link">
                    <a href="/public/uploads/calendario/<?= $c['caminho'] ?>" target="_blank" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-external-link-alt"></i>
                        Abrir Calendário em Nova Aba
                    </a>
                </div>
                <div style="margin-top: 1.5rem; display: flex; gap: 1rem; flex-wrap: wrap;">
                    <a href="/public/uploads/calendario/<?= $c['caminho'] ?>" download class="btn btn-primary">
                        <i class="fas fa-download"></i>
                        Baixar Calendário
                    </a>
                    <button onclick="fecharModalCalendario()" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        Fechar
                    </button>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="far fa-calendar-times"></i>
                    </div>
                    <h3>Nenhum calendário disponível</h3>
                    <p>Não existe nenhum calendário académico publicado ainda.</p>
                    <button onclick="fecharModalCalendario()" class="btn btn-secondary" style="margin-top: 1rem;">
                        <i class="fas fa-times"></i>
                        Fechar
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Footer (Inalterado conforme solicitado) -->
    <footer class="footer">
        <p>© 2026 <span class="footer-logo">SMARTKAMPUS</span> • Universidade Católica de Moçambique</p>
    </footer>
</body>
</html>