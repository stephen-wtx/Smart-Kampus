<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../libs/fpdf/fpdf.php';

// =========================
// RECEBER FILTROS
// =========================
$tipo     = $_GET['tipo'] ?? 'aula';
$curso    = $_GET['curso'] ?? '';
$ano      = $_GET['ano'] ?? '';
$semestre = $_GET['semestre'] ?? '';
$turno    = $_GET['turno'] ?? '';

// =========================
// MONTAR FILTROS
// =========================
$filtros = [];
if ($curso !== '')    $filtros[] = "curso = '" . $conn->real_escape_string($curso) . "'";
if ($ano !== '')      $filtros[] = "ano = " . (int)$ano;
if ($semestre !== '') $filtros[] = "semestre = '" . $conn->real_escape_string($semestre) . "'";
if ($turno !== '')    $filtros[] = "turno = '" . $conn->real_escape_string($turno) . "'";
$where = $filtros ? 'WHERE ' . implode(' AND ', $filtros) : '';

// =========================
// DEFINIR TABELA E COLUNAS
// =========================
if ($tipo === 'teste') {
    $tabela = 'testes';
    $colunas = ['Curso', 'Disciplina', 'Ano', 'Semestre', 'Turno', 'Sala', 'Docente', 'Dia', 'Data', 'Hora', 'Duração'];
} elseif ($tipo === 'exame') {
    $tabela = 'exames';
    $colunas = ['Curso', 'Disciplina', 'Ano', 'Semestre', 'Turno', 'Sala', 'Docente', 'Dia', 'Data', 'Hora', 'Duração'];
} else {
    $tabela = 'horarios';
    $colunas = ['Dia', 'Curso', 'Ano', 'Semestre', 'Disciplina', 'Turno', 'Sala', 'Docente', 'Horário'];
}

// =========================
// QUERY COM ORDER BY ADEQUADO
// =========================
if ($tabela === 'horarios') {
    $sql = "
    SELECT
    dia_semana,
    curso,
    ano,
    semestre,
    disciplina,
    turno,
    sala,
    docente_nome,
    hora_inicio,
    hora_fim
    FROM $tabela
    $where
    ORDER BY FIELD(dia_semana,'Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado'),
    hora_inicio,
    curso,
    ano
    ";
} else {
    $sql = "
    SELECT
    curso,
    disciplina,
    ano,
    semestre,
    turno,
    sala,
    docente_nome,
    dia_semana,
    data,
    hora_inicio,
    hora_fim
    FROM $tabela
    $where
    ORDER BY data, hora_inicio
    ";
}

$result = $conn->query($sql);
if (!$result || $result->num_rows === 0) {
    die('Sem dados para gerar o PDF.');
}

// =========================
// CRIAR PDF COM LAYOUT PROFISSIONAL
// =========================
$pdf = new FPDF('L', 'mm', 'A4'); // Landscape
$pdf->AddPage();
$pdf->SetMargins(10, 15, 10);

// NOTA SOBRE TIPOGRAFIA:
// Para usar Bebas Neue e Inter, gere os arquivos .php/.z com a ferramenta 'makefont' do FPDF 
// e descomente as linhas abaixo. O código usa 'helvetica' como fallback elegante e seguro.
// $pdf->AddFont('BebasNeue', '', 'bebasneue.php');
// $pdf->AddFont('Inter', '', 'inter.php');
// $pdf->AddFont('Inter', 'B', 'inter-bold.php');

$fonteTitulo = 'helvetica'; // Alterar para 'BebasNeue' se a fonte for adicionada
$fonteCorpo  = 'helvetica'; // Alterar para 'Inter' se a fonte for adicionada

// CORES (Paleta Moderna e Profissional)
$azulEscuro = [30, 58, 138];   // #1E3A8A (Primário institucional)
$cinzaClaro = [248, 250, 252]; // #F8FAFC (Fundo alternado de linhas)
$cinzaTexto = [100, 116, 139]; // #64748B (Texto secundário/filtros)
$preto      = [15, 23, 42];    // #0F172A (Texto principal)
$branco     = [255, 255, 255];
$borda      = [226, 232, 240]; // #E2E8F0 (Linhas sutis da tabela)

// =========================
// CABEÇALHO DO PDF
// =========================
$pdf->SetTextColor($azulEscuro[0], $azulEscuro[1], $azulEscuro[2]);
$pdf->SetFont($fonteTitulo, 'B', 28);
$pdf->Cell(0, 12, utf8_decode('SMARTKAMPUS'), 0, 1, 'C');

$pdf->SetFont($fonteCorpo, 'B', 14);
$pdf->SetTextColor($preto[0], $preto[1], $preto[2]);
$pdf->Cell(0, 8, utf8_decode('HORÁRIO ACADÊMICO - ' . strtoupper($tipo)), 0, 1, 'C');

$pdf->Ln(3);

// Bloco de Filtros (Design em caixa sutil)
$pdf->SetFillColor($cinzaClaro[0], $cinzaClaro[1], $cinzaClaro[2]);
$pdf->SetDrawColor($borda[0], $borda[1], $borda[2]);
$pdf->SetTextColor($cinzaTexto[0], $cinzaTexto[1], $cinzaTexto[2]);
$pdf->SetFont($fonteCorpo, '', 9);

$filtrosTexto = 'Curso: ' . ($curso ?: 'Todos') . '   |   ';
$filtrosTexto .= 'Ano: ' . ($ano ?: 'Todos') . '   |   ';
$filtrosTexto .= 'Semestre: ' . ($semestre ?: 'Ambos') . '   |   ';
$filtrosTexto .= 'Turno: ' . ($turno ?: 'Todos') . '   |   ';
$filtrosTexto .= 'Gerado em: ' . date('d/m/Y H:i');

$pdf->Cell(0, 10, utf8_decode($filtrosTexto), 1, 1, 'C', true);
$pdf->Ln(4);

// =========================
// DEFINIÇÃO DAS COLUNAS (LARGURAS E ALINHAMENTOS)
// Corrigido para corresponder exatamente ao número de colunas em $colunas
// Total de larguras = 277mm (Largura A4 Paisagem 297mm - 20mm de margens)
// =========================
if ($tipo === 'teste' || $tipo === 'exame') {
    // 11 colunas
    $widths = [30, 45, 15, 18, 18, 18, 35, 25, 25, 25, 23]; 
    $aligns = ['L', 'L', 'C', 'C', 'C', 'C', 'L', 'C', 'C', 'C', 'C'];
} else {
    // 9 colunas
    $widths = [25, 45, 15, 20, 60, 20, 20, 50, 22]; 
    $aligns = ['C', 'L', 'C', 'C', 'L', 'C', 'C', 'L', 'C'];
}

// =========================
// CABEÇALHO DA TABELA
// =========================
$pdf->SetFillColor($azulEscuro[0], $azulEscuro[1], $azulEscuro[2]);
$pdf->SetTextColor($branco[0], $branco[1], $branco[2]);
$pdf->SetFont($fonteCorpo, 'B', 9);
$pdf->SetDrawColor($borda[0], $borda[1], $borda[2]);

foreach ($colunas as $i => $coluna) {
    $pdf->Cell($widths[$i], 9, utf8_decode($coluna), 1, 0, 'C', true);
}
$pdf->Ln();

// =========================
// DADOS DA TABELA
// =========================
$pdf->SetFont($fonteCorpo, '', 8);
$pdf->SetTextColor($preto[0], $preto[1], $preto[2]);
$fill = false;
$rowHeight = 7; // Altura base elegante

while ($row = $result->fetch_assoc()) {
    // Alternar cor de fundo
    if ($fill) {
        $pdf->SetFillColor(241, 245, 249);
    } else {
        $pdf->SetFillColor(255, 255, 255);
    }
    
    $rowData = [];
    
    foreach ($colunas as $coluna) {
        switch ($coluna) {
            case 'Dia':
                $text = $row['dia_semana'] ?? '-';
                break;
            case 'Curso':
                $text = $row['curso'];
                break;
            case 'Ano':
                // CORREÇÃO: Remove caracteres não numéricos e adiciona apenas um 'º'
                $anoLimpo = preg_replace('/[^0-9]/', '', $row['ano']);
                $text = $anoLimpo . 'º';
                break;
            case 'Semestre':
                $text = $row['semestre'];
                break;
            case 'Disciplina':
                $text = $row['disciplina'];
                break;
            case 'Turno':
                $text = $row['turno'];
                break;
            case 'Sala':
                $text = $row['sala'];
                break;
            case 'Docente':
                $text = $row['docente_nome'] ?? '-';
                break;
            case 'Horário':
            case 'Hora':
                $horaInicio = substr($row['hora_inicio'], 0, 5);
                $horaFim = substr($row['hora_fim'], 0, 5);
                $text = $horaInicio . ' - ' . $horaFim;
                break;
            case 'Data':
                $text = isset($row['data']) ? date('d/m/Y', strtotime($row['data'])) : '-';
                break;
            default:
                $text = '-';
        }
        $rowData[] = utf8_decode($text);
    }
    
    // Verificar se a linha não vai ultrapassar a página
    if ($pdf->GetY() > 250) {
        $pdf->AddPage();
        // Reimprimir cabeçalho na nova página
        $pdf->SetFont('Arial', 'B', 9);
        $pdf->SetFillColor(248, 250, 252);
        $pdf->SetTextColor(71, 85, 105);
        foreach ($colunas as $i => $coluna) {
            $pdf->Cell($widths[$i], 10, utf8_decode($coluna), 1, 0, 'C', true);
        }
        $pdf->Ln();
        $pdf->SetFont('Arial', '', 8);
        $pdf->SetTextColor(15, 23, 42);
    }
    
    // Imprimir linha
    for ($i = 0; $i < count($rowData); $i++) {
        $pdf->Cell($widths[$i], 8, $rowData[$i], 1, 0, $aligns[$i], true);
    }
    $pdf->Ln();
    $fill = !$fill;
}
// =========================
// RODAPÉ
// =========================
$pdf->Ln(4);
$pdf->SetDrawColor($borda[0], $borda[1], $borda[2]);
// Linha separadora elegante (da margem esquerda 10 até a direita 287)
$pdf->Line(10, $pdf->GetY(), 287, $pdf->GetY()); 
$pdf->Ln(4);

$pdf->SetFont($fonteCorpo, 'I', 8);
$pdf->SetTextColor($cinzaTexto[0], $cinzaTexto[1], $cinzaTexto[2]);
$pdf->Cell(0, 5, utf8_decode('Documento gerado automaticamente pelo sistema SMARTKAMPUS - Universidade Católica de Moçambique'), 0, 1, 'C');
$pdf->Cell(0, 5, utf8_decode('© ' . date('Y') . ' - Todos os direitos reservados'), 0, 1, 'C');

// =========================
// OUTPUT
// =========================
$pdf->Output('I', 'horario_' . $tipo . '_' . date('Y-m-d') . '.pdf');