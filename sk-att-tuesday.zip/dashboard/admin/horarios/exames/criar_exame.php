<?php
session_start();
require_once __DIR__ . "/../../../../config/database.php";
if (!isset($_SESSION['user'])) {
    header('Location: ../../../../public/index.php');
    exit;
}
$user = $_SESSION['user'];
if (!isset($user['role']) || $user['role'] !== 'admin') {
    // Se não for admin, redireciona para o dashboard normal
    header('Location: ../../../dashboard.php');
    exit;
}

$diasSemana = ['Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
$cursos = ['Administração Pública', 'Contabilidade & Auditoria', 'Direito', 'Economia e Gestão', 'Gestão de Recursos Humanos', 'Meio Ambiente', 'Tecnologia de Informação'];
$anos = ['1º', '2º', '3º', '4º'];
$semestres = ['I', 'II'];
$turnos = ['Manhã', 'Tarde', 'Noite'];
$salas = ['Nelson Mandela 1', 'Nelson Mandela 2', 'Nkwame Nkrumah', 'Martin Luther King', 'Santo Agostinho', 'Dom Jaime Gonsalves', 'Josefina Bakhita 1', 'Josefina Bakhita 2', 'Blase Pascal', 'Sala de Informática', 'Laboratório de SIG', 'Cipriano Parite 1', 'Cipriano Parite 2', 'Laboratório de Línguas', 'São Tomás de Aquino', 'Roberto Busa', 'Rosário Policarpo Nápica', 'Beato Newman', 'Francisco de Assis', 'São Francisco de Vitória', 'Max Planck'];
?>
<!DOCTYPE html>
<html lang="pt-pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Criar Exame - SMART KAMPUS</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="icon" type="image/x-icon" href="../../../../public/assets/imgs/smartkampus-logo.png">
<style>
/* Importação das Fontes (Padronizado) */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap');

:root {
    /* PALETA ROXA (Identidade do Módulo de Exames) */
    --primary: #8b5cf6;
    --primary-hover: #7c3aed;
    --primary-soft: #ede9fe;
    --primary-glow: rgba(139, 92, 246, 0.15);
    --logo-color: #3b43ce;
    --bg: #f8fafc;
    --bg-card: #ffffff;
    --text-main: #334155;
    --text-dark: #0f172a;
    --text-muted: #64748b;
    --border: #e2e8f0;
    --border-light: #f1f5f9;
    --success: #10b981;
    --error: #ef4444;
    --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.06);
}

* { margin: 0; padding: 0; box-sizing: border-box; }

body { 
    background-color: var(--bg); 
    color: var(--text-main); 
    line-height: 1.6; 
    min-height: 100vh; 
    display: flex;
    flex-direction: column;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

/* =========================================================
   HEADER PADRONIZADO
   ========================================================= */
.header {
    background: var(--bg-card);
    padding: 0 2rem;
    box-shadow: var(--shadow-sm);
    position: sticky;
    top: 0;
    z-index: 100;
    border-bottom: none;
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    max-width: 1200px;
    margin: 0 auto;
    height: 80px;
}

.logo-container {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.logo-img {
    height: 40px;
    width: auto;
    transition: transform 0.2s ease;
}

.logo-img:hover {
    transform: scale(1.05);
}

.logo-text {
    font-family: 'Bebas Neue', sans-serif;
    font-size: 1.75rem;
    font-weight: 400;
    color: var(--logo-color);
    letter-spacing: 0.5px;
    line-height: 1;
}

.nav-links {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.nav-button {
    display: flex;
    align-items: center;
    gap: 8px;
    background: transparent;
    border: none;
    color: var(--text-muted);
    font-size: 0.9rem;
    font-weight: 500;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
    text-decoration: none;
}

.nav-button:hover {
    background-color: #f1f5f9;
    color: var(--primary-hover);
}

.nav-button.logout {
    color: #ef4444;
}

.nav-button.logout:hover {
    background-color: #fee2e2;
}

/* =========================================
   CONTEÚDO E FORMULÁRIO (Mantidos originais)
   ========================================= */
.container { max-width: 1400px; margin: 2rem auto; padding: 0 2rem; width: 100%; flex: 1; }
.breadcrumb { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1.5rem; font-size: 0.85rem; color: var(--text-muted); }
.breadcrumb a { color: var(--primary); text-decoration: none; font-weight: 500; transition: color 0.2s; }
.breadcrumb a:hover { color: var(--primary-hover); }
.breadcrumb .separator { color: #cbd5e1; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem; }
.page-title { font-size: 1.75rem; font-weight: 700; color: var(--text-dark); display: flex; align-items: center; gap: 0.75rem; }
.page-title i { color: var(--primary); }

.toast-container { position: fixed; top: 85px; right: 2rem; z-index: 9999; display: flex; flex-direction: column; gap: 1rem; pointer-events: none; }
.toast { background: white; padding: 1.25rem 1.5rem; border-radius: 12px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.1); display: flex; align-items: center; gap: 1rem; min-width: 320px; max-width: 420px; animation: toastIn 0.4s cubic-bezier(0.16, 1, 0.3, 1); border-left: 4px solid; pointer-events: auto; }
.toast-success { border-left-color: var(--success); }
.toast-error { border-left-color: var(--error); }
.toast-icon { font-size: 1.5rem; }
.toast-success .toast-icon { color: var(--success); }
.toast-error .toast-icon { color: var(--error); }
.toast-content { flex: 1; }
.toast-title { font-weight: 600; color: var(--text-dark); font-size: 0.95rem; }
.toast-message { font-size: 0.875rem; color: var(--text-muted); margin-top: 2px; }
.toast-close { background: none; border: none; color: #94a3b8; cursor: pointer; font-size: 1.5rem; line-height: 1; padding: 0; transition: color 0.2s; }
.toast-close:hover { color: var(--text-main); }
@keyframes toastIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
@keyframes toastOut { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } }

.form-card { background: white; border-radius: 16px; padding: 2.5rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05), 0 2px 4px -1px rgba(0,0,0,0.03); border: 1px solid var(--border); margin-bottom: 2rem; }
.form-title { font-size: 1.25rem; font-weight: 600; color: var(--text-dark); margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 1px solid var(--border-light); display: flex; align-items: center; gap: 0.75rem; }
.form-title i { color: var(--primary); }
.form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; }
.form-group { display: flex; flex-direction: column; gap: 0.5rem; }
.form-group label { font-size: 0.875rem; font-weight: 600; color: var(--text-main); }
.form-group label .required { color: var(--error); margin-left: 2px; }
.form-control { width: 100%; padding: 0.85rem 1rem; border: 1px solid var(--border); border-radius: 10px; font-size: 0.95rem; color: var(--text-main); background: white; transition: all 0.2s ease; appearance: none; -webkit-appearance: none; }
select.form-control { background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e"); background-repeat: no-repeat; background-position: right 1rem center; background-size: 16px 12px; padding-right: 2.5rem; }
.form-control:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 4px var(--primary-glow); }
.form-control:hover { border-color: #cbd5e1; }
.form-control.error { border-color: var(--error); background-color: #fef2f2; }
.error-message { color: var(--error); font-size: 0.75rem; margin-top: 0.25rem; display: none; align-items: center; gap: 0.25rem; }
.error-message i { font-size: 0.7rem; }
.error-message.show { display: flex; }
.form-actions { display: flex; gap: 1rem; margin-top: 2.5rem; flex-wrap: wrap; }
.btn { display: inline-flex; align-items: center; justify-content: center; gap: 0.5rem; padding: 0.85rem 1.75rem; border-radius: 10px; font-weight: 600; font-size: 0.9rem; cursor: pointer; transition: all 0.2s ease; border: 1px solid transparent; text-decoration: none; white-space: nowrap; }
.btn-primary { background: var(--primary); color: white; }
.btn-primary:hover { background: var(--primary-hover); transform: translateY(-2px); box-shadow: 0 4px 12px rgba(139, 92, 246, 0.25); }
.btn-secondary { background: white; color: var(--text-main); border-color: var(--border); }
.btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
.btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }

/* =========================================================
   FOOTER PADRONIZADO
   ========================================================= */
.footer {
    background: #0f172a;
    color: #cbd5e1;
    text-align: center;
    padding: 1.5rem;
    margin-top: auto;
    font-size: 0.875rem;
}

.footer-logo {
    font-family: 'Bebas Neue', sans-serif;
    font-size: 1.2rem;
    letter-spacing: 0.5px;
    color: #ffffff;
}

/* =========================================================
   RESPONSIVIDADE PADRÃO
   ========================================================= */
@media (max-width: 768px) {
    .header-content { flex-direction: column; height: auto; padding: 1rem 0; gap: 1rem; }
    .logo-container { flex-direction: row; text-align: center; }
    .nav-links { flex-wrap: wrap; justify-content: center; margin-top: 0; }
    .container { padding: 0 1rem; margin: 1.5rem auto; }
    .page-header { flex-direction: column; align-items: flex-start; }
    .form-card { padding: 1.5rem; border-radius: 12px; }
    .form-grid { grid-template-columns: 1fr; gap: 1rem; }
    .form-actions { flex-direction: column; }
    .btn { width: 100%; }
    .toast-container { top: 1rem; right: 1rem; left: 1rem; }
    .toast { min-width: auto; width: 100%; }
}
</style>
</head>
<body>

<header class="header">
    <div class="header-content">
        <div class="logo-container">
            <img src="../../../../public/assets/imgs/smartkampus-logo.png" alt="Logo" class="logo-img">
            <span class="logo-text">SMARTKAMPUS</span>
        </div>
        <div class="nav-links">
            <a href="../../../dashboard.php" class="nav-button"><i class="fas fa-dashboard"></i><span>Painel Principal</span></a>
            <a href="../../../../public/logout.php" class="nav-button logout"><i class="fas fa-sign-out-alt"></i><span>Sair</span></a>
        </div>
    </div>
</header>

<div id="toast-container" class="toast-container">
    <?php if (!empty($_SESSION['sucesso'])): ?>
    <div class="toast toast-success">
        <i class="fas fa-check-circle toast-icon"></i>
        <div class="toast-content">
            <div class="toast-title">Sucesso!</div>
            <div class="toast-message"><?= htmlspecialchars($_SESSION['sucesso']); ?></div>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
    </div>
    <?php unset($_SESSION['sucesso']); ?>
    <?php endif; ?>
    <?php if (!empty($_SESSION['erro'])): ?>
    <div class="toast toast-error">
        <i class="fas fa-exclamation-circle toast-icon"></i>
        <div class="toast-content">
            <div class="toast-title">Erro!</div>
            <div class="toast-message"><?= htmlspecialchars($_SESSION['erro']); ?></div>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
    </div>
    <?php unset($_SESSION['erro']); ?>
    <?php endif; ?>
</div>

<main class="container">
    <div class="breadcrumb">
        <a href="../../index.php">Início</a><span class="separator">/</span><span>Criar Exame</span>
    </div>
    <div class="page-header">
        <h1 class="page-title"><i class="fas fa-file-signature"></i> Criar Exame</h1>
    </div>
    <div class="form-card">
        <h2 class="form-title"><i class="fas fa-edit"></i> Preencher Dados do Exame</h2>
        <form method="POST" action="salvar_exame.php" id="formExame">
            <div class="form-grid">
                <div class="form-group">
                    <label>Dia da Semana <span class="required">*</span></label>
                    <select name="dia_semana" class="form-control" required>
                        <option value="" disabled selected>Selecione o dia</option>
                        <?php foreach ($diasSemana as $dia): ?>
                        <option value="<?= $dia ?>"><?= $dia ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Data <span class="required">*</span></label>
                    <input type="date" name="data" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Curso <span class="required">*</span></label>
                    <select name="curso" class="form-control" required>
                        <option value="" disabled selected>Selecione o curso</option>
                        <?php foreach ($cursos as $curso): ?>
                        <option value="<?= $curso ?>"><?= $curso ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Ano <span class="required">*</span></label>
                    <select name="ano" class="form-control" required>
                        <option value="" disabled selected>Selecione o ano</option>
                        <?php foreach ($anos as $ano): ?>
                        <option value="<?= $ano ?>"><?= $ano ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Semestre <span class="required">*</span></label>
                    <select name="semestre" class="form-control" required>
                        <option value="" disabled selected>Selecione o semestre</option>
                        <?php foreach ($semestres as $sem): ?>
                        <option value="<?= $sem ?>"><?= $sem ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Disciplina <span class="required">*</span></label>
                    <input type="text" name="disciplina" id="disciplina" class="form-control" placeholder="Ex: Engenharia de Software" autocomplete="off" required>
                    <div class="error-message" id="disciplina-error"><i class="fas fa-exclamation-circle"></i> Apenas letras e espaços são permitidos!</div>
                </div>
                <div class="form-group">
                    <label>Turno <span class="required">*</span></label>
                    <select name="turno" class="form-control" required>
                        <option value="" disabled selected>Selecione o turno</option>
                        <?php foreach ($turnos as $turno): ?>
                        <option value="<?= $turno ?>"><?= $turno ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Sala <span class="required">*</span></label>
                    <select name="sala" class="form-control" required>
                        <option value="" disabled selected>Selecione a sala</option>
                        <?php foreach ($salas as $sala): ?>
                        <option value="<?= $sala ?>"><?= $sala ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Docente <span class="required">*</span></label>
                    <input type="text" name="docente_nome" id="docente_nome" class="form-control" placeholder="Nome do Docente" autocomplete="off" required>
                    <div class="error-message" id="docente-error"><i class="fas fa-exclamation-circle"></i> Apenas letras e espaços são permitidos!</div>
                </div>
                <div class="form-group">
                    <label>Hora Início <span class="required">*</span></label>
                    <input type="time" name="hora_inicio" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Hora Fim <span class="required">*</span></label>
                    <input type="time" name="hora_fim" class="form-control" required>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" id="submitBtn" class="btn btn-primary"><i class="fas fa-save"></i> Salvar Exame</button>
                <a href="listar_exames.php" class="btn btn-secondary"><i class="fas fa-list"></i> Ver Exames Existentes</a>
                <a href="../../index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Voltar ao Painel</a>
            </div>
        </form>
    </div>
</main>

<footer class="footer">
    <p>© 2026 <span class="footer-logo">SMARTKAMPUS</span> • Universidade Católica de Moçambique</p>
</footer>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const toasts = document.querySelectorAll('.toast');
    toasts.forEach(toast => {
        setTimeout(() => {
            toast.style.animation = 'toastOut 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards';
            setTimeout(() => toast.remove(), 400);
        }, 5000);
    });

    function validarTexto(valor) { return /^[A-Za-zÀ-ÿ\s\-']*$/.test(valor); }
    function limparTexto(valor) { return valor.replace(/[^A-Za-zÀ-ÿ\s\-']/g, ''); }
    function mostrarErro(elemento, mensagem) {
        if (elemento) { elemento.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${mensagem}`; elemento.classList.add('show'); }
    }
    function ocultarErro(elemento) { if (elemento) elemento.classList.remove('show'); }
    function formatarCapitalizacao(valor) {
        return valor.trim().split(/\s+/).map(p => p.length > 0 ? p.charAt(0).toUpperCase() + p.slice(1).toLowerCase() : p).join(' ');
    }

    const disciplinaInput = document.getElementById('disciplina');
    const disciplinaError = document.getElementById('disciplina-error');
    if (disciplinaInput) {
        disciplinaInput.addEventListener('input', function() {
            let valorLimpo = limparTexto(this.value);
            if (this.value !== valorLimpo) {
                this.value = valorLimpo;
                mostrarErro(disciplinaError, 'Caracteres não permitidos foram removidos!');
                this.style.borderColor = '#ef4444';
            } else {
                validarTexto(this.value) ? (ocultarErro(disciplinaError), this.style.borderColor = '#8b5cf6') : (mostrarErro(disciplinaError, 'Apenas letras e espaços!'), this.style.borderColor = '#ef4444');
            }
        });
        disciplinaInput.addEventListener('blur', function() {
            const valor = this.value.trim();
            if (valor === '') { mostrarErro(disciplinaError, 'Este campo é obrigatório!'); this.style.borderColor = '#ef4444'; } 
            else { ocultarErro(disciplinaError); this.style.borderColor = '#8b5cf6'; this.value = formatarCapitalizacao(valor); }
        });
    }

    const docenteInput = document.getElementById('docente_nome');
    const docenteError = document.getElementById('docente-error');
    if (docenteInput) {
        docenteInput.addEventListener('input', function() {
            let valorLimpo = limparTexto(this.value);
            if (this.value !== valorLimpo) {
                this.value = valorLimpo;
                mostrarErro(docenteError, 'Caracteres não permitidos foram removidos!');
                this.style.borderColor = '#ef4444';
            } else {
                validarTexto(this.value) ? (ocultarErro(docenteError), this.style.borderColor = '#8b5cf6') : (mostrarErro(docenteError, 'Apenas letras e espaços!'), this.style.borderColor = '#ef4444');
            }
        });
        docenteInput.addEventListener('blur', function() {
            const valor = this.value.trim();
            if (valor === '') { mostrarErro(docenteError, 'Este campo é obrigatório!'); this.style.borderColor = '#ef4444'; } 
            else { ocultarErro(docenteError); this.style.borderColor = '#8b5cf6'; this.value = formatarCapitalizacao(valor); }
        });
        docenteInput.addEventListener('paste', function(e) {
            e.preventDefault();
            const textoColado = (e.clipboardData || window.clipboardData).getData('text');
            this.value = limparTexto(textoColado);
            this.dispatchEvent(new Event('input', { bubbles: true }));
        });
    }

    const form = document.getElementById('formExame');
    if (form) {
        form.addEventListener('submit', function(e) {
            let isValid = true;
            if (disciplinaInput && disciplinaInput.value.trim() === '') {
                e.preventDefault(); mostrarErro(disciplinaError, 'O campo Disciplina é obrigatório!'); disciplinaInput.style.borderColor = '#ef4444'; disciplinaInput.focus(); isValid = false;
            }
            if (docenteInput && docenteInput.value.trim() === '') {
                e.preventDefault(); mostrarErro(docenteError, 'O campo Docente é obrigatório!'); docenteInput.style.borderColor = '#ef4444'; if (isValid) docenteInput.focus(); isValid = false;
            }
            return isValid;
        });
    }
});
</script>
</body>
</html>