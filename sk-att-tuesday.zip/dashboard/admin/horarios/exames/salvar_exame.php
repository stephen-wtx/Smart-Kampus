<?php
session_start();
require_once __DIR__ . "/../../../../config/database.php";
require_once __DIR__ . "/../validacao/validar_horario.php";

if (!isset($_SESSION['user'])) {
    header('Location: ../../../../public/index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Requisição inválida.");
}

// 1️⃣ Captura dados (Alinhado com salvar_teste.php)
$dia_semana   = $_POST['dia_semana'] ?? '';
$data         = $_POST['data'] ?? '';
$curso        = $_POST['curso'] ?? '';
$ano          = $_POST['ano'] ?? '';
$semestre     = $_POST['semestre'] ?? '';
$disciplina   = $_POST['disciplina'] ?? '';
$turno        = $_POST['turno'] ?? '';
$sala         = $_POST['sala'] ?? '';
$docente_nome = trim($_POST['docente_nome'] ?? ''); // Recebe texto direto do form
$hora_inicio  = $_POST['hora_inicio'] ?? '';
$hora_fim     = $_POST['hora_fim'] ?? '';

// 2️⃣ Validação da data
if (!DateTime::createFromFormat('Y-m-d', $data)) {
    $_SESSION['erro'] = "Data inválida!";
    header("Location: criar_exame.php");
    exit;
}

// 3️⃣ Validação de conflitos e regras de negócio
$erro = validarHorario(
    $conn, 'exame', $dia_semana, $data, $curso, $ano, $semestre,
    $turno, $sala, $hora_inicio, $hora_fim
);

if ($erro) {
    $_SESSION['erro'] = $erro;
    header("Location: criar_exame.php");
    exit;
}

// 4️⃣ Cálculo da duração
$hora_inicio_dt = new DateTime($hora_inicio);
$hora_fim_dt    = new DateTime($hora_fim);
$duracao        = intval(($hora_fim_dt->getTimestamp() - $hora_inicio_dt->getTimestamp()) / 60);

// 5️⃣ Gravação no banco
$stmt = $conn->prepare("
    INSERT INTO exames (dia_semana, data, curso, ano, semestre, disciplina, turno, sala, docente_nome, hora_inicio, hora_fim, duracao)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

$stmt->bind_param(
    "sssssssssssi",
    $dia_semana, $data, $curso, $ano, $semestre, $disciplina,
    $turno, $sala, $docente_nome, $hora_inicio, $hora_fim, $duracao
);

if ($stmt->execute()) {
    $_SESSION['sucesso'] = "Exame criado com sucesso!";
} else {
    $_SESSION['erro'] = "Erro ao salvar no banco de dados: " . $conn->error;
}
$stmt->close();

// Redirecionamento correto para a lista
header("Location: listar_exames.php");
exit;
?>