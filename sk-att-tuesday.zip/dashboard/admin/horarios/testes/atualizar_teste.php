<?php
session_start();
require_once __DIR__ . "/../../../../config/database.php";
require_once __DIR__ . "/../validacao/validar_horario.php";

if (!isset($_SESSION['user'])) {
    header('Location: ../../../../public/index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['id'])) {
    die("Requisição inválida.");
}

// 1️⃣ Captura dados (Alinhado perfeitamente com atualizar_horario.php)
$id           = (int) $_POST['id'];
$dia_semana   = $_POST['dia_semana'] ?? '';
$data         = $_POST['data'] ?? '';
$curso        = $_POST['curso'] ?? '';
$ano          = $_POST['ano'] ?? '';
$semestre     = $_POST['semestre'] ?? '';
$disciplina   = $_POST['disciplina'] ?? '';
$turno        = $_POST['turno'] ?? '';
$sala         = $_POST['sala'] ?? '';
$docente_nome = trim($_POST['docente_nome'] ?? ''); // Recebe texto direto do form
$hora_inicio  = $_POST['hora_inicio'] ?? '';
$hora_fim     = $_POST['hora_fim'] ?? '';

// 2️⃣ Validação da data
if (!DateTime::createFromFormat('Y-m-d', $data)) {
    $_SESSION['erro'] = "Data inválida!";
    header("Location: editar_teste.php?id=$id");
    exit;
}

// 3️⃣ Validação de regras de negócio e conflitos
$erro = validarHorario(
    $conn, 'teste', $dia_semana, $data, $curso, $ano, $semestre,
    $turno, $sala, $hora_inicio, $hora_fim, $id
);

if ($erro) {
    $_SESSION['erro'] = $erro;
    header("Location: editar_teste.php?id=$id");
    exit;
}

// 4️⃣ Cálculo da duração em minutos
$hora_inicio_dt = new DateTime($hora_inicio);
$hora_fim_dt    = new DateTime($hora_fim);
$duracao        = intval(($hora_fim_dt->getTimestamp() - $hora_inicio_dt->getTimestamp()) / 60);

// 5️⃣ Atualiza o teste no banco (Sem a coluna docente_id que causava o crash)
$stmt = $conn->prepare("
    UPDATE testes SET
    dia_semana = ?, data = ?, curso = ?, ano = ?, semestre = ?,
    disciplina = ?, turno = ?, sala = ?, docente_nome = ?, 
    hora_inicio = ?, hora_fim = ?, duracao = ?
    WHERE id = ?
");

// CORREÇÃO CRÍTICA: 11 strings ('s') e 2 inteiros ('i' para duracao e id)
$stmt->bind_param(
    "sssssssssssii",
    $dia_semana, $data, $curso, $ano, $semestre, $disciplina,
    $turno, $sala, $docente_nome, $hora_inicio, $hora_fim, $duracao, $id
);

if ($stmt->execute()) {
    $_SESSION['sucesso'] = "Teste atualizado com sucesso!";
} else {
    $_SESSION['erro'] = "Erro ao atualizar no banco de dados: " . $conn->error;
}
$stmt->close();

header("Location: listar_testes.php");
exit;
?>