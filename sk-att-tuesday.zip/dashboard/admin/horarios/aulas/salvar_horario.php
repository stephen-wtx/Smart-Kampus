<?php
session_start();
require_once __DIR__ . "/../../../../config/database.php";
require_once __DIR__ . "/../validacao/validar_horario.php";

if (!isset($_SESSION['user'])) {
    header('Location: ../../../../public/index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Requisição inválida.");
}

// Captura dados
$dia_semana   = $_POST['dia_semana'];
$curso        = $_POST['curso'];
$ano          = $_POST['ano'];
$semestre     = $_POST['semestre'];
$disciplina   = $_POST['disciplina'];
$turno        = $_POST['turno'];
$sala         = $_POST['sala'];
$docente_nome = trim($_POST['docente_nome']);
$hora_inicio  = $_POST['hora_inicio'];
$hora_fim     = $_POST['hora_fim'];

// 1️⃣ Validação
$erro = validarHorario(
    $conn, 'aula', $dia_semana, null, $curso, $ano, $semestre, 
    $turno, $sala, $hora_inicio, $hora_fim
);

if ($erro) {
    $_SESSION['erro'] = $erro;
    header("Location: criar_horario.php");
    exit;
}

// 2️⃣ Gravação no banco
$stmt = $conn->prepare("
    INSERT INTO horarios (dia_semana, curso, ano, semestre, disciplina, turno, sala, docente_nome, hora_inicio, hora_fim) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");
$stmt->bind_param(
    "ssssssssss",
    $dia_semana, $curso, $ano, $semestre, $disciplina, 
    $turno, $sala, $docente_nome, $hora_inicio, $hora_fim
);

if ($stmt->execute()) {
    $_SESSION['sucesso'] = "Horário criado com sucesso!";
} else {
    $_SESSION['erro'] = "Erro ao salvar no banco de dados: " . $conn->error;
}

$stmt->close();
header("Location: listar_horarios.php");
exit;
?>