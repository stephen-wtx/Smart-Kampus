<?php
session_start();
require_once __DIR__ . "/../../../../config/database.php";
if (!isset($_SESSION['user'])) {
    header('Location: ../../../../public/index.php');
    exit;
}
$user = $_SESSION['user'];

if (!isset($user['role']) || $user['role'] !== 'admin') {
    // Se não for admin, redireciona para o dashboard normal
    header('Location: ../../../dashboard.php');
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) { die("Horário inválido."); }

$stmt = $conn->prepare("SELECT * FROM horarios WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$horario = $result->fetch_assoc();
if (!$horario) { die("Horário não encontrado."); }

$diasSemana = ['Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira'];
$cursos = ['Administração Pública', 'Contabilidade & Auditoria', 'Direito', 'Economia e Gestão', 'Gestão de Recursos Humanos', 'Meio Ambiente', 'Tecnologia de Informação'];
$anos = ['1º','2º','3º','4º'];
$semestres = ['I','II'];
$turnos = ['Manhã','Tarde','Noite'];
$salas = ['Nelson Mandela 1','Nelson Mandela 2','Nkwame Nkrumah','Martin Luther King', 'Santo Agostinho','Dom Jaime Gonsalves','Josefina Bakhita 1','Josefina Bakhita 2', 'Blase Pascal','Sala de Informática','Laboratório de SIG','Cipriano Parite 1', 'Cipriano Parite 2','Laboratório de Línguas','São Tomás de Aquino','Roberto Busa', 'Rosário Policarpo Nápica','Beato Newman','Francisco de Assis', 'São Francisco de Vitória','Max Planck'];
?>
<!DOCTYPE html>
<html lang="pt-pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Editar Horário - SMART KAMPUS</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="icon" type="image/x-icon" href="../../../../public/assets/imgs/smartkampus-logo.png">
<style>
/* Importação das Fontes (Padronizado com criar_horario.php) */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap');

/* Variáveis Globais de Estilo do Header/Footer */
:root {
    --primary: #3b43ce;
    --primary-hover: #2f36b5;
    --danger: #ef4444;
    --bg-body: #f8fafc;
    --bg-card: #ffffff;
    --text-main: #0f172a;
    --text-muted: #64748b;
    --border-color: #e2e8f0;
    --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.06);
}

* { margin: 0; padding: 0; box-sizing: border-box; }

body { 
    background-color: #f8fafc; 
    color: #334155; 
    line-height: 1.6; 
    min-height: 100vh; 
    display: flex;
    flex-direction: column;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

/* =========================================================
   HEADER IDÊNTICO (Estilos de criar_horario.php)
   ========================================================= */
.header {
    background: var(--bg-card);
    padding: 0 2rem;
    box-shadow: var(--shadow-sm);
    position: sticky;
    top: 0;
    z-index: 100;
    border-bottom: none;
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    max-width: 1200px;
    margin: 0 auto;
    height: 80px;
}

.logo-container {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.logo-img {
    height: 40px;
    width: auto;
    transition: transform 0.2s ease;
}

.logo-img:hover {
    transform: scale(1.05);
}

.logo-text {
    font-family: 'Bebas Neue', sans-serif;
    font-size: 1.75rem;
    font-weight: 400;
    color: var(--primary);
    letter-spacing: 0.5px;
    line-height: 1;
}

.nav-links {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.nav-button {
    display: flex;
    align-items: center;
    gap: 8px;
    background: transparent;
    border: none;
    color: var(--text-muted);
    font-size: 0.9rem;
    font-weight: 500;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
    text-decoration: none;
}

.nav-button:hover {
    background-color: #f1f5f9;
    color: var(--primary);
}

.nav-button.logout {
    color: var(--danger);
}

.nav-button.logout:hover {
    background-color: #fee2e2;
}

/* =========================================
   CONTEÚDO E FORMULÁRIO (Mantidos originais)
   ========================================= */
.container { max-width: 1400px; margin: 2rem auto; padding: 0 2rem; width: 100%; flex: 1; }
.breadcrumb { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1.5rem; font-size: 0.85rem; color: #64748b; }
.breadcrumb a { color: var(--primary); text-decoration: none; font-weight: 500; }
.breadcrumb .separator { color: #cbd5e1; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem; }
.page-title { font-size: 1.75rem; font-weight: 700; color: #0f172a; display: flex; align-items: center; gap: 0.75rem; }
.page-title i { color: var(--primary); }

.horario-info { background: #e0f2fe; border: 1px solid #bae6fd; border-radius: 12px; padding: 1.25rem 1.5rem; margin-bottom: 2rem; display: flex; align-items: center; gap: 1.25rem; }
.horario-icon { width: 48px; height: 48px; background: var(--primary); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.25rem; }
.horario-details h3 { color: #0f172a; margin-bottom: 0.25rem; font-size: 1.1rem; font-weight: 600; }
.horario-details p { color: #334155; font-size: 0.9rem; }

.form-card { background: white; border-radius: 16px; padding: 2.5rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05), 0 2px 4px -1px rgba(0,0,0,0.03); border: 1px solid #e2e8f0; margin-bottom: 2rem; }
.form-title { font-size: 1.25rem; font-weight: 600; color: #0f172a; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 1px solid #f1f5f9; display: flex; align-items: center; gap: 0.75rem; }
.form-title i { color: var(--primary); }
.form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; }
.form-group { display: flex; flex-direction: column; gap: 0.5rem; }
.form-group label { font-size: 0.875rem; font-weight: 600; color: #334155; }
.form-group label .required { color: var(--danger); margin-left: 2px; }
.form-control { width: 100%; padding: 0.85rem 1rem; border: 1px solid #e2e8f0; border-radius: 10px; font-size: 0.95rem; color: #334155; background: white; transition: all 0.2s ease; appearance: none; -webkit-appearance: none; }
select.form-control { background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e"); background-repeat: no-repeat; background-position: right 1rem center; background-size: 16px 12px; padding-right: 2.5rem; }
.form-control:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 4px rgba(59, 67, 206, 0.1); }
.form-control.error { border-color: var(--danger); background-color: #fef2f2; }
.error-message { color: var(--danger); font-size: 0.75rem; margin-top: 0.25rem; display: none; align-items: center; gap: 0.25rem; }
.error-message.show { display: flex; }

.form-actions { display: flex; gap: 1rem; margin-top: 2.5rem; flex-wrap: wrap; }
.btn { display: inline-flex; align-items: center; justify-content: center; gap: 0.5rem; padding: 0.85rem 1.75rem; border-radius: 10px; font-weight: 600; font-size: 0.9rem; cursor: pointer; transition: all 0.2s ease; border: 1px solid transparent; text-decoration: none; white-space: nowrap; }
.btn-success { background: #10b981; color: white; }
.btn-success:hover { background: #059669; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(16, 185, 129, 0.25); }
.btn-secondary { background: white; color: #334155; border-color: #e2e8f0; }
.btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.05); }

/* =========================================================
   FOOTER IDÊNTICO (Estilos de criar_horario.php)
   ========================================================= */
.footer {
    background: #0f172a;
    color: #cbd5e1;
    text-align: center;
    padding: 1.5rem;
    margin-top: auto;
    font-size: 0.875rem;
}

.footer-logo {
    font-family: 'Bebas Neue', sans-serif;
    font-size: 1.2rem;
    letter-spacing: 0.5px;
    color: #ffffff;
}

/* =========================================================
   RESPONSIVIDADE PADRÃO (Header e Layout)
   ========================================================= */
@media (max-width: 768px) {
    .header-content { flex-direction: column; height: auto; padding: 1rem 0; gap: 1rem; } 
    .logo-container { flex-direction: row; text-align: center; } 
    .nav-links { flex-wrap: wrap; justify-content: center; } 
    .container { padding: 0 1rem; margin: 1.5rem auto; }
    .page-header { flex-direction: column; align-items: flex-start; }
    .form-card { padding: 1.5rem; border-radius: 12px; }
    .form-grid { grid-template-columns: 1fr; gap: 1rem; }
    .form-actions { flex-direction: column; }
    .btn { width: 100%; }
}
</style>
</head>
<body>

<header class="header">
    <div class="header-content">
        <div class="logo-container">
            <img src="../../../../public/assets/imgs/smartkampus-logo.png" alt="Logo" class="logo-img">
            <span class="logo-text">SMARTKAMPUS</span>
        </div>
        <div class="nav-links">
            <a href="../../index.php" class="nav-button"><i class="fas fa-home"></i><span>Meu Painel</span></a>
            <a href="../../../dashboard.php" class="nav-button"><i class="fas fa-dashboard"></i><span>Painel Principal</span></a>
            <a href="../../../../public/logout.php" class="nav-button logout"><i class="fas fa-sign-out-alt"></i><span>sair</span></a>
        </div>
    </div>
</header>

<main class="container">
    <div class="breadcrumb">
        <a href="../../index.php">Início</a><span class="separator">/</span><a href="listar_horarios.php">Listar Horários</a><span class="separator">/</span><span>Editar Horário</span>
    </div>
    
    <div class="page-header">
        <h1 class="page-title"><i class="fas fa-edit"></i> Editar Horário</h1>
    </div>

    <?php if (!empty($_SESSION['erro'])): ?>
        <div style="background: #fee2e2; border: 1px solid #fecaca; color: #991b1b; padding: 1rem; border-radius: 10px; margin-bottom: 1.5rem;">
            <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($_SESSION['erro']); ?>
        </div>
        <?php unset($_SESSION['erro']); ?>
    <?php endif; ?>

    <div class="horario-info">
        <div class="horario-icon"><i class="fas fa-calendar-alt"></i></div>
        <div class="horario-details">
            <h3><?= htmlspecialchars($horario['disciplina']) ?> - <?= htmlspecialchars($horario['curso']) ?></h3>
            <p>Sala: <?= htmlspecialchars($horario['sala']) ?> • Dia: <?= htmlspecialchars($horario['dia_semana']) ?> • Horário: <?= date('H:i', strtotime($horario['hora_inicio'])) ?> - <?= date('H:i', strtotime($horario['hora_fim'])) ?></p>
        </div>
    </div>

    <div class="form-card">
        <h2 class="form-title"><i class="fas fa-pencil-alt"></i> Modificar Dados do Horário</h2>
        <form method="POST" action="atualizar_horario.php" id="formHorario">
            <input type="hidden" name="id" value="<?= $horario['id']; ?>">
            
            <div class="form-grid">
                <div class="form-group">
                    <label>Dia da Semana <span class="required">*</span></label>
                    <select name="dia_semana" class="form-control" required>
                        <?php foreach ($diasSemana as $d): ?>
                            <option value="<?= $d ?>" <?= $horario['dia_semana'] === $d ? 'selected' : '' ?>><?= $d ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Curso <span class="required">*</span></label>
                    <select name="curso" class="form-control" required>
                        <?php foreach ($cursos as $c): ?>
                            <option value="<?= $c ?>" <?= $horario['curso'] === $c ? 'selected' : '' ?>><?= $c ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Ano <span class="required">*</span></label>
                    <select name="ano" class="form-control" required>
                        <?php foreach ($anos as $a): ?>
                            <option value="<?= $a ?>" <?= $horario['ano'] === $a ? 'selected' : '' ?>><?= $a ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Semestre <span class="required">*</span></label>
                    <select name="semestre" class="form-control" required>
                        <?php foreach ($semestres as $s): ?>
                            <option value="<?= $s ?>" <?= $horario['semestre'] === $s ? 'selected' : '' ?>><?= $s ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Disciplina <span class="required">*</span></label>
                    <input type="text" name="disciplina" id="disciplina" class="form-control" value="<?= htmlspecialchars($horario['disciplina']); ?>" autocomplete="off" required>
                    <div class="error-message" id="disciplina-error"><i class="fas fa-exclamation-circle"></i> Apenas letras e espaços são permitidos!</div>
                </div>

                <div class="form-group">
                    <label>Turno <span class="required">*</span></label>
                    <select name="turno" class="form-control" required>
                        <?php foreach ($turnos as $t): ?>
                            <option value="<?= $t ?>" <?= $horario['turno'] === $t ? 'selected' : '' ?>><?= $t ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Sala <span class="required">*</span></label>
                    <select name="sala" class="form-control" required>
                        <?php foreach ($salas as $sala): ?>
                            <option value="<?= $sala ?>" <?= $horario['sala'] === $sala ? 'selected' : '' ?>><?= $sala ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Docente <span class="required">*</span></label>
                    <input type="text" name="docente_nome" id="docente_nome" class="form-control" value="<?= htmlspecialchars($horario['docente_nome'] ?? '') ?>" autocomplete="off" required>
                    <div class="error-message" id="docente-error"><i class="fas fa-exclamation-circle"></i> Apenas letras e espaços são permitidos!</div>
                </div>

                <div class="form-group">
                    <label>Hora Início <span class="required">*</span></label>
                    <input type="time" name="hora_inicio" class="form-control" value="<?= date('H:i', strtotime($horario['hora_inicio'])); ?>" required>
                </div>

                <div class="form-group">
                    <label>Hora Fim <span class="required">*</span></label>
                    <input type="time" name="hora_fim" class="form-control" value="<?= date('H:i', strtotime($horario['hora_fim'])); ?>" required>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Atualizar Horário</button>
                <a href="listar_horarios.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Voltar à Lista</a>
            </div>
        </form>
    </div>
</main>

<footer class="footer">
    <p>© 2026 <span class="footer-logo">SMARTKAMPUS</span> • Universidade Católica de Moçambique</p>
</footer>

<script>
    const disciplinaInput = document.getElementById('disciplina');
    const disciplinaError = document.getElementById('disciplina-error');
    const docenteInput = document.getElementById('docente_nome');
    const docenteError = document.getElementById('docente-error');

    function validarTexto(valor) {
        return /^[A-Za-zÀ-ÿ\s]*$/.test(valor);
    }

    function mostrarErro(elemento) {
        elemento.classList.add('show');
    }

    function ocultarErro(elemento) {
        elemento.classList.remove('show');
    }

    function formatarCapitalizacao(valor) {
        return valor.toLowerCase().replace(/\b\w/g, function(l) { return l.toUpperCase(); });
    }

    if(disciplinaInput) {
        disciplinaInput.addEventListener('input', function() {
            if (!validarTexto(this.value)) {
                mostrarErro(disciplinaError);
                this.classList.add('error');
            } else {
                ocultarErro(disciplinaError);
                this.classList.remove('error');
            }
        });

        disciplinaInput.addEventListener('blur', function() {
            if (validarTexto(this.value)) {
                this.value = formatarCapitalizacao(this.value.trim());
            }
        });
    }

    if(docenteInput) {
        docenteInput.addEventListener('input', function() {
            if (!validarTexto(this.value)) {
                mostrarErro(docenteError);
                this.classList.add('error');
            } else {
                ocultarErro(docenteError);
                this.classList.remove('error');
            }
        });

        docenteInput.addEventListener('blur', function() {
            if (validarTexto(this.value)) {
                this.value = formatarCapitalizacao(this.value.trim());
            }
        });
    }

    document.getElementById('formHorario').addEventListener('submit', function(e) {
        if ((disciplinaInput && !validarTexto(disciplinaInput.value)) || (docenteInput && !validarTexto(docenteInput.value))) {
            e.preventDefault();
            alert('Por favor, corrija os erros antes de enviar.');
        }
    });
</script>

</body>
</html>