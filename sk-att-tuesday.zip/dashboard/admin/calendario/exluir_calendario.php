<?php
session_start();
require_once '../../../config/database.php';
// if (!isset($_SESSION['user'])) {
//     header('Location: ../../../public/index.php');
//     exit;
// }

// $id do calendário
$id = (int)($_POST['id'] ?? 0);

$res = $conn->query("SELECT * FROM calendario_academico WHERE id = $id");

if ($res && $res->num_rows > 0) {
    $c = $res->fetch_assoc();
    @unlink('../../../public/uploads/calendario/' . $c['caminho']);
    $conn->query("DELETE FROM calendario_academico WHERE id = $id");

    // Adiciona mensagem de sucesso na sessão
    $_SESSION['success_message'] = "Calendário apagado com sucesso!";
}

// Redireciona de volta para a página principal
header('Location: ../index.php');
exit;
?>