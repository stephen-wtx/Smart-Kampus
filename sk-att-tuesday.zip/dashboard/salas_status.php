<?php
require_once __DIR__ . '/../config/database.php';

// Fuso horário de Moçambique
date_default_timezone_set('Africa/Maputo');

$hoje = date('Y-m-d');
$horaAtual = date('H:i:s');

// Dia da semana em português
$dias = [
    'Sunday'    => 'Domingo',
    'Monday'    => 'Segunda-feira',
    'Tuesday'   => 'Terça-feira',
    'Wednesday' => 'Quarta-feira',
    'Thursday'  => 'Quinta-feira',
    'Friday'    => 'Sexta-feira',
    'Saturday'  => 'Sábado',
];
$diaSemana = $dias[date('l')];

// Receber tipo de consulta (livres ou ocupadas)
$tipo = $_GET['tipo'] ?? 'livres';

// Função para normalizar nomes de salas
function normalizarNome($nome) {
    $acentos = array(
        'á' => 'a', 'à' => 'a', 'ã' => 'a', 'â' => 'a',
        'é' => 'e', 'ê' => 'e',
        'í' => 'i',
        'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
        'ú' => 'u',
        'ç' => 'c',
        'Á' => 'A', 'À' => 'A', 'Ã' => 'A', 'Â' => 'A',
        'É' => 'E', 'Ê' => 'E',
        'Í' => 'I',
        'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O',
        'Ú' => 'U',
        'Ç' => 'C'
    );
    
    $nome = strtr($nome, $acentos);
    $nome = strtolower(trim($nome));
    $nome = preg_replace('/\s+/', ' ', $nome);
    
    return $nome;
}

// ==========================
// 1. Buscar TODAS as salas da tabela salas
// ==========================
$mapaSalas = [];

$resSalas = $conn->query("SELECT nome FROM salas ORDER BY nome");

while ($s = $resSalas->fetch_assoc()) {
    $nomeOriginal = $s['nome'];
    $nomeNorm = normalizarNome($nomeOriginal);
    $mapaSalas[$nomeNorm] = $nomeOriginal;
}

// ==========================
// 2. Buscar as salas ocupadas com detalhes (Curso e Horário)
// ==========================
// NOTA: Se na sua estrutura o campo for 'curso_id' ou se chamar 'cadeira' nas tabelas de testes/exames, ajuste os campos abaixo.
$sqlOcupadas = "
    SELECT DISTINCT sala, curso, hora_inicio, hora_fim FROM (
        SELECT sala, curso, hora_inicio, hora_fim
        FROM horarios
        WHERE dia_semana = ?
          AND hora_inicio <= ?
          AND hora_fim > ?
        UNION
        SELECT sala, curso, hora_inicio, hora_fim
        FROM testes
        WHERE data = ?
          AND hora_inicio <= ?
          AND hora_fim > ?
        UNION
        SELECT sala, curso, hora_inicio, hora_fim
        FROM exames
        WHERE data = ?
          AND hora_inicio <= ?
          AND hora_fim > ?
    ) t
    WHERE sala IS NOT NULL AND sala != ''
";

$stmt = $conn->prepare($sqlOcupadas);
$stmt->bind_param(
    "sssssssss",
    $diaSemana, $horaAtual, $horaAtual,
    $hoje, $horaAtual, $horaAtual,
    $hoje, $horaAtual, $horaAtual
);
$stmt->execute();
$result = $stmt->get_result();

$salasOcupadasDetalhadas = [];
while ($r = $result->fetch_assoc()) {
    $salaOcupada = $r['sala'];
    $salaNorm = normalizarNome($salaOcupada);
    
    if (isset($mapaSalas[$salaNorm])) {
        // Formatando as horas para exibir ex: (12-13) em vez de (12:00:00-13:00:00)
        $inicio = date('H:i', strtotime($r['hora_inicio']));
        $fim = date('H:i', strtotime($r['hora_fim']));
        
        $salasOcupadasDetalhadas[$salaNorm] = [
            'nome' => $mapaSalas[$salaNorm],
            'curso' => $r['curso'] ?? 'N/A',
            'horario' => "({$inicio}-{$fim})"
        ];
    }
}

// ==========================
// 3. Separar livres e ocupadas
// ==========================
$livresFinal = [];

foreach ($mapaSalas as $norm => $original) {
    if (!isset($salasOcupadasDetalhadas[$norm])) {
        $livresFinal[] = $original;
    }
}

// ==========================
// 4. Mostrar conforme solicitado
// ==========================
if ($tipo === 'livres') {
    $totalLivres = count($livresFinal);
    echo "<p><strong>Salas Livres:</strong> " . $totalLivres . "</p>";
    
    if ($totalLivres > 0) {
        echo "<ul>";
        sort($livresFinal);
        foreach ($livresFinal as $sala) {
            echo "<li style='color:green'>🟢 " . htmlspecialchars($sala) . "</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>Não existem salas livres neste momento.</p>";
    }
    
} else { // ocupadas
    $totalOcupadas = count($salasOcupadasDetalhadas);
    echo "<p><strong>Salas Ocupadas:</strong> " . $totalOcupadas . "</p>";
    
    if ($totalOcupadas > 0) {
        echo "<ul>";
        // Ordenar as salas ocupadas pelo nome original da sala
        uasort($salasOcupadasDetalhadas, function($a, $b) {
            return strcmp($a['nome'], $b['nome']);
        });
        
        foreach ($salasOcupadasDetalhadas as $info) {
            echo "<li style='color:red'>";
            echo "🔴 " . htmlspecialchars($info['nome']) . " ";
            echo "- <strong>" . htmlspecialchars($info['curso']) . "</strong> ";
            echo htmlspecialchars($info['horario']);
            echo "</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>Não existem salas ocupadas neste momento.</p>";
    }
}
?>