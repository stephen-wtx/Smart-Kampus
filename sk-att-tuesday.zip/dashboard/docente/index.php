<?php
session_start();
require_once '../../config/database.php';
if (!isset($_SESSION['user'])) {
    header('Location: ../../public/index.php');
    exit;
}
$user = $_SESSION['user'];
/*
if (!isset($user['role']) || $user['role'] !== 'docente') {
    // Se não for admin, redireciona para o dashboard normal
    header('Location: ../dashboard.php');
    exit;
} 
*/

// Verifica se já existe reserva ativa
$check = $conn->prepare("
    SELECT id, estado
    FROM reservas
    WHERE docente_id = ?
    AND estado IN ('pendente', 'aprovada')
    LIMIT 1
");
$check->bind_param("i", $user['id']);
$check->execute();
$reservaAtiva = $check->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Docente - SMART KAMPUS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="/public/assets/imgs/smartkampus-logo.png">
    <style>
        /* =========================================================
           VARIÁVEIS GLOBAIS (Consistência com o sistema)
           ========================================================= */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap');

        :root {
            --primary: #3b43ce;
            --primary-hover: #2f36b5;
            --success: #10b981;
            --success-hover: #059669;
            --warning: #f59e0b;
            --danger: #ef4444;
            --bg-body: #f8fafc;
            --bg-card: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.06);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.025);
            --radius: 12px;
        }

        /* =========================================================
           RESET GLOBAL
           ========================================================= */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        body {
            background-color: var(--bg-body);
            color: var(--text-main);
            line-height: 1.5;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* =========================================================
           HEADER
           ========================================================= */
        .header {
            background: var(--bg-card);
            padding: 0 2rem;
            box-shadow: var(--shadow-sm);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            height: 80px;
        }

        .logo-container {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .logo-img {
            height: 40px;
            width: auto;
            transition: transform 0.2s ease;
        }

        .logo-img:hover { transform: scale(1.05); }

        .logo-text {
            font-family: 'Bebas Neue', sans-serif;
            font-size: 1.75rem;
            font-weight: 400;
            color: var(--primary);
            letter-spacing: 0.5px;
            line-height: 1;
        }

        .nav-links {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .nav-button {
            display: flex;
            align-items: center;
            gap: 8px;
            background: transparent;
            border: none;
            color: var(--text-muted);
            font-size: 0.9rem;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
        }

        .nav-button:hover {
            background-color: #f1f5f9;
            color: var(--primary);
        }

        .nav-button.logout { color: var(--danger); }
        .nav-button.logout:hover { background-color: #fee2e2; }

        /* =========================================================
           CONTEÚDO PRINCIPAL
           ========================================================= */
        .container {
            flex: 1;
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
            width: 100%;
        }

        /* =========================================================
           CARTÃO DE BOAS-VINDAS
           ========================================================= */
        .welcome-card {
            background: var(--bg-card);
            border-radius: var(--radius);
            padding: 1.5rem 2rem;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-color);
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .user-avatar, .avatar-placeholder {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            flex-shrink: 0;
            overflow: hidden;
            border: 3px solid var(--border-color);
            box-shadow: var(--shadow-sm);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .avatar-placeholder {
            background: linear-gradient(135deg, var(--primary), #6366f1);
            color: white;
            font-size: 2rem;
            border: none;
        }

        .welcome-text h1 {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--text-main);
            margin-bottom: 0.25rem;
            background: linear-gradient(135deg, var(--primary), #6366f1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .welcome-text p {
            color: var(--text-muted);
            font-size: 0.95rem;
        }

        .welcome-text strong {
            color: var(--text-main);
            font-weight: 600;
        }

        /* =========================================================
           CARDS DE AÇÃO
           ========================================================= */
        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .action-button {
            display: flex;
            align-items: center;
            gap: 1rem;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-top: 4px solid transparent;
            border-radius: var(--radius);
            padding: 1.5rem;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: var(--shadow-sm);
            text-align: left;
            width: 100%;
        }

        .action-button:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
            border-color: transparent;
        }

        .action-button.solicitar { border-top-color: var(--primary); }
        .action-button.minhas { border-top-color: var(--success); }

        .button-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            color: white;
            flex-shrink: 0;
        }

        .button-icon.solicitar { background: linear-gradient(135deg, var(--primary), #6366f1); }
        .button-icon.minhas { background: linear-gradient(135deg, var(--success), #34d399); }

        .action-button strong {
            display: block;
            font-size: 1.125rem;
            font-weight: 600;
            color: var(--text-main);
            margin-bottom: 0.25rem;
        }

        .action-button p {
            font-size: 0.875rem;
            color: var(--text-muted);
            margin: 0;
        }

        /* =========================================================
           MODAIS
           ========================================================= */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(4px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.2s ease;
            overflow-y: auto;
            padding: 1rem;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { transform: translateY(15px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .modal-content {
            background: var(--bg-card);
            border-radius: var(--radius);
            padding: 1.5rem 2rem;
            width: 100%;
            max-width: 800px; /* Reduzido para melhor proporção em formulários */
            box-shadow: var(--shadow-lg);
            animation: slideUp 0.3s ease;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .modal-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-main);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .close-modal {
            background: none;
            border: none;
            font-size: 1.25rem;
            color: var(--text-muted);
            cursor: pointer;
            width: 36px;
            height: 36px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        }

        .close-modal:hover {
            background: #f1f5f9;
            color: var(--text-main);
        }

        /* =========================================================
           FORMULÁRIOS MODERNOS (Substituindo a tabela antiga)
           ========================================================= */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.25rem;
            margin-bottom: 1.5rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.375rem;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        .form-label {
            font-weight: 500;
            color: var(--text-main);
            font-size: 0.875rem;
        }

        .form-select, .form-input {
            width: 100%;
            padding: 0.625rem 0.75rem;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 0.875rem;
            color: var(--text-main);
            background: white;
            transition: all 0.2s ease;
        }

        .form-select:focus, .form-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(59, 67, 206, 0.1);
        }

        .form-actions {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--border-color);
        }

        /* =========================================================
           ALERTAS
           ========================================================= */
        .alert {
            display: flex;
            gap: 1rem;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }

        .alert-warning {
            background: #fffbeb;
            border: 1px solid #fef3c7;
            color: #92400e;
        }

        .alert-warning i {
            font-size: 1.25rem;
            margin-top: 0.125rem;
        }

        .alert-warning strong {
            display: block;
            margin-bottom: 0.25rem;
        }

        .alert-warning p {
            font-size: 0.875rem;
            margin: 0;
            line-height: 1.5;
        }

        /* =========================================================
           BOTÕES PADRÃO
           ========================================================= */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.625rem 1.25rem;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.875rem;
            cursor: pointer;
            transition: all 0.2s ease;
            border: 1px solid transparent;
            text-decoration: none;
            height: fit-content;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }
        .btn-primary:hover { background: var(--primary-hover); border-color: var(--primary-hover); }

        .btn-success {
            background: var(--success);
            color: white;
            border-color: var(--success);
        }
        .btn-success:hover { background: var(--success-hover); border-color: var(--success-hover); }

        .btn-secondary {
            background: white;
            color: var(--text-main);
            border-color: var(--border-color);
        }
        .btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; }

        .btn-warning {
            background: #fef3c7;
            color: #92400e;
            border-color: #fef3c7;
        }
        .btn-warning:hover { background: #fde68a; }

        .btn-error {
            background: #fee2e2;
            color: #991b1b;
            border-color: #fee2e2;
        }
        .btn-error:hover { background: #fecaca; }

        .btn-small {
            padding: 0.375rem 0.75rem;
            font-size: 0.75rem;
        }

        /* =========================================================
           TABELAS
           ========================================================= */
        .table-container {
            overflow-x: auto;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            margin-top: 1rem;
        }

        .data-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            min-width: 900px;
            background: var(--bg-card);
        }

        .data-table thead { background: #f8fafc; }

        .data-table th {
            padding: 0.75rem 1rem;
            text-align: left;
            font-weight: 600;
            color: var(--text-muted);
            border-bottom: 1px solid var(--border-color);
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .data-table td {
            padding: 0.75rem 1rem;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-main);
            font-size: 0.875rem;
        }

        .data-table tr:last-child td { border-bottom: none; }
        .data-table tr:hover td { background-color: #f8fafc; }

        .action-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        /* =========================================================
           STATUS BADGES
           ========================================================= */
        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.75rem;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .status-pendente { background: #fef3c7; color: #92400e; }
        .status-aprovada { background: #d1fae5; color: #065f46; }
        .status-rejeitada { background: #fee2e2; color: #991b1b; }

        /* =========================================================
           ESTADO VAZIO
           ========================================================= */
        .empty-state {
            text-align: center;
            padding: 2.5rem 1rem;
            color: var(--text-muted);
        }

        .empty-icon {
            font-size: 2.5rem;
            color: #cbd5e1;
            margin-bottom: 0.75rem;
        }

        .empty-state h3 {
            font-size: 1.125rem;
            color: var(--text-main);
            margin-bottom: 0.5rem;
        }

        .empty-state p {
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }

        /* =========================================================
           FOOTER
           ========================================================= */
        .footer {
            background: #0f172a;
            color: #cbd5e1;
            text-align: center;
            padding: 1.5rem;
            margin-top: auto;
            font-size: 0.875rem;
        }

        .footer-logo {
            font-family: 'Bebas Neue', sans-serif;
            font-size: 1.2rem;
            letter-spacing: 0.5px;
            color: #ffffff;
        }

        /* =========================================================
           TOAST NOTIFICATIONS (Adaptado para as variáveis)
           ========================================================= */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 10px;
            max-width: 350px;
            width: 100%;
            pointer-events: none;
        }

        .toast {
            background: white;
            border-radius: 12px;
            padding: 1rem 1.25rem;
            box-shadow: var(--shadow-lg);
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            animation: toastSlideIn 0.3s ease forwards;
            pointer-events: auto;
            border-left: 4px solid transparent;
            margin-bottom: 0.5rem;
            position: relative;
            overflow: hidden;
        }

        @keyframes toastSlideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes toastSlideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }

        .toast.fade-out { animation: toastSlideOut 0.3s ease forwards; }

        .toast-success { border-left-color: var(--success); }
        .toast-success .toast-icon { background: var(--success); }
        
        .toast-error { border-left-color: var(--danger); }
        .toast-error .toast-icon { background: var(--danger); }
        
        .toast-warning { border-left-color: var(--warning); }
        .toast-warning .toast-icon { background: var(--warning); }
        
        .toast-info { border-left-color: #3b82f6; }
        .toast-info .toast-icon { background: #3b82f6; }

        .toast-icon {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            color: white;
            flex-shrink: 0;
        }

        .toast-content { flex: 1; }

        .toast-title {
            font-weight: 600;
            font-size: 0.95rem;
            color: var(--text-main);
            margin-bottom: 0.25rem;
        }

        .toast-message {
            font-size: 0.85rem;
            color: var(--text-muted);
            line-height: 1.4;
        }

        .toast-close {
            background: transparent;
            border: none;
            color: #94a3b8;
            cursor: pointer;
            font-size: 1rem;
            padding: 0.25rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            transition: all 0.2s ease;
            flex-shrink: 0;
        }

        .toast-close:hover { background: #f1f5f9; color: var(--text-muted); }

        .toast-progress {
            position: absolute;
            bottom: 0;
            left: 0;
            height: 3px;
            border-radius: 0 0 0 12px;
            animation: progress 5s linear forwards;
        }

        @keyframes progress {
            from { width: 100%; }
            to { width: 0%; }
        }

        .toast-success .toast-progress { background: var(--success); }
        .toast-error .toast-progress { background: var(--danger); }
        .toast-warning .toast-progress { background: var(--warning); }
        .toast-info .toast-progress { background: #3b82f6; }

        /* =========================================================
           RESPONSIVIDADE
           ========================================================= */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                height: auto;
                padding: 1rem 0;
                gap: 1rem;
            }

            .logo-container { flex-direction: row; text-align: center; }

            .nav-links {
                flex-wrap: wrap;
                justify-content: center;
            }

            .container { padding: 0 1rem; margin: 1rem auto; }

            .welcome-card {
                flex-direction: column;
                text-align: center;
                padding: 1.5rem;
            }

            .actions-grid { grid-template-columns: 1fr; }

            .modal-content {
                padding: 1.25rem;
                max-width: 100%;
                margin: 1rem;
            }

            .form-grid { grid-template-columns: 1fr; }

            .form-actions {
                flex-direction: column;
            }

            .btn { width: 100%; justify-content: center; }

            .toast-container {
                top: 10px;
                right: 10px;
                left: 10px;
                max-width: none;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-content">
            <div class="logo-container">
                <img src="../../public/assets/imgs/smartkampus-logo.png" alt="Logo" class="logo-img">
                <span class="logo-text">SMARTKAMPUS</span>
            </div>
            <div class="nav-links">
                <a href="../dashboard.php" class="nav-button">
                    <i class="fas fa-home"></i>
                    <span>Painel Principal</span>
                </a>
                <a href="../../public/logout.php" class="nav-button logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Sair</span>
                </a>
            </div>
        </div>
    </header>

    <!-- Conteúdo principal -->
    <main class="container">
        <!-- Welcome card -->
        <div class="welcome-card">
            <?php if (!empty($user['picture'])): ?>
                <div class="user-avatar">
                    <img src="<?= htmlspecialchars($user['picture']) ?>" alt="Foto do docente">
                </div>
            <?php else: ?>
                <div class="avatar-placeholder">
                    <i class="fas fa-user"></i>
                </div>
            <?php endif; ?>
            <div class="welcome-text">
                <h1>Painel do Docente</h1>
                <p>Bem-vindo, <strong><?= htmlspecialchars($user['name']) ?></strong></p>
                <p>Gerencie suas reservas de salas de forma rápida e eficiente.</p>
            </div>
        </div>

        <!-- Cards de ação -->
        <div class="actions-grid">
            <button class="action-button solicitar" onclick="abrirModal('modalSolicitar')">
                <div class="button-icon solicitar">
                    <i class="fas fa-calendar-plus"></i>
                </div>
                <div>
                    <strong>Solicitar Reserva</strong>
                    <p>Solicite uma nova reserva de sala</p>
                </div>
            </button>
            <button class="action-button minhas" onclick="abrirModal('modalMinhas')">
                <div class="button-icon minhas">
                    <i class="fas fa-list-alt"></i>
                </div>
                <div>
                    <strong>Minhas Reservas</strong>
                    <p>Consulte e gerencie suas reservas</p>
                </div>
            </button>
        </div>

        <!-- ================= MODAL SOLICITAR RESERVA ================= -->
        <div id="modalSolicitar" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">
                        <i class="fas fa-calendar-plus" style="color: var(--primary);"></i>
                        Solicitar Reserva
                    </h2>
                    <button class="close-modal" onclick="fecharModal('modalSolicitar')" aria-label="Fechar modal">
                        <i class="fas fa-times"></i>
                    </button>
                </div>

                <?php if ($reservaAtiva): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i>
                        <div>
                            <strong>Reserva ativa encontrada</strong>
                            <p>Você já possui uma reserva <span class="status-badge status-<?= $reservaAtiva['estado'] ?>"><?= strtoupper($reservaAtiva['estado']) ?></span>.<br>
                            Para cancelar, acesse <strong>Minhas Reservas</strong>.</p>
                        </div>
                    </div>
                    <div class="form-actions" style="border-top: none; margin-top: 0; padding-top: 0;">
                        <button onclick="abrirModal('modalMinhas'); fecharModal('modalSolicitar')" class="btn btn-primary">
                            <i class="fas fa-list-alt"></i>
                            Ver Minhas Reservas
                        </button>
                        <button onclick="fecharModal('modalSolicitar')" class="btn btn-secondary">
                            <i class="fas fa-times"></i>
                            Fechar
                        </td>
                    </div>
                <?php else: ?>
                    <form method="POST" action="solicitar_reserva.php">
                        <!-- Layout moderno em Grid substituindo a tabela antiga -->
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Curso</label>
                                <select name="curso" class="form-select" required>
                                    <option value="">-- Selecionar Curso --</option>
                                    <option value="Administração Pública">Administração Pública</option>
                                    <option value="Contabilidade & Auditoria">Contabilidade & Auditoria</option>
                            <option value="Direito">Direito</option>
                                    <option value="Economia e Gestão">Economia e Gestão</option>
                                    <option value="Gestão de Recursos Humanos">Gestão de Recursos Humanos</option>
                                    <option value="Meio Ambiente">Meio Ambiente</option>
                                    <option value="Tecnologia de Informação">Tecnologia de Informação</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Disciplina</label>
                                <input type="text" name="disciplina" class="form-input" placeholder="Nome da disciplina" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Turno</label>
                                <select name="turno" class="form-select" required>
                                    <option value="Manhã">Manhã</option>
                                    <option value="Tarde">Tarde</option>
                                    <option value="Noite">Noite</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Sala</label>
                                <select name="sala" class="form-select" required>
                                    <?php
                                    $salas = $conn->query("SELECT nome FROM salas WHERE estado = 'livre' ORDER BY nome");
                                    while ($s = $salas->fetch_assoc()):
                                    ?>
                                        <option value="<?= htmlspecialchars($s['nome']) ?>">
                                            <?= htmlspecialchars($s['nome']) ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Dia da Semana</label>
                                <select name="dia_semana" class="form-select" required>
                                    <option value="Segunda-feira">Segunda-feira</option>
                                    <option value="Terça-feira">Terça-feira</option>
                                    <option value="Quarta-feira">Quarta-feira</option>
                                    <option value="Quinta-feira">Quinta-feira</option>
                                    <option value="Sexta-feira">Sexta-feira</option>
                                    <option value="Sábado">Sábado</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Data</label>
                                <input type="date" name="data" class="form-input" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Hora início</label>
                                <input type="time" name="hora_inicio" class="form-input" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Hora fim</label>
                                <input type="time" name="hora_fim" class="form-input" required>
                            </div>
                            <div class="form-group full-width">
                                <label class="form-label">Finalidade (opcional)</label>
                                <input type="text" name="finalidade" class="form-input" placeholder="Ex: Aula prática, Reunião...">
                            </div>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-paper-plane"></i>
                                Solicitar Reserva
                            </button>
                            <button type="button" onclick="fecharModal('modalSolicitar')" class="btn btn-secondary">
                                <i class="fas fa-times"></i>
                                Cancelar
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>

        <!-- ================= MODAL MINHAS RESERVAS ================= -->
        <div id="modalMinhas" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">
                        <i class="fas fa-list-alt" style="color: var(--success);"></i>
                        Minhas Reservas
                    </h2>
                    <button class="close-modal" onclick="fecharModal('modalMinhas')" aria-label="Fechar modal">
                        <i class="fas fa-times"></i>
                    </button>
                </div>

                <?php
                $list = $conn->prepare("
                    SELECT id, curso, disciplina, turno, sala, dia_semana, data, hora_inicio, hora_fim, finalidade, estado
                    FROM reservas
                    WHERE docente_id = ?
                    ORDER BY criado_em DESC
                ");
                $list->bind_param("i", $user['id']);
                $list->execute();
                $result = $list->get_result();
                ?>

                <?php if ($result->num_rows === 0): ?>
                    <div class="empty-state">
                        <div class="empty-icon">
                            <i class="far fa-calendar-times"></i>
                        </div>
                        <h3>Nenhuma reserva encontrada</h3>
                        <p>Você ainda não possui reservas cadastradas.</p>
                        <button onclick="fecharModal('modalMinhas'); abrirModal('modalSolicitar')" class="btn btn-primary" style="margin-top: 1rem;">
                            <i class="fas fa-calendar-plus"></i>
                            Solicitar Primeira Reserva
                        </button>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Curso</th>
                                    <th>Disciplina</th>
                                    <th>Sala</th>
                                    <th>Turno</th>
                                    <th>Dia</th>
                                    <th>Data</th>
                                    <th>Hora</th>
                                    <th>Finalidade</th>
                                    <th>Estado</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($r = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($r['curso']) ?></td>
                                    <td><?= htmlspecialchars($r['disciplina']) ?></td>
                                    <td><strong><?= htmlspecialchars($r['sala']) ?></strong></td>
                                    <td><?= htmlspecialchars($r['turno']) ?></td>
                                    <td><?= htmlspecialchars($r['dia_semana']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($r['data'])) ?></td>
                                    <td><?= substr($r['hora_inicio'],0,5) ?> - <?= substr($r['hora_fim'],0,5) ?></td>
                                    <td><?= $r['finalidade'] ?: '-' ?></td>
                                    <td>
                                        <span class="status-badge status-<?= $r['estado'] ?>">
                                            <?= strtoupper($r['estado']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <?php if ($r['estado'] === 'aprovada' || $r['estado'] === 'pendente'): ?>
                                                <button type="button" class="btn btn-warning btn-small" onclick="abrirModalCancelar(<?= $r['id'] ?>)">
                                                    <i class="fas fa-ban"></i> Cancelar
                                                </button>
                                            <?php elseif ($r['estado'] === 'rejeitada'): ?>
                                                <form method="POST" action="excluir_reserva.php" style="display:inline;">
                                                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                                                    <button type="submit" class="btn btn-error btn-small" onclick="return confirm('Deseja excluir esta reserva rejeitada?')">
                                                        <i class="fas fa-trash"></i> Excluir
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <span style="font-size: 0.75rem; color: var(--text-muted);">-</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="form-actions">
                        <button onclick="fecharModal('modalMinhas')" class="btn btn-secondary" style="margin-left: auto;">
                            <i class="fas fa-times"></i>
                            Fechar
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- MODAL CONFIRMAR CANCELAMENTO -->
        <div id="modalCancelar" class="modal">
            <div class="modal-content" style="max-width: 500px;">
                <div class="modal-header">
                    <h2 class="modal-title">
                        <i class="fas fa-exclamation-triangle" style="color: var(--warning);"></i>
                        Confirmar Cancelamento
                    </h2>
                    <button class="close-modal" onclick="fecharModal('modalCancelar')" aria-label="Fechar modal">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <p style="margin: 1rem 0; color: var(--text-muted); line-height: 1.6;">
                    Tem certeza que deseja cancelar esta reserva?<br>
                    <strong>Esta ação não pode ser desfeita.</strong>
                </p>
                <form method="POST" action="cancelar_reserva.php">
                    <input type="hidden" name="id" id="reservaIdCancelar">
                    <div class="form-actions" style="margin-top: 1.5rem;">
                        <button type="submit" class="btn btn-warning">
                            <i class="fas fa-ban"></i>
                            Sim, Cancelar
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="fecharModal('modalCancelar')">
                            Voltar
                        </button>
                </div>
                </form>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <p>© 2026 <span class="footer-logo">SMARTKAMPUS</span> • Universidade Católica de Moçambique</p>
    </footer>

    <!-- Toast Notifications -->
    <div class="toast-container" id="toastContainer"></div>

    <script src="/public/assets/js/docente/script.js"></script>
    <script>
        // Sistema de Toast Notifications
        function showToast(message, type = 'success', duration = 5000) {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            
            let icon = 'check-circle';
            let title = 'Sucesso';
            switch(type) {
                case 'error': icon = 'exclamation-circle'; title = 'Erro'; break;
                case 'warning': icon = 'exclamation-triangle'; title = 'Aviso'; break;
                case 'info': icon = 'info-circle'; title = 'Informação'; break;
                default: icon = 'check-circle'; title = 'Sucesso';
            }
            
            toast.innerHTML = `
                <div class="toast-icon"><i class="fas fa-${icon}"></i></div>
                <div class="toast-content">
                    <div class="toast-title">${title}</div>
                    <div class="toast-message">${message}</div>
                </div>
                <button class="toast-close" onclick="this.closest('.toast').remove()"><i class="fas fa-times"></i></button>
                <div class="toast-progress"></div>
            `;
            
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.classList.add('fade-out');
                setTimeout(() => { if (toast.parentNode) toast.remove(); }, 300);
            }, duration);
            
            toast.querySelector('.toast-close').addEventListener('click', () => {
                toast.classList.add('fade-out');
                setTimeout(() => toast.remove(), 300);
            });
        }

        // Mostrar mensagens da sessão
        document.addEventListener('DOMContentLoaded', function() {
            <?php if (isset($_SESSION['success_message'])): ?>
                showToast('<?= htmlspecialchars($_SESSION['success_message']) ?>', 'success');
                <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>
            <?php if (isset($_SESSION['error_message'])): ?>
                showToast('<?= htmlspecialchars($_SESSION['error_message']) ?>', 'error');
                <?php unset($_SESSION['error_message']); ?>
            <?php endif; ?>
            <?php if (isset($_SESSION['warning_message'])): ?>
                showToast('<?= htmlspecialchars($_SESSION['warning_message']) ?>', 'warning');
                <?php unset($_SESSION['warning_message']); ?>
            <?php endif; ?>
        });
    </script>
</body>
</html>