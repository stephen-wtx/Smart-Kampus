<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

session_start();

if (!isset($_SESSION['user'])) {
    http_response_code(401);
    die("Usuário não autenticado.");
}

$user = $_SESSION['user'];

require_once '../../config/database.php';


$sala        = $_POST['sala'] ?? null;
$dia_semana  = $_POST['dia_semana'] ?? null;
$data        = $_POST['data'] ?? null;
$hora_inicio = $_POST['hora_inicio'] ?? null;
$hora_fim    = $_POST['hora_fim'] ?? null;
$curso       = $_POST['curso'] ?? null;
$disciplina  = $_POST['disciplina'] ?? null;
$turno       = $_POST['turno'] ?? null;
$finalidade  = $_POST['finalidade'] ?? null;

/* ================= VALIDAÇÕES ================= */

// Função para redirecionar com mensagem de erro
function redirectWithError($message) {
    $_SESSION['error_message'] = $message;
    header("Location: index.php");
    exit;
}

// Campos obrigatórios
if (
    empty($sala) || empty($dia_semana) || empty($data) ||
    empty($hora_inicio) || empty($hora_fim) ||
    empty($curso) || empty($disciplina) || empty($turno)
) {
    redirectWithError("Todos os campos obrigatórios devem ser preenchidos.");
}

// Data válida
$hoje = date('Y-m-d');
if ($data < $hoje) {
    redirectWithError("Não é possível reservar para datas passadas.");
}

// Hora lógica
if ($hora_fim <= $hora_inicio) {
    redirectWithError("Hora fim deve ser maior que a hora início.");
}

// Curso válido
$cursosValidos = [
    'Administração Pública',
    'Contabilidade & Auditoria',
    'Direito',
    'Economia e Gestão',
    'Gestão de Recursos Humanos',
    'Meio Ambiente',
    'Tecnologia de Informação'
];

if (!in_array($curso, $cursosValidos)) {
    redirectWithError("Curso inválido.");
}

// Disciplina válida
$disciplina = trim($disciplina);

if (!preg_match('/^[A-Za-zÀ-ÿ\s]+(\s[I,V,X]+)?$/', $disciplina)) {
    redirectWithError("Nome de disciplina inválido.");
}


// Turno coerente
switch ($turno) {
    case 'Manhã':
        if ($hora_inicio < '07:00' || $hora_fim > '11:59') {
            redirectWithError("Horário fora do turno da manhã.");
        }
        break;

    case 'Tarde':
        if ($hora_inicio < '12:00' || $hora_fim > '17:59') {
            redirectWithError("Horário fora do turno da tarde.");
        }
        break;

    case 'Noite':
        if ($hora_inicio < '18:00' || $hora_fim > '21:30') {
            redirectWithError("Horário fora do turno da noite.");
        }
        break;

    default:
        redirectWithError("Turno inválido.");
}

/* ================= VALIDAÇÕES EXISTENTES ================= */

// Já possui reserva
$check = $conn->prepare("SELECT 1 FROM reservas WHERE docente_id = ?");
$check->bind_param("i", $user['id']);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    redirectWithError("Já possui uma reserva.");
}

// Conflitos de sala - SEM FILTRO DE DATA (igual ao original)
$sqlConflito = "
    SELECT 1 FROM (
        SELECT sala, hora_inicio, hora_fim FROM horarios
        UNION ALL
        SELECT sala, hora_inicio, hora_fim FROM testes
        UNION ALL
        SELECT sala, hora_inicio, hora_fim FROM exames
        UNION ALL
        SELECT sala, hora_inicio, hora_fim FROM reservas
        WHERE estado IN ('pendente','aprovada')
    ) t
    WHERE sala = ?
    AND NOT (hora_fim <= ? OR hora_inicio >= ?)
";

$stmt = $conn->prepare($sqlConflito);
$stmt->bind_param("sss", $sala, $hora_inicio, $hora_fim);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    redirectWithError("Sala ocupada neste horário.");
}

// Inserção
$insert = $conn->prepare("
    INSERT INTO reservas
    (docente_id, docente_nome, sala, dia_semana, data, hora_inicio, hora_fim, curso, disciplina, turno, finalidade)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

$insert->bind_param(
    "issssssssss",
    $user['id'],
    $user['name'],
    $sala,
    $dia_semana,
    $data,
    $hora_inicio,
    $hora_fim,
    $curso,
    $disciplina,
    $turno,
    $finalidade
);

if ($insert->execute()) {
    $_SESSION['success_message'] = "Reserva solicitada com sucesso! Aguarde aprovação.";
} else {
    $_SESSION['error_message'] = "Erro ao solicitar reserva. Tente novamente.";
}

header("Location: index.php");
exit;