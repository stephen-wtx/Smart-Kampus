<?php
session_start();
require_once __DIR__ . '/../config/database.php';
if (!isset($_SESSION['user'])) {
    header('Location: /public/index.php');
    exit;
}
$user = $_SESSION['user'];

// Buscar reservas ativas (aprovadas) para exibir no dashboard
$reservas_ativas = $conn->query("
    SELECT 
        id,
        docente_nome,
        curso,
        disciplina,
        sala,
        turno,
        dia_semana,
        data,
        hora_inicio,
        hora_fim,
        finalidade,
        estado
    FROM reservas 
    WHERE estado = 'aprovada' 
    AND data >= CURDATE()
    ORDER BY data ASC, hora_inicio ASC
    LIMIT 10
");

// Buscar total de reservas ativas
$total_reservas = $conn->query("
    SELECT COUNT(*) as total 
    FROM reservas 
    WHERE estado = 'aprovada' 
    AND data >= CURDATE()
")->fetch_assoc()['total'];

// Buscar salas ocupadas no momento
$salas_ocupadas = $conn->query("
    SELECT DISTINCT sala 
    FROM reservas 
    WHERE estado = 'aprovada' 
    AND data = CURDATE() 
    AND CURTIME() BETWEEN hora_inicio AND hora_fim
");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Principal - SMARTKAMPUS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="/public/assets/imgs/smartkampus-logo.png">
    <link rel="stylesheet" href="/public/assets/css/dashboard.css">
    <style>
        /* =========================================================
           ESTILOS ADICIONAIS PARA O DASHBOARD
           ========================================================= */
        :root {
            --primary: #3b43ce;
            --primary-hover: #2f36b5;
            --success: #10b981;
            --success-hover: #059669;
            --warning: #f59e0b;
            --danger: #ef4444;
            --bg-body: #f8fafc;
            --bg-card: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.06);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.025);
            --radius: 12px;
        }

        /* =========================================================
           SEÇÃO DE EVENTOS/RESERVAS ATIVAS
           ========================================================= */
        .events-section {
            background: var(--bg-card);
            border-radius: var(--radius);
            padding: 1.5rem 2rem;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-color);
            margin-top: 2rem;
        }

        .events-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .events-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-main);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .events-title i {
            color: var(--success);
        }

        .events-badge {
            background: #d1fae5;
            color: #065f46;
            padding: 0.25rem 0.75rem;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .events-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1rem;
        }

        .event-card {
            background: #f8fafc;
            border: 1px solid var(--border-color);
            border-radius: var(--radius);
            padding: 1rem 1.25rem;
            transition: all 0.2s ease;
            border-left: 4px solid var(--success);
        }

        .event-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .event-card.ocupado {
            border-left-color: var(--danger);
            background: #fef2f2;
        }

        .event-card.ocupado .event-status {
            background: #fee2e2;
            color: #991b1b;
        }

        .event-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 0.5rem;
        }

        .event-sala {
            font-weight: 600;
            font-size: 1rem;
            color: var(--text-main);
        }

        .event-sala i {
            color: var(--primary);
            margin-right: 0.25rem;
        }

        .event-status {
            font-size: 0.65rem;
            font-weight: 600;
            padding: 0.2rem 0.6rem;
            border-radius: 999px;
            background: #d1fae5;
            color: #065f46;
        }

        .event-details {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            font-size: 0.85rem;
            color: var(--text-muted);
            margin: 0.5rem 0;
        }

        .event-details span {
            display: flex;
            align-items: center;
            gap: 0.35rem;
        }

        .event-details i {
            width: 16px;
            color: var(--primary);
        }

        .event-docente {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-top: 0.25rem;
        }

        .event-docente i {
            color: var(--text-muted);
            margin-right: 0.25rem;
        }

        .event-empty {
            text-align: center;
            padding: 2rem 1rem;
            color: var(--text-muted);
        }

        .event-empty i {
            font-size: 2.5rem;
            color: #cbd5e1;
            margin-bottom: 0.75rem;
            display: block;
        }

        .view-all-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.875rem;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
        }

        .view-all-btn:hover {
            background: var(--primary-hover);
            transform: translateY(-1px);
        }

        /* =========================================================
           MODAL DE TODAS AS RESERVAS
           ========================================================= */
        .modal-content {
            max-width: 1000px;
        }

        .filter-bar {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 1.5rem;
            padding: 1rem;
            background: #f8fafc;
            border-radius: 8px;
            border: 1px solid var(--border-color);
        }

        .filter-bar .form-group {
            flex: 1;
            min-width: 150px;
        }

        .filter-bar .form-group label {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-muted);
            display: block;
            margin-bottom: 0.25rem;
        }

        .filter-bar .form-group select,
        .filter-bar .form-group input {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 0.875rem;
        }

        /* =========================================================
           TOAST NOTIFICATIONS
           ========================================================= */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 10px;
            max-width: 350px;
            width: 100%;
            pointer-events: none;
        }

        .toast {
            background: white;
            border-radius: 12px;
            padding: 1rem 1.25rem;
            box-shadow: var(--shadow-lg);
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            animation: toastSlideIn 0.3s ease forwards;
            pointer-events: auto;
            border-left: 4px solid transparent;
            margin-bottom: 0.5rem;
            position: relative;
            overflow: hidden;
        }

        @keyframes toastSlideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes toastSlideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }

        .toast.fade-out { animation: toastSlideOut 0.3s ease forwards; }

        .toast-success { border-left-color: var(--success); }
        .toast-success .toast-icon { background: var(--success); }
        .toast-error { border-left-color: var(--danger); }
        .toast-error .toast-icon { background: var(--danger); }
        .toast-warning { border-left-color: var(--warning); }
        .toast-warning .toast-icon { background: var(--warning); }
        .toast-info { border-left-color: #3b82f6; }
        .toast-info .toast-icon { background: #3b82f6; }

        .toast-icon {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            color: white;
            flex-shrink: 0;
        }

        .toast-content { flex: 1; }
        .toast-title {
            font-weight: 600;
            font-size: 0.95rem;
            color: var(--text-main);
            margin-bottom: 0.25rem;
        }
        .toast-message {
            font-size: 0.85rem;
            color: var(--text-muted);
            line-height: 1.4;
        }
        .toast-close {
            background: transparent;
            border: none;
            color: #94a3b8;
            cursor: pointer;
            font-size: 1rem;
            padding: 0.25rem;
            border-radius: 6px;
            transition: all 0.2s ease;
        }
        .toast-close:hover { background: #f1f5f9; color: var(--text-muted); }
        .toast-progress {
            position: absolute;
            bottom: 0;
            left: 0;
            height: 3px;
            border-radius: 0 0 0 12px;
            animation: progress 5s linear forwards;
        }
        @keyframes progress {
            from { width: 100%; }
            to { width: 0%; }
        }
        .toast-success .toast-progress { background: var(--success); }
        .toast-error .toast-progress { background: var(--danger); }
        .toast-warning .toast-progress { background: var(--warning); }
        .toast-info .toast-progress { background: #3b82f6; }

        /* =========================================================
           RESPONSIVIDADE
           ========================================================= */
        @media (max-width: 768px) {
            .events-grid {
                grid-template-columns: 1fr;
            }
            .events-header {
                flex-direction: column;
                align-items: stretch;
            }
            .filter-bar {
                flex-direction: column;
            }
            .filter-bar .form-group {
                min-width: 100%;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-content">
            <div class="logo-container">
                <img src="/public/assets/imgs/smartkampus-logo.png" alt="Logo" class="logo-img">
                <span class="logo-text">SMARTKAMPUS</span>
            </div>
            <div class="nav-links">
                <i class="fas fa-home"></i>
                <span>Painel principal</span>
                <a href="/public/logout.php" class="nav-button logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Sair</span>
                </a>
            </div>
        </div>
    </header>

    <!-- Conteúdo principal -->
    <main class="container">
        <!-- Welcome card -->
        <div class="welcome-card">
            <?php if (!empty($user['picture'])): ?>
                <div class="user-avatar">
                    <img src="<?= htmlspecialchars($user['picture']) ?>" alt="Foto do usuário">
                </div>
            <?php else: ?>
                <div class="avatar-placeholder">
                    <i class="fas fa-user"></i>
                </div>
            <?php endif; ?>
            <div class="welcome-text">
                <h1>Bem-vindo, <?= htmlspecialchars($user['name']); ?>!</h1>
                <div class="user-email">
                    <i class="fas fa-envelope"></i>
                    <?= htmlspecialchars($user['email']); ?>
                </div>
                <p>Acesse informações acadêmicas e gerencie sua experiência no campus.</p>
            </div>
        </div>

        <!-- ========================================================= -->
        <!-- SEÇÃO DE EVENTOS / RESERVAS ATIVAS                        -->
        <!-- ========================================================= -->
        <div class="events-section">
            <div class="events-header">
                <div class="events-title">
                    <i class="fas fa-calendar-check"></i>
                    Agendas Ativas
                    <span class="events-badge"><?= $total_reservas ?> ativas</span>
                </div>
                <?php if ($total_reservas > 0): ?>
                    <button class="view-all-btn" onclick="abrirModalTodasReservas()">
                        <i class="fas fa-list"></i>
                        Ver Todas
                    </button>
                <?php endif; ?>
            </div>

            <div class="events-grid">
                <?php if ($reservas_ativas && $reservas_ativas->num_rows > 0): ?>
                    <?php while ($r = $reservas_ativas->fetch_assoc()): 
                        // Verificar se a sala está ocupada no momento
                        $ocupado_agora = false;
                        $hoje = date('Y-m-d');
                        $agora = date('H:i:s');
                        if ($r['data'] == $hoje && $agora >= $r['hora_inicio'] && $agora <= $r['hora_fim']) {
                            $ocupado_agora = true;
                        }
                    ?>
                        <div class="event-card <?= $ocupado_agora ? 'ocupado' : '' ?>"
                             data-curso="<?= htmlspecialchars($r['curso']) ?>"
                             data-data="<?= $r['data'] ?>"
                             data-docente="<?= strtolower(htmlspecialchars($r['docente_nome'])) ?>"
                             data-disciplina="<?= strtolower(htmlspecialchars($r['disciplina'])) ?>"
                             data-sala="<?= strtolower(htmlspecialchars($r['sala'])) ?>">
                            <div class="event-header">
                                <span class="event-sala">
                                    <i class="fas fa-door-open"></i>
                                    <?= htmlspecialchars($r['sala']) ?>
                                </span>
                                <span class="event-status">
                                    <?= $ocupado_agora ? '🔴 OCUPADA AGORA' : '📅 AGENDADA' ?>
                                </span>
                            </div>
                            <div class="event-details">
                                <span><i class="fas fa-calendar-day"></i> <?= date('d/m/Y', strtotime($r['data'])) ?></span>
                                <span><i class="fas fa-clock"></i> <?= substr($r['hora_inicio'], 0, 5) ?> - <?= substr($r['hora_fim'], 0, 5) ?></span>
                                <span><i class="fas fa-graduation-cap"></i> <?= htmlspecialchars($r['curso']) ?></span>
                                <span><i class="fas fa-book"></i> <?= htmlspecialchars($r['disciplina']) ?></span>
                            </div>
                            <div class="event-docente">
                                <i class="fas fa-user"></i>
                                <?= htmlspecialchars($r['docente_nome']) ?>
                                <?php if ($r['finalidade']): ?>
                                    <span style="margin-left: 0.75rem; color: var(--text-muted);">
                                        <i class="fas fa-tag"></i> <?= htmlspecialchars($r['finalidade']) ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="event-empty" style="grid-column: 1 / -1;">
                        <i class="far fa-calendar-times"></i>
                        <p>Nenhuma agenda ativa no momento.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Dashboard Grid (Cards originais) -->
        <div class="dashboard-grid">
            <!-- Horários -->
            <div class="dashboard-card horarios" onclick="abrirModalHorarios()">
                <div class="card-header">
                    <div class="card-icon horarios">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Ver Horários</h3>
                        <div class="card-stats">
                            <i class="fas fa-search"></i>
                            <span>Consultar horários de aulas, testes e exames</span>
                        </div>
                    </div>
                </div>
                <p class="card-description">
                    Consulte os horários acadêmicos filtrados por curso, ano, semestre e turno.
                </p>
            </div>

            <!-- Salas Livres -->
            <div class="dashboard-card salas-livres" onclick="abrirModalSalas('livres')">
                <div class="card-header">
                    <div class="card-icon salas-livres">
                        <i class="fas fa-door-open"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Salas Livres</h3>
                        <div class="card-stats">
                            <i class="fas fa-check-circle"></i>
                            <span>Disponíveis para uso imediato</span>
                        </div>
                    </div>
                </div>
                <p class="card-description">
                    Visualize quais salas estão disponíveis no momento atual para reservas.
                </p>
            </div>

            <!-- Salas Ocupadas -->
            <div class="dashboard-card salas-ocupadas" onclick="abrirModalSalas('ocupadas')">
                <div class="card-header">
                    <div class="card-icon salas-ocupadas">
                        <i class="fas fa-door-closed"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Salas Ocupadas</h3>
                        <div class="card-stats">
                            <i class="fas fa-exclamation-circle"></i>
                            <span>Em uso no momento</span>
                        </div>
                    </div>
                </div>
                <p class="card-description">
                    Consulte as salas que estão atualmente em uso ou reservadas.
                </p>
            </div>

            <!-- Calendário Académico -->
            <div class="dashboard-card calendario" onclick="abrirModalCalendario()">
                <div class="card-header">
                    <div class="card-icon calendario">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Calendário Académico</h3>
                        <div class="card-stats">
                            <i class="fas fa-calendar-check"></i>
                            <span>Datas importantes do semestre</span>
                        </div>
                    </div>
                </div>
                <p class="card-description">
                    Acesse o calendário oficial com todas as datas acadêmicas importantes.
                </p>
            </div>
        </div>
    </main>

    <!-- ================= MODAL SALAS ================= -->
    <div id="modalSalas" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="tituloSalas">
                    <i class="fas fa-door-open"></i>
                    Salas
                </h2>
                <button class="close-modal" onclick="fecharModalSalas()" aria-label="Fechar modal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div id="resultadoSalas" class="table-container"></div>
            <div style="margin-top: 1.5rem; display: flex; justify-content: flex-end;">
                <button onclick="fecharModalSalas()" class="btn btn-secondary">
                    <i class="fas fa-times"></i>
                    Fechar
                </button>
            </div>
        </div>
    </div>

    <!-- ================= MODAL HORÁRIOS ================= -->
    <div id="modalHorarios" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">
                    <i class="fas fa-clock"></i>
                    Consultar Horários
                </h2>
                <button class="close-modal" onclick="fecharModalHorarios()" aria-label="Fechar modal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="filters-container">
                <div class="filters-grid">
                    <div class="form-group">
                        <label class="form-label">Tipo de Horário</label>
                        <select id="tipoHorario" class="form-select" onchange="mostrarFiltros()">
                            <option value="">-- Selecione o tipo --</option>
                            <option value="aula">Aulas</option>
                            <option value="teste">Testes</option>
                            <option value="exame">Exames</option>
                        </select>
                    </div>
                    <div id="filtros" style="display:none; grid-column: 1 / -1;">
                        <div class="filters-grid">
                            <div class="form-group">
                                <label class="form-label">Curso</label>
                                <select id="curso" class="form-select">
                                    <option value="">Todos os cursos</option>
                                    <option>Administração Pública</option>
                                    <option>Contabilidade & Auditoria</option>
                                    <option>Direito</option>
                                    <option>Economia e Gestão</option>
                                    <option>Gestão de Recursos Humanos</option>
                                    <option>Meio Ambiente</option>
                                    <option>Tecnologia de Informação</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Ano</label>
                                <select id="ano" class="form-select">
                                    <option value="">Todos os anos</option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Semestre</label>
                                <select id="semestre" class="form-select">
                                    <option value="">Ambos semestres</option>
                                    <option>I</option>
                                    <option>II</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Turno</label>
                                <select id="turno" class="form-select">
                                    <option value="">Todos os turnos</option>
                                    <option>Manhã</option>
                                    <option>Tarde</option>
                                    <option>Noite</option>
                                </select>
                            </div>
                            <div class="form-group" style="display: flex; align-items: flex-end;">
                                <button onclick="buscarHorarios()" class="btn btn-primary" style="width: 100%;">
                                    <i class="fas fa-search"></i>
                                    Buscar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="resultadoHorarios" class="table-container"></div>
        </div>
    </div>

    <!-- ================= MODAL TODAS AS RESERVAS ================= -->
    <div id="modalTodasReservas" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">
                    <i class="fas fa-calendar-check" style="color: var(--success);"></i>
                    Todas as Reservas Ativas
                </h2>
                <button class="close-modal" onclick="fecharModalTodasReservas()" aria-label="Fechar modal">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <!-- Barra de Filtros -->
            <div class="filter-bar">
                <div class="form-group">
                    <label><i class="fas fa-search"></i> Buscar</label>
                    <input type="text" id="filtroBusca" placeholder="Docente, disciplina, sala..." onkeyup="filtrarReservas()">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-filter"></i> Curso</label>
                    <select id="filtroCurso" onchange="filtrarReservas()">
                        <option value="">Todos os cursos</option>
                        <option>Administração Pública</option>
                        <option>Contabilidade & Auditoria</option>
                        <option>Direito</option>
                        <option>Economia e Gestão</option>
                        <option>Gestão de Recursos Humanos</option>
                        <option>Meio Ambiente</option>
                        <option>Tecnologia de Informação</option>
                    </select>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-calendar-day"></i> Data</label>
                    <input type="date" id="filtroData" onchange="filtrarReservas()">
                </div>
                <div class="form-group" style="display: flex; align-items: flex-end; gap: 0.5rem;">
                    <button onclick="filtrarReservas()" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-search"></i>
                        Buscar
                    </button>
                    <button onclick="limparFiltrosReservas()" class="btn btn-secondary" style="width: 100%;">
                        <i class="fas fa-undo"></i>
                        Limpar
                    </button>
                </div>
            </div>

            <div id="resultadoTodasReservas" class="table-container">
                <?php
                // Buscar reservas ativas diretamente no PHP
                $reservas_todas = $conn->query("
                    SELECT 
                        id,
                        docente_nome,
                        curso,
                        disciplina,
                        sala,
                        turno,
                        dia_semana,
                        data,
                        hora_inicio,
                        hora_fim,
                        finalidade,
                        estado
                    FROM reservas 
                    WHERE estado = 'aprovada' 
                    AND data >= CURDATE()
                    ORDER BY data ASC, hora_inicio ASC
                ");
                
                if ($reservas_todas && $reservas_todas->num_rows > 0):
                    $hoje = date('Y-m-d');
                    $agora = date('H:i:s');
                    while ($r = $reservas_todas->fetch_assoc()):
                        $ocupado_agora = ($r['data'] == $hoje && $agora >= $r['hora_inicio'] && $agora <= $r['hora_fim']);
                ?>
                    <div class="event-card <?= $ocupado_agora ? 'ocupado' : '' ?>" 
                         data-curso="<?= htmlspecialchars($r['curso']) ?>" 
                         data-data="<?= $r['data'] ?>"
                         data-docente="<?= strtolower(htmlspecialchars($r['docente_nome'])) ?>"
                         data-disciplina="<?= strtolower(htmlspecialchars($r['disciplina'])) ?>"
                         data-sala="<?= strtolower(htmlspecialchars($r['sala'])) ?>">
                        <div class="event-header">
                            <span class="event-sala">
                                <i class="fas fa-door-open"></i>
                                <?= htmlspecialchars($r['sala']) ?>
                            </span>
                            <span class="event-status">
                                <?= $ocupado_agora ? '🔴 OCUPADA AGORA' : '📅 AGENDADA' ?>
                            </span>
                        </div>
                        <div class="event-details">
                            <span><i class="fas fa-calendar-day"></i> <?= date('d/m/Y', strtotime($r['data'])) ?></span>
                            <span><i class="fas fa-clock"></i> <?= substr($r['hora_inicio'], 0, 5) ?> - <?= substr($r['hora_fim'], 0, 5) ?></span>
                            <span><i class="fas fa-graduation-cap"></i> <?= htmlspecialchars($r['curso']) ?></span>
                            <span><i class="fas fa-book"></i> <?= htmlspecialchars($r['disciplina']) ?></span>
                        </div>
                        <div class="event-docente">
                            <i class="fas fa-user"></i>
                            <?= htmlspecialchars($r['docente_nome']) ?>
                            <?php if ($r['finalidade']): ?>
                                <span style="margin-left: 0.75rem; color: var(--text-muted);">
                                    <i class="fas fa-tag"></i> <?= htmlspecialchars($r['finalidade']) ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php 
                    endwhile;
                else: 
                ?>
                    <div class="empty-state">
                        <div class="empty-icon"><i class="far fa-calendar-times"></i></div>
                        <p>Nenhuma reserva ativa encontrada.</p>
                    </div>
                <?php endif; ?>
            </div>
            <div style="margin-top: 1.5rem; display: flex; justify-content: flex-end;">
                <button onclick="fecharModalTodasReservas()" class="btn btn-secondary">
                    <i class="fas fa-times"></i>
                    Fechar
                </button>
            </div>
        </div>
    </div>

    <!-- ================= MODAL CALENDÁRIO ACADÉMICO ================= -->
    <div id="modalCalendario" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">
                    <i class="fas fa-calendar-alt"></i>
                    Calendário Académico
                </h2>
                <button class="close-modal" onclick="fecharModalCalendario()" aria-label="Fechar modal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <?php
            $cal = $conn->query("
                SELECT * FROM calendario_academico
                ORDER BY data_publicacao DESC
                LIMIT 1
            ");
            ?>
            <?php if ($cal && $cal->num_rows > 0):
                $c = $cal->fetch_assoc();
            ?>
                <div class="calendar-info">
                    <div>
                        <h3>Calendário Académico Atual</h3>
                        <p>
                            <i class="fas fa-calendar-check"></i>
                            Publicado em: <?= date('d/m/Y H:i', strtotime($c['data_publicacao'])) ?>
                        </p>
                    </div>
                </div>
                <div class="calendar-preview">
                    <iframe class="calendar-iframe" src="/public/uploads/calendario/<?= $c['caminho'] ?>" title="Calendário Académico"></iframe>
                </div>
                <div class="calendar-mobile-link">
                    <a href="/public/uploads/calendario/<?= $c['caminho'] ?>" target="_blank" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-external-link-alt"></i>
                        Abrir Calendário em Nova Aba
                    </a>
                </div>
                <div style="margin-top: 1.5rem; display: flex; gap: 1rem; flex-wrap: wrap;">
                    <a href="/public/uploads/calendario/<?= $c['caminho'] ?>" download class="btn btn-primary">
                        <i class="fas fa-download"></i>
                        Baixar Calendário
                    </a>
                    <button onclick="fecharModalCalendario()" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        Fechar
                    </button>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="far fa-calendar-times"></i>
                    </div>
                    <h3>Nenhum calendário disponível</h3>
                    <p>Não existe nenhum calendário académico publicado ainda.</p>
                    <button onclick="fecharModalCalendario()" class="btn btn-secondary" style="margin-top: 1rem;">
                        <i class="fas fa-times"></i>
                        Fechar
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>© 2026 <span class="footer-logo">SMARTKAMPUS</span> • Universidade Católica de Moçambique</p>
    </footer>

    <!-- Toast Notifications -->
    <div class="toast-container" id="toastContainer"></div>

    <script src="/public/assets/js/dashboard.js"></script>
    <script>
    // =========================================================
    // TOAST NOTIFICATIONS
    // =========================================================
    function showToast(message, type = 'success', duration = 5000) {
        const container = document.getElementById('toastContainer');
        if (!message || message.trim() === '') return;
        
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        
        let icon = 'check-circle';
        let title = 'Sucesso';
        switch(type) {
            case 'error': icon = 'exclamation-circle'; title = 'Erro'; break;
            case 'warning': icon = 'exclamation-triangle'; title = 'Aviso'; break;
            case 'info': icon = 'info-circle'; title = 'Informação'; break;
            default: icon = 'check-circle'; title = 'Sucesso';
        }
        
        toast.innerHTML = `
            <div class="toast-icon"><i class="fas fa-${icon}"></i></div>
            <div class="toast-content">
                <div class="toast-title">${title}</div>
                <div class="toast-message">${message}</div>
            </div>
            <button class="toast-close" onclick="this.closest('.toast').remove()"><i class="fas fa-times"></i></button>
            <div class="toast-progress"></div>
        `;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.add('fade-out');
            setTimeout(() => { if (toast.parentNode) toast.remove(); }, 300);
        }, duration);
        
        toast.querySelector('.toast-close').addEventListener('click', () => {
            toast.classList.add('fade-out');
            setTimeout(() => toast.remove(), 300);
        });
    }

    // =========================================================
    // MODAL TODAS AS RESERVAS
    // =========================================================
    function abrirModalTodasReservas() {
        document.getElementById('modalTodasReservas').style.display = 'flex';
    }

    function fecharModalTodasReservas() {
        document.getElementById('modalTodasReservas').style.display = 'none';
    }

    function filtrarReservas() {
        const busca = document.getElementById('filtroBusca').value.toLowerCase().trim();
        const curso = document.getElementById('filtroCurso').value;
        const data = document.getElementById('filtroData').value;
        
        const container = document.getElementById('resultadoTodasReservas');
        const cards = container.querySelectorAll('.event-card');
        
        // Se não houver cards, mostrar mensagem
        if (cards.length === 0) {
            const emptyMsg = container.querySelector('.empty-state');
            if (!emptyMsg) {
                const msg = document.createElement('div');
                msg.className = 'empty-state';
                msg.innerHTML = `
                    <div class="empty-icon"><i class="fas fa-search"></i></div>
                    <p>Nenhuma reserva encontrada.</p>
                `;
                container.appendChild(msg);
            }
            return;
        }
        
        // Remover mensagem "sem resultados" se existir
        const oldMsg = container.querySelector('.no-results');
        if (oldMsg) oldMsg.remove();
        
        let visiveis = 0;
        cards.forEach(card => {
            const texto = card.textContent.toLowerCase();
            const cursoCard = card.dataset.curso || '';
            const dataCard = card.dataset.data || '';
            const docenteCard = card.dataset.docente || '';
            const disciplinaCard = card.dataset.disciplina || '';
            const salaCard = card.dataset.sala || '';
            
            let mostrar = true;
            
            if (busca) {
                const buscaMatch = texto.includes(busca) || 
                                  docenteCard.includes(busca) || 
                                  disciplinaCard.includes(busca) || 
                                  salaCard.includes(busca);
                if (!buscaMatch) mostrar = false;
            }
            
            if (curso && cursoCard !== curso) mostrar = false;
            if (data && dataCard !== data) mostrar = false;
            
            card.style.display = mostrar ? '' : 'none';
            if (mostrar) visiveis++;
        });
        
        if (visiveis === 0) {
            const msg = document.createElement('div');
            msg.className = 'empty-state no-results';
            msg.innerHTML = `
                <div class="empty-icon"><i class="fas fa-search"></i></div>
                <p>Nenhuma reserva encontrada com os filtros selecionados.</p>
                <button onclick="limparFiltrosReservas()" class="btn btn-primary" style="margin-top: 1rem;">
                    <i class="fas fa-undo"></i>
                    Limpar filtros
                </button>
            `;
            container.appendChild(msg);
        }
    }

    function limparFiltrosReservas() {
        document.getElementById('filtroBusca').value = '';
        document.getElementById('filtroCurso').value = '';
        document.getElementById('filtroData').value = '';
        
        const container = document.getElementById('resultadoTodasReservas');
        const cards = container.querySelectorAll('.event-card');
        cards.forEach(card => card.style.display = '');
        
        const oldMsg = container.querySelector('.no-results');
        if (oldMsg) oldMsg.remove();
    }

    // =========================================================
    // FUNÇÕES DO MODAL SALAS (USANDO salas_status.php)
    // =========================================================
    function abrirModalSalas(tipo) {
        const modal = document.getElementById('modalSalas');
        const titulo = document.getElementById('tituloSalas');
        const resultado = document.getElementById('resultadoSalas');
        
        if (tipo === 'livres') {
            titulo.innerHTML = '<i class="fas fa-door-open"></i> Salas Livres';
            resultado.innerHTML = '<div class="empty-state"><div class="empty-icon"><i class="fas fa-spinner fa-spin"></i></div><p>Carregando salas livres...</p></div>';
            fetch('salas_status.php?tipo=livres')
                .then(response => response.text())
                .then(data => resultado.innerHTML = data)
                .catch(() => resultado.innerHTML = '<div class="empty-state"><div class="empty-icon"><i class="fas fa-exclamation-triangle"></i></div><p>Erro ao carregar salas livres.</p></div>');
        } else if (tipo === 'ocupadas') {
            titulo.innerHTML = '<i class="fas fa-door-closed"></i> Salas Ocupadas';
            resultado.innerHTML = '<div class="empty-state"><div class="empty-icon"><i class="fas fa-spinner fa-spin"></i></div><p>Carregando salas ocupadas...</p></div>';
            fetch('salas_status.php?tipo=ocupadas')
                .then(response => response.text())
                .then(data => resultado.innerHTML = data)
                .catch(() => resultado.innerHTML = '<div class="empty-state"><div class="empty-icon"><i class="fas fa-exclamation-triangle"></i></div><p>Erro ao carregar salas ocupadas.</p></div>');
        }
        
        modal.style.display = 'flex';
    }

    function fecharModalSalas() {
        document.getElementById('modalSalas').style.display = 'none';
    }

    // =========================================================
    // FUNÇÕES DO MODAL HORÁRIOS (USANDO listar_horario_visual.php)
    // =========================================================
    function abrirModalHorarios() {
        document.getElementById('modalHorarios').style.display = 'flex';
        document.getElementById('resultadoHorarios').innerHTML = '';
        // Resetar os filtros
        document.getElementById('tipoHorario').value = '';
        document.getElementById('filtros').style.display = 'none';
    }

    function fecharModalHorarios() {
        document.getElementById('modalHorarios').style.display = 'none';
    }

    function mostrarFiltros() {
        const tipo = document.getElementById('tipoHorario').value;
        const filtros = document.getElementById('filtros');
        if (tipo) {
            filtros.style.display = 'block';
        } else {
            filtros.style.display = 'none';
            document.getElementById('resultadoHorarios').innerHTML = '';
        }
    }

    function buscarHorarios() {
        const tipo = document.getElementById('tipoHorario').value;
        const curso = document.getElementById('curso').value;
        const ano = document.getElementById('ano').value;
        const semestre = document.getElementById('semestre').value;
        const turno = document.getElementById('turno').value;
        
        if (!tipo) {
            showToast('Selecione um tipo de horário primeiro.', 'warning');
            return;
        }
        
        const resultado = document.getElementById('resultadoHorarios');
        resultado.innerHTML = '<div class="empty-state"><div class="empty-icon"><i class="fas fa-spinner fa-spin"></i></div><p>Carregando horários...</p></div>';
        
        // Construir a URL com os parâmetros
        const params = new URLSearchParams({
            tipo: tipo,
            curso: curso,
            ano: ano,
            semestre: semestre,
            turno: turno
        });
        
        // Usar o arquivo existente listar_horario_visual.php
        fetch(`listar_horario_visual.php?${params.toString()}`)
            .then(response => response.text())
            .then(data => {
                // Verificar se a resposta contém erro
                if (data.includes('Sem horário disponível ainda')) {
                    resultado.innerHTML = `
                        <div class="empty-state">
                            <div class="empty-icon"><i class="fas fa-search"></i></div>
                            <p>Nenhum horário encontrado com os filtros selecionados.</p>
                        </div>
                    `;
                } else {
                    resultado.innerHTML = data;
                }
            })
            .catch(() => {
                resultado.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-icon"><i class="fas fa-exclamation-triangle"></i></div>
                        <p>Erro ao carregar horários. Tente novamente.</p>
                    </div>
                `;
            });
    }

    // =========================================================
    // FUNÇÕES DO MODAL CALENDÁRIO
    // =========================================================
    function abrirModalCalendario() {
        document.getElementById('modalCalendario').style.display = 'flex';
    }

    function fecharModalCalendario() {
        document.getElementById('modalCalendario').style.display = 'none';
    }

    // =========================================================
    // FECHAR MODAIS CLICANDO FORA
    // =========================================================
    window.onclick = function(event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        });
    }

    // =========================================================
    // MOSTRAR MENSAGENS DA SESSÃO
    // =========================================================
    document.addEventListener('DOMContentLoaded', function() {
        <?php if (isset($_SESSION['success_message']) && !empty($_SESSION['success_message'])): ?>
            showToast('<?= addslashes($_SESSION['success_message']) ?>', 'success');
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message']) && !empty($_SESSION['error_message'])): ?>
            showToast('<?= addslashes($_SESSION['error_message']) ?>', 'error');
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>
        <?php if (isset($_SESSION['warning_message']) && !empty($_SESSION['warning_message'])): ?>
            showToast('<?= addslashes($_SESSION['warning_message']) ?>', 'warning');
            <?php unset($_SESSION['warning_message']); ?>
        <?php endif; ?>
    });
</script>
</body>
</html>