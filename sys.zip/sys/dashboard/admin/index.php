<?php
session_start();
require_once '../../config/database.php';
if (!isset($_SESSION['user'])) {
    header('Location: ../../public/index.php');
    exit;
}
$user = $_SESSION['user'];

if (!isset($user['role']) || $user['role'] !== 'admin') {
    header('Location: ../dashboard.php');
    exit;
}

// Seleciona todas as reservas
$reservas = $conn->query("
    SELECT
        id,
        docente_nome,
        curso,
        disciplina,
        turno,
        sala,
        dia_semana,
        data,
        hora_inicio,
        hora_fim,
        finalidade,
        estado
    FROM reservas
    ORDER BY data DESC, hora_inicio DESC
") or die("Erro na query: " . $conn->error);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Admin - SMARTKAMPUS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="../../public/assets/imgs/smartkampus-logo.png">
    <style>
        /* =========================================================
           VARIÁVEIS GLOBAIS (Consistência com dashboard.css)
           ========================================================= */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap');

        :root {
            --primary: #3b43ce;
            --primary-hover: #2f36b5;
            --success: #10b981;
            --success-hover: #059669;
            --warning: #f59e0b;
            --danger: #ef4444;
            --purple: #8b5cf6;
            --bg-body: #f8fafc;
            --bg-card: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.06);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.025);
            --radius: 12px;
        }

        /* =========================================================
           RESET GLOBAL
           ========================================================= */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        body {
            background-color: var(--bg-body);
            color: var(--text-main);
            line-height: 1.5;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* =========================================================
           HEADER (Consistente com o Dashboard)
           ========================================================= */
        .header {
            background: var(--bg-card);
            padding: 0 2rem;
            box-shadow: var(--shadow-sm);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            height: 80px;
        }

        .logo-container {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .logo-img {
            height: 40px;
            width: auto;
            transition: transform 0.2s ease;
        }

        .logo-img:hover {
            transform: scale(1.05);
        }

        .logo-text {
            font-family: 'Bebas Neue', sans-serif;
            font-size: 1.75rem;
            font-weight: 400;
            color: var(--primary);
            letter-spacing: 0.5px;
            line-height: 1;
        }

        .nav-links {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .nav-button {
            display: flex;
            align-items: center;
            gap: 8px;
            background: transparent;
            border: none;
            color: var(--text-muted);
            font-size: 0.9rem;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
        }

        .nav-button:hover {
            background-color: #f1f5f9;
            color: var(--primary);
        }

        .nav-button.logout {
            color: var(--danger);
        }

        .nav-button.logout:hover {
            background-color: #fee2e2;
        }

        /* =========================================================
           CONTEÚDO PRINCIPAL
           ========================================================= */
        .container {
            flex: 1;
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
            width: 100%;
        }

        .page-title {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--text-main);
            margin-bottom: 2rem;
            letter-spacing: -0.025em;
        }

        /* =========================================================
           BOTÕES DE AÇÃO PRINCIPAIS (Estilo Card Moderno)
           ========================================================= */
        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .action-button {
            display: flex;
            align-items: center;
            gap: 1rem;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-top: 4px solid transparent;
            border-radius: var(--radius);
            padding: 1.5rem;
            font-size: 1rem;
            font-weight: 600;
            color: var(--text-main);
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: var(--shadow-sm);
            text-align: left;
        }

        .action-button:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
            border-color: transparent;
        }

        .action-button.gerir { border-top-color: var(--primary); }
        .action-button.reservas { border-top-color: var(--success); }
        .action-button.calendario { border-top-color: var(--purple); }

        .button-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            color: white;
            flex-shrink: 0;
        }

        .button-icon.gerir { background: linear-gradient(135deg, var(--primary), #6366f1); }
        .button-icon.reservas { background: linear-gradient(135deg, var(--success), #34d399); }
        .button-icon.calendario { background: linear-gradient(135deg, var(--purple), #a78bfa); }

        /* =========================================================
           MODAIS
           ========================================================= */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(4px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.2s ease;
            overflow-y: auto;
            padding: 1rem;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { transform: translateY(15px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .modal-content {
            background: var(--bg-card);
            border-radius: var(--radius);
            padding: 1.5rem 2rem;
            width: 100%;
            max-width: 500px;
            box-shadow: var(--shadow-lg);
            animation: slideUp 0.3s ease;
            max-height: 85vh;
            overflow-y: auto;
        }

        .modal-content.large {
            max-width: 900px;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .modal-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-main);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .close-modal {
            background: none;
            border: none;
            font-size: 1.25rem;
            color: var(--text-muted);
            cursor: pointer;
            width: 36px;
            height: 36px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        }

        .close-modal:hover {
            background: #f1f5f9;
            color: var(--text-main);
        }

        .modal-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-top: 1.5rem;
        }

        .modal-btn {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.625rem 1.25rem;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            background: var(--bg-card);
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            font-size: 0.875rem;
            color: var(--text-main);
            text-decoration: none;
        }

        .modal-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .modal-btn.primary {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .modal-btn.primary:hover {
            background: var(--primary-hover);
            border-color: var(--primary-hover);
        }

        .modal-btn.secondary {
            background: #f1f5f9;
            color: var(--text-main);
        }

        .modal-btn.secondary:hover {
            background: #e2e8f0;
        }

        .modal-btn.cancel {
            background: #fee2e2;
            color: #dc2626;
            border-color: #fee2e2;
        }

        .modal-btn.cancel:hover {
            background: #fecaca;
            border-color: #fecaca;
        }

        .modal-btn.approve {
            background: #d1fae5;
            color: #065f46;
            border-color: #d1fae5;
        }

        .modal-btn.approve:hover {
            background: #a7f3d0;
            border-color: #a7f3d0;
        }

        .modal-btn.reject {
            background: #fee2e2;
            color: #991b1b;
            border-color: #fee2e2;
        }

        .modal-btn.reject:hover {
            background: #fecaca;
            border-color: #fecaca;
        }

        .modal-btn.delete {
            background: #f1f5f9;
            color: #475569;
            border-color: #f1f5f9;
        }

        .modal-btn.delete:hover {
            background: #e2e8f0;
            border-color: #e2e8f0;
        }

        /* =========================================================
           TABELAS
           ========================================================= */
        .table-container {
            overflow-x: auto;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            margin-top: 1rem;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            min-width: 1000px;
            background: var(--bg-card);
        }

        thead {
            background: #f8fafc;
        }

        th {
            padding: 0.75rem 1rem;
            text-align: left;
            font-weight: 600;
            color: var(--text-muted);
            border-bottom: 1px solid var(--border-color);
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        td {
            padding: 0.75rem 1rem;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-main);
            font-size: 0.875rem;
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover td {
            background-color: #f8fafc;
        }

        /* =========================================================
           BOTÕES DE AÇÃO NA TABELA
           ========================================================= */
        .action-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .btn {
            padding: 0.375rem 0.75rem;
            border-radius: 6px;
            border: none;
            font-weight: 500;
            font-size: 0.75rem;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.375rem;
        }

        .btn-approve { background: #d1fae5; color: #065f46; }
        .btn-approve:hover { background: #a7f3d0; }

        .btn-reject { background: #fee2e2; color: #991b1b; }
        .btn-reject:hover { background: #fecaca; }

        .btn-cancel { background: #fef3c7; color: #92400e; }
        .btn-cancel:hover { background: #fde68a; }

        .btn-delete { background: #f1f5f9; color: #475569; }
        .btn-delete:hover { background: #e2e8f0; }

        /* =========================================================
           STATUS BADGES
           ========================================================= */
        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.75rem;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .status-pendente { background: #fef3c7; color: #92400e; }
        .status-aprovada { background: #d1fae5; color: #065f46; }
        .status-rejeitada { background: #fee2e2; color: #991b1b; }

        /* =========================================================
           UPLOAD DE CALENDÁRIO
           ========================================================= */
        .upload-container {
            border: 2px dashed #c7d2fe;
            border-radius: var(--radius);
            padding: 2rem;
            text-align: center;
            background: #f8fafc;
            margin-top: 1rem;
        }

        .upload-icon {
            font-size: 2rem;
            color: var(--primary);
            margin-bottom: 0.75rem;
        }

        .upload-container p {
            color: var(--text-muted);
            font-size: 0.875rem;
            margin-bottom: 1rem;
        }

        .upload-button {
            background: var(--primary);
            color: white;
            border: none;
            padding: 0.625rem 1.25rem;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.875rem;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
        }

        .upload-button:hover {
            background: var(--primary-hover);
            transform: translateY(-1px);
        }

        /* =========================================================
           ESTADO VAZIO
           ========================================================= */
        .empty-state {
            text-align: center;
            padding: 2rem 1rem;
            color: var(--text-muted);
        }

        .empty-icon {
            font-size: 2.5rem;
            color: #cbd5e1;
            margin-bottom: 0.75rem;
        }

        .empty-state p {
            font-size: 0.9rem;
        }

        /* =========================================================
           FOOTER
           ========================================================= */
        .footer {
            background: #0f172a;
            color: #cbd5e1;
            text-align: center;
            padding: 1.5rem;
            margin-top: auto;
            font-size: 0.875rem;
        }

        .footer-logo {
            font-family: 'Bebas Neue', sans-serif;
            font-size: 1.2rem;
            letter-spacing: 0.5px;
            color: #ffffff;
        }

        /* =========================================================
           TOAST NOTIFICATIONS (Mesmas do painel do docente)
           ========================================================= */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 10px;
            max-width: 350px;
            width: 100%;
            pointer-events: none;
        }

        .toast {
            background: white;
            border-radius: 12px;
            padding: 1rem 1.25rem;
            box-shadow: var(--shadow-lg);
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            animation: toastSlideIn 0.3s ease forwards;
            pointer-events: auto;
            border-left: 4px solid transparent;
            margin-bottom: 0.5rem;
            position: relative;
            overflow: hidden;
        }

        @keyframes toastSlideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes toastSlideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }

        .toast.fade-out { animation: toastSlideOut 0.3s ease forwards; }

        .toast-success { border-left-color: var(--success); }
        .toast-success .toast-icon { background: var(--success); }
        
        .toast-error { border-left-color: var(--danger); }
        .toast-error .toast-icon { background: var(--danger); }
        
        .toast-warning { border-left-color: var(--warning); }
        .toast-warning .toast-icon { background: var(--warning); }
        
        .toast-info { border-left-color: #3b82f6; }
        .toast-info .toast-icon { background: #3b82f6; }

        .toast-icon {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            color: white;
            flex-shrink: 0;
        }

        .toast-content { flex: 1; }

        .toast-title {
            font-weight: 600;
            font-size: 0.95rem;
            color: var(--text-main);
            margin-bottom: 0.25rem;
        }

        .toast-message {
            font-size: 0.85rem;
            color: var(--text-muted);
            line-height: 1.4;
        }

        .toast-close {
            background: transparent;
            border: none;
            color: #94a3b8;
            cursor: pointer;
            font-size: 1rem;
            padding: 0.25rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            transition: all 0.2s ease;
            flex-shrink: 0;
        }

        .toast-close:hover { background: #f1f5f9; color: var(--text-muted); }

        .toast-progress {
            position: absolute;
            bottom: 0;
            left: 0;
            height: 3px;
            border-radius: 0 0 0 12px;
            animation: progress 5s linear forwards;
        }

        @keyframes progress {
            from { width: 100%; }
            to { width: 0%; }
        }

        .toast-success .toast-progress { background: var(--success); }
        .toast-error .toast-progress { background: var(--danger); }
        .toast-warning .toast-progress { background: var(--warning); }
        .toast-info .toast-progress { background: #3b82f6; }

        /* =========================================================
           FORM ACTIONS (para os modais de confirmação)
           ========================================================= */
        .form-actions {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--border-color);
        }

        .modal-message {
            margin: 1rem 0;
            color: var(--text-muted);
            line-height: 1.6;
        }

        .modal-message strong {
            color: var(--text-main);
        }

        /* =========================================================
           RESPONSIVIDADE
           ========================================================= */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                height: auto;
                padding: 1rem 0;
                gap: 1rem;
            }

            .logo-container {
                flex-direction: row;
                text-align: center;
            }

            .nav-links {
                flex-wrap: wrap;
                justify-content: center;
            }

            .container {
                padding: 0 1rem;
                margin: 1rem auto;
            }

            .page-title {
                font-size: 1.5rem;
                text-align: center;
            }

            .actions-grid {
                grid-template-columns: 1fr;
            }

            .modal-content {
                padding: 1.25rem;
                max-width: 100%;
                margin: 1rem;
            }

            .modal-buttons {
                flex-direction: column;
            }

            .modal-btn {
                width: 100%;
                justify-content: center;
            }

            .toast-container {
                top: 10px;
                right: 10px;
                left: 10px;
                max-width: none;
            }

            .form-actions {
                flex-direction: column;
            }
            
            .form-actions .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-content">
            <div class="logo-container">
                <img src="../../public/assets/imgs/smartkampus-logo.png" alt="Logo" class="logo-img">
                <span class="logo-text">SMARTKAMPUS</span>
            </div>
            <div class="nav-links">
                <a href="../dashboard.php" class="nav-button">
                    <i class="fas fa-home"></i>
                    <span>Painel Principal</span>
                </a>
                <a href="../../public/logout.php" class="nav-button logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Sair</span>
                </a>
            </div>
        </div>
    </header>

    <!-- Conteúdo principal -->
    <main class="container">
        <h2 class="page-title">Painel do Administrador</h2>
        
        <div class="actions-grid">
            <button class="action-button gerir" onclick="abrirModalGerir()">
                <div class="button-icon gerir">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <span>Gerir horários</span>
            </button>
            <button class="action-button reservas" onclick="abrirModalReservas()">
                <div class="button-icon reservas">
                    <i class="fas fa-clock"></i>
                </div>
                <span>Gerir reservas</span>
            </button>
            <button class="action-button calendario" onclick="abrirModalCalendario()">
                <div class="button-icon calendario">
                    <i class="fas fa-calendar-day"></i>
                </div>
                <span>Calendário Académico</span>
            </button>
        </div>

        <!-- MODAL 1: GERIR -->
        <div id="modalGerir" class="modal">
            <div class="modal-content large">
                <div class="modal-header">
                    <h2 class="modal-title">
                        <i class="fas fa-calendar-alt" style="color: var(--primary);"></i>
                        Gerir Horários
                    </h2>
                    <button class="close-modal" onclick="fecharTodos()" aria-label="Fechar modal">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-buttons">
                    <button class="modal-btn primary" onclick="abrirModalTipo('criar')">
                        <i class="fas fa-plus-circle"></i>
                        Criar horários
                    </button>
                    <button class="modal-btn secondary" onclick="abrirModalTipo('ver')">
                        <i class="fas fa-eye"></i>
                        Ver horários
                    </button>
                </div>
            </div>
        </div>

        <!-- MODAL 2: TIPO -->
        <div id="modalTipo" class="modal">
            <div class="modal-content large">
                <div class="modal-header">
                    <h2 class="modal-title">
                        <i class="fas fa-list-alt" style="color: var(--primary);"></i>
                        Tipo de horário
                    </h2>
                    <button class="close-modal" onclick="fecharTodos()" aria-label="Fechar modal">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <h3 style="font-size: 1rem; font-weight: 600; color: var(--text-main); margin-bottom: 1rem;">Selecione o tipo de horário</h3>
                <div class="modal-buttons">
                    <button class="modal-btn primary" onclick="redirecionar('aula')">
                        <i class="fas fa-chalkboard-teacher"></i>
                        Aula
                    </button>
                    <button class="modal-btn primary" style="background: var(--success); border-color: var(--success);" onclick="redirecionar('teste')">
                        <i class="fas fa-edit"></i>
                        Teste
                    </button>
                    <button class="modal-btn primary" style="background: var(--purple); border-color: var(--purple);" onclick="redirecionar('exame')">
                        <i class="fas fa-file-alt"></i>
                        Exame
                    </button>
                    <button class="modal-btn cancel" onclick="fecharTodos()">
                        <i class="fas fa-times"></i>
                        Fechar
                    </button>
                </div>
            </div>
        </div>

        <!-- MODAL 3: GERIR RESERVAS -->
        <div id="modalReservas" class="modal">
            <div class="modal-content large">
                <div class="modal-header">
                    <h2 class="modal-title">
                        <i class="fas fa-clock" style="color: var(--success);"></i>
                        Gerir Reservas
                    </h2>
                    <button class="close-modal" onclick="fecharTodos()" aria-label="Fechar modal">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <?php if ($reservas && $reservas->num_rows > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Docente</th>
                                    <th>Curso</th>
                                    <th>Sala</th>
                                    <th>Disciplina</th>
                                    <th>Turno</th>
                                    <th>Dia</th>
                                    <th>Data</th>
                                    <th>Hora</th>
                                    <th>Finalidade</th>
                                    <th>Estado</th>
                                    <th>Ação</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($r = $reservas->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($r['docente_nome']) ?></td>
                                    <td><?= htmlspecialchars($r['curso']) ?></td>
                                    <td><strong><?= htmlspecialchars($r['sala']) ?></strong></td>
                                    <td><?= htmlspecialchars($r['disciplina']) ?></td>
                                    <td><?= htmlspecialchars($r['turno']) ?></td>
                                    <td><?= htmlspecialchars($r['dia_semana']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($r['data'])) ?></td>
                                    <td><?= substr($r['hora_inicio'],0,5) ?> - <?= substr($r['hora_fim'],0,5) ?></td>
                                    <td><?= htmlspecialchars($r['finalidade'] ?: '-') ?></td>
                                    <td>
                                        <span class="status-badge status-<?= $r['estado'] ?>">
                                            <?= ucfirst($r['estado']) ?>
                                        </span>
                                    </td>
                                    <td class="action-buttons">
                                        <?php if ($r['estado'] === 'pendente'): ?>
                                            <button type="button" class="btn btn-approve" onclick="abrirModalAprovar(<?= $r['id'] ?>, '<?= htmlspecialchars($r['docente_nome']) ?>')">
                                                <i class="fas fa-check"></i> Aprovar
                                            </button>
                                            <button type="button" class="btn btn-reject" onclick="abrirModalRejeitar(<?= $r['id'] ?>, '<?= htmlspecialchars($r['docente_nome']) ?>')">
                                                <i class="fas fa-times"></i> Rejeitar
                                            </button>
                                        <?php elseif ($r['estado'] === 'aprovada'): ?>
                                            <button type="button" class="btn btn-cancel" onclick="abrirModalCancelarAdmin(<?= $r['id'] ?>, '<?= htmlspecialchars($r['docente_nome']) ?>')">
                                                <i class="fas fa-ban"></i> Cancelar
                                            </button>
                                        <?php elseif ($r['estado'] === 'rejeitada'): ?>
                                            <button type="button" class="btn btn-delete" onclick="abrirModalExcluir(<?= $r['id'] ?>, '<?= htmlspecialchars($r['docente_nome']) ?>')">
                                                <i class="fas fa-trash"></i> Excluir
                                            </button>
                                        <?php else: ?>
                                            <span style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted);"><?= strtoupper($r['estado']) ?></span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon">
                            <i class="far fa-calendar-times"></i>
                        </div>
                        <p>Sem reservas registadas.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ========================================================= -->
        <!-- MODAIS DE CONFIRMAÇÃO (Estilo consistente)                -->
        <!-- ========================================================= -->

        <!-- MODAL CONFIRMAR APROVAÇÃO -->
        <div id="modalAprovar" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">
                        <i class="fas fa-check-circle" style="color: var(--success);"></i>
                        Confirmar Aprovação
                    </h2>
                    <button class="close-modal" onclick="fecharModalAprovar()" aria-label="Fechar modal">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <p class="modal-message">
                    Deseja aprovar a reserva de <strong id="nomeDocenteAprovar"></strong>?<br>
                    A sala será reservada para o docente.
                </p>
                <form method="POST" action="reserva/gerir_reserva.php" id="formAprovar">
                    <input type="hidden" name="id" id="reservaIdAprovar">
                    <input type="hidden" name="acao" value="aprovar">
                    <div class="form-actions">
                        <button type="submit" class="modal-btn approve" style="padding: 0.625rem 1.25rem; border-radius: 8px; border: none; font-weight: 500; font-size: 0.875rem; cursor: pointer; transition: all 0.2s ease; display: inline-flex; align-items: center; gap: 0.5rem; background: #d1fae5; color: #065f46;">
                            <i class="fas fa-check"></i>
                            Sim, Aprovar
                        </button>
                        <button type="button" class="modal-btn secondary" onclick="fecharModalAprovar()">
                            <i class="fas fa-times"></i>
                            Cancelar
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- MODAL CONFIRMAR REJEIÇÃO -->
        <div id="modalRejeitar" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">
                        <i class="fas fa-times-circle" style="color: var(--danger);"></i>
                        Confirmar Rejeição
                    </h2>
                    <button class="close-modal" onclick="fecharModalRejeitar()" aria-label="Fechar modal">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <p class="modal-message">
                    Deseja rejeitar a reserva de <strong id="nomeDocenteRejeitar"></strong>?<br>
                    O docente será notificado que a reserva foi rejeitada.
                </p>
                <form method="POST" action="reserva/gerir_reserva.php" id="formRejeitar">
                    <input type="hidden" name="id" id="reservaIdRejeitar">
                    <input type="hidden" name="acao" value="rejeitar">
                    <div class="form-actions">
                        <button type="submit" class="modal-btn reject" style="padding: 0.625rem 1.25rem; border-radius: 8px; border: none; font-weight: 500; font-size: 0.875rem; cursor: pointer; transition: all 0.2s ease; display: inline-flex; align-items: center; gap: 0.5rem; background: #fee2e2; color: #991b1b;">
                            <i class="fas fa-times"></i>
                            Sim, Rejeitar
                        </button>
                        <button type="button" class="modal-btn secondary" onclick="fecharModalRejeitar()">
                            <i class="fas fa-times"></i>
                            Cancelar
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- MODAL CONFIRMAR CANCELAMENTO -->
        <div id="modalCancelarAdmin" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">
                        <i class="fas fa-exclamation-triangle" style="color: var(--warning);"></i>
                        Confirmar Cancelamento
                    </h2>
                    <button class="close-modal" onclick="fecharModalCancelarAdmin()" aria-label="Fechar modal">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <p class="modal-message">
                    Tem certeza que deseja cancelar a reserva de <strong id="nomeDocenteCancelar"></strong>?<br>
                    <strong>Esta ação não pode ser desfeita.</strong>
                </p>
                <form method="POST" action="reserva/cancelar_reserva.php" id="formCancelarAdmin">
                    <input type="hidden" name="id" id="reservaIdCancelarAdmin">
                    <div class="form-actions">
                        <button type="submit" class="modal-btn cancel" style="padding: 0.625rem 1.25rem; border-radius: 8px; border: none; font-weight: 500; font-size: 0.875rem; cursor: pointer; transition: all 0.2s ease; display: inline-flex; align-items: center; gap: 0.5rem; background: #fef3c7; color: #92400e;">
                            <i class="fas fa-ban"></i>
                            Sim, Cancelar
                        </button>
                        <button type="button" class="modal-btn secondary" onclick="fecharModalCancelarAdmin()">
                            <i class="fas fa-times"></i>
                            Voltar
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- MODAL CONFIRMAR EXCLUSÃO -->
        <div id="modalExcluir" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">
                        <i class="fas fa-trash-alt" style="color: var(--danger);"></i>
                        Confirmar Exclusão
                    </h2>
                    <button class="close-modal" onclick="fecharModalExcluir()" aria-label="Fechar modal">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <p class="modal-message">
                    Deseja excluir permanentemente a reserva rejeitada de <strong id="nomeDocenteExcluir"></strong>?<br>
                    <strong>Esta ação não pode ser desfeita.</strong>
                </p>
                <form method="POST" action="reserva/excluir_reserva.php" id="formExcluir">
                    <input type="hidden" name="id" id="reservaIdExcluir">
                    <div class="form-actions">
                        <button type="submit" class="modal-btn delete" style="padding: 0.625rem 1.25rem; border-radius: 8px; border: none; font-weight: 500; font-size: 0.875rem; cursor: pointer; transition: all 0.2s ease; display: inline-flex; align-items: center; gap: 0.5rem; background: #f1f5f9; color: #475569;">
                            <i class="fas fa-trash"></i>
                            Sim, Excluir
                        </button>
                        <button type="button" class="modal-btn secondary" onclick="fecharModalExcluir()">
                            <i class="fas fa-times"></i>
                            Cancelar
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- MODAL 4: CALENDÁRIO ACADÉMICO -->
        <div id="modalCalendario" class="modal">
            <div class="modal-content large">
                <div class="modal-header">
                    <h2 class="modal-title">
                        <i class="fas fa-calendar-day" style="color: var(--purple);"></i>
                        Calendário Académico
                    </h2>
                    <button class="close-modal" onclick="fecharTodos()" aria-label="Fechar modal">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <?php
                $cal = $conn->query("SELECT * FROM calendario_academico ORDER BY data_publicacao DESC LIMIT 1");
                ?>
                <?php if ($cal && $cal->num_rows > 0):
                    $c = $cal->fetch_assoc();
                ?>
                    <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 1rem; margin-bottom: 1rem; display: flex; align-items: center; gap: 1rem;">
                        <i class="fas fa-calendar-check" style="color: #166534; font-size: 1.25rem;"></i>
                        <div>
                            <h3 style="color: #166534; font-size: 0.95rem; font-weight: 600; margin-bottom: 0.25rem;">Calendário Académico Atual</h3>
                            <p style="color: #15803d; font-size: 0.875rem;">Publicado em: <?= date('d/m/Y H:i', strtotime($c['data_publicacao'])) ?></p>
                        </div>
                    </div>
                    
                    <div class="upload-container">
                        <div class="upload-icon">
                            <i class="far fa-calendar-check"></i>
                        </div>
                        <p>Calendário académico disponível para visualização e download</p>
                        <a href="../../public/uploads/calendario/<?= $c['caminho'] ?>" target="_blank" class="upload-button">
                            <i class="fas fa-external-link-alt"></i>
                            Ver Calendário
                        </a>
                    </div>
                    
                    <div class="modal-buttons">
                        <form method="POST" action="calendario/exluir_calendario.php" onsubmit="return confirm('Deseja excluir o calendário académico?')">
                            <input type="hidden" name="id" value="<?= $c['id'] ?>">
                            <button type="submit" class="modal-btn cancel">
                                <i class="fas fa-trash"></i>
                                Excluir Calendário
                            </button>
                        </form>
                        <button class="modal-btn secondary" onclick="fecharTodos()">
                            <i class="fas fa-times"></i>
                            Fechar
                        </button>
                    </div>
                <?php else: ?>
                    <div class="upload-container">
                        <div class="upload-icon">
                            <i class="fas fa-cloud-upload-alt"></i>
                        </div>
                        <p>Faça upload do calendário académico em formato PDF</p>
                        <form method="POST" action="calendario/upload_calendario.php" enctype="multipart/form-data" style="margin-top: 1rem;">
                            <input type="file" name="calendario_pdf" accept="application/pdf" required style="padding: 0.75rem; border: 1px solid var(--border-color); border-radius: 8px; width: 100%; max-width: 400px; font-size: 0.875rem; background: white;">
                            <br><br>
                            <button type="submit" class="upload-button">
                                <i class="fas fa-upload"></i>
                                Publicar Calendário
                            </button>
                        </form>
                    </div>
                    <div class="modal-buttons">
                        <button class="modal-btn secondary" onclick="fecharTodos()">
                            <i class="fas fa-times"></i>
                            Fechar
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <p>© 2026 <span class="footer-logo">SMARTKAMPUS</span> • Universidade Católica de Moçambique</p>
    </footer>

    <!-- Toast Notifications (Mesmas do painel do docente) -->
    <div class="toast-container" id="toastContainer"></div>

    <script>
        // =========================================================
        // FUNÇÕES DE MODAL
        // =========================================================
        let acao = null;
        function abrirModalGerir() {
            document.getElementById('modalGerir').style.display = 'flex';
        }
        function abrirModalReservas() {
            document.getElementById('modalReservas').style.display = 'flex';
        }
        function abrirModalTipo(tipoAcao) {
            acao = tipoAcao;
            document.getElementById('modalGerir').style.display = 'none';
            document.getElementById('modalTipo').style.display = 'flex';
        }
        function abrirModalCalendario() {
            document.getElementById('modalCalendario').style.display = 'flex';
        }
        function fecharTodos() {
            document.getElementById('modalGerir').style.display = 'none';
            document.getElementById('modalTipo').style.display = 'none';
            document.getElementById('modalReservas').style.display = 'none';
            document.getElementById('modalCalendario').style.display = 'none';
            document.getElementById('modalAprovar').style.display = 'none';
            document.getElementById('modalRejeitar').style.display = 'none';
            document.getElementById('modalCancelarAdmin').style.display = 'none';
            document.getElementById('modalExcluir').style.display = 'none';
        }
        function redirecionar(tipo) {
            if (acao === 'criar') {
                if (tipo === 'aula')   window.location = 'horarios/aulas/criar_horario.php';
                if (tipo === 'teste')  window.location = 'horarios/testes/criar_teste.php';
                if (tipo === 'exame')  window.location = 'horarios/exames/criar_exame.php';
            }
            if (acao === 'ver') {
                if (tipo === 'aula')   window.location = 'horarios/aulas/listar_horarios.php';
                if (tipo === 'teste')  window.location = 'horarios/testes/listar_testes.php';
                if (tipo === 'exame')  window.location = 'horarios/exames/listar_exames.php';
            }
        }

        // =========================================================
        // MODAL DE APROVAÇÃO
        // =========================================================
        function abrirModalAprovar(reservaId, nomeDocente) {
            document.getElementById('reservaIdAprovar').value = reservaId;
            document.getElementById('nomeDocenteAprovar').textContent = nomeDocente || 'este docente';
            document.getElementById('modalAprovar').style.display = 'flex';
        }

        function fecharModalAprovar() {
            document.getElementById('modalAprovar').style.display = 'none';
        }

        // =========================================================
        // MODAL DE REJEIÇÃO
        // =========================================================
        function abrirModalRejeitar(reservaId, nomeDocente) {
            document.getElementById('reservaIdRejeitar').value = reservaId;
            document.getElementById('nomeDocenteRejeitar').textContent = nomeDocente || 'este docente';
            document.getElementById('modalRejeitar').style.display = 'flex';
        }

        function fecharModalRejeitar() {
            document.getElementById('modalRejeitar').style.display = 'none';
        }

        // =========================================================
        // MODAL DE CANCELAMENTO (Admin)
        // =========================================================
        function abrirModalCancelarAdmin(reservaId, nomeDocente) {
            document.getElementById('reservaIdCancelarAdmin').value = reservaId;
            document.getElementById('nomeDocenteCancelar').textContent = nomeDocente || 'este docente';
            document.getElementById('modalCancelarAdmin').style.display = 'flex';
        }

        function fecharModalCancelarAdmin() {
            document.getElementById('modalCancelarAdmin').style.display = 'none';
        }

        // =========================================================
        // MODAL DE EXCLUSÃO
        // =========================================================
        function abrirModalExcluir(reservaId, nomeDocente) {
            document.getElementById('reservaIdExcluir').value = reservaId;
            document.getElementById('nomeDocenteExcluir').textContent = nomeDocente || 'este docente';
            document.getElementById('modalExcluir').style.display = 'flex';
        }

        function fecharModalExcluir() {
            document.getElementById('modalExcluir').style.display = 'none';
        }

        // =========================================================
        // TOAST NOTIFICATIONS (Mesmas do painel do docente)
        // =========================================================
        function showToast(message, type = 'success', duration = 5000) {
            const container = document.getElementById('toastContainer');
            
            if (!message || message.trim() === '') return;
            
            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            
            let icon = 'check-circle';
            let title = 'Sucesso';
            switch(type) {
                case 'error': icon = 'exclamation-circle'; title = 'Erro'; break;
                case 'warning': icon = 'exclamation-triangle'; title = 'Aviso'; break;
                case 'info': icon = 'info-circle'; title = 'Informação'; break;
                default: icon = 'check-circle'; title = 'Sucesso';
            }
            
            toast.innerHTML = `
                <div class="toast-icon"><i class="fas fa-${icon}"></i></div>
                <div class="toast-content">
                    <div class="toast-title">${title}</div>
                    <div class="toast-message">${message}</div>
                </div>
                <button class="toast-close" onclick="this.closest('.toast').remove()"><i class="fas fa-times"></i></button>
                <div class="toast-progress"></div>
            `;
            
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.classList.add('fade-out');
                setTimeout(() => { if (toast.parentNode) toast.remove(); }, 300);
            }, duration);
            
            toast.querySelector('.toast-close').addEventListener('click', () => {
                toast.classList.add('fade-out');
                setTimeout(() => toast.remove(), 300);
            });
        }

        // =========================================================
        // FECHAR MODAIS CLICANDO FORA
        // =========================================================
        window.onclick = function(event) {
            const modals = document.querySelectorAll('.modal');
            modals.forEach(modal => {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            });
        }

        // =========================================================
        // MOSTRAR MENSAGENS DA SESSÃO (COM TOAST)
        // =========================================================
        document.addEventListener('DOMContentLoaded', function() {
            <?php if (isset($_SESSION['success_message']) && !empty($_SESSION['success_message'])): ?>
                showToast('<?= addslashes($_SESSION['success_message']) ?>', 'success');
                <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>
            <?php if (isset($_SESSION['error_message']) && !empty($_SESSION['error_message'])): ?>
                showToast('<?= addslashes($_SESSION['error_message']) ?>', 'error');
                <?php unset($_SESSION['error_message']); ?>
            <?php endif; ?>
            <?php if (isset($_SESSION['warning_message']) && !empty($_SESSION['warning_message'])): ?>
                showToast('<?= addslashes($_SESSION['warning_message']) ?>', 'warning');
                <?php unset($_SESSION['warning_message']); ?>
            <?php endif; ?>
        });
    </script>
</body>
</html>