<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_POST['id'])) {
    $_SESSION['error_message'] = 'ID da reserva não informado.';
    header('Location: ../index.php');
    exit;
}

$id = (int) $_POST['id'];

/* Buscar sala da reserva */
$stmt = $conn->prepare("SELECT sala FROM reservas WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();

if (!$res) {
    $_SESSION['error_message'] = 'Reserva não encontrada.';
    header('Location: ../index.php');
    exit;
}

$sala = $res['sala'];

/* Apagar reserva */
$del = $conn->prepare("DELETE FROM reservas WHERE id = ?");
$del->bind_param("i", $id);

if (!$del->execute()) {
    $_SESSION['error_message'] = 'Erro ao cancelar reserva: ' . $del->error;
    header('Location: ../index.php');
    exit;
}

/* Libertar sala */
$upd = $conn->prepare("UPDATE salas SET estado = 'livre' WHERE nome = ?");
$upd->bind_param("s", $sala);
$upd->execute();

/* Mensagem de sucesso */
$_SESSION['warning_message'] = 'Reserva cancelada com sucesso!';

/* Volta */
header("Location: ../index.php");
exit;