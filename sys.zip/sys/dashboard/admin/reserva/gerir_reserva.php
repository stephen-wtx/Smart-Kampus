<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start(); // <-- ADICIONADO
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_POST['id'], $_POST['acao'])) {
    $_SESSION['error_message'] = 'Dados inválidos para processar a reserva.';
    header('Location: ../index.php');
    exit;
}

$id = (int) $_POST['id'];
$acao = $_POST['acao'];

if ($acao === 'aprovar') {
    $estado = 'aprovada';
} elseif ($acao === 'rejeitar') {
    $estado = 'rejeitada';
} else {
    $_SESSION['error_message'] = 'Ação inválida.';
    header('Location: ../index.php');
    exit;
}

$stmt = $conn->prepare("UPDATE reservas SET estado = ? WHERE id = ?");
if (!$stmt) {
    $_SESSION['error_message'] = 'Erro na query: ' . $conn->error;
    header('Location: ../index.php');
    exit;
}

$stmt->bind_param("si", $estado, $id);

if (!$stmt->execute()) {
    $_SESSION['error_message'] = 'Erro ao executar: ' . $stmt->error;
    header('Location: ../index.php');
    exit;
}

// Define a mensagem de sucesso baseada na ação
if ($acao === 'aprovar') {
    $_SESSION['success_message'] = 'Reserva aprovada com sucesso!';
} else {
    $_SESSION['warning_message'] = 'Reserva rejeitada com sucesso!';
}

header('Location: ../index.php');
exit;