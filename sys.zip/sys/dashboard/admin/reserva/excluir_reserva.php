<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_POST['id'])) {
    $_SESSION['error_message'] = 'ID da reserva não informado.';
    header('Location: ../index.php');
    exit;
}

$id = intval($_POST['id']);

// Buscar a sala da reserva antes de excluir
$stmtSala = $conn->prepare("SELECT sala FROM reservas WHERE id = ? AND estado = 'rejeitada'");
$stmtSala->bind_param("i", $id);
$stmtSala->execute();
$result = $stmtSala->get_result();
$reserva = $result->fetch_assoc();

if (!$reserva) {
    $_SESSION['error_message'] = 'Reserva não encontrada ou não está rejeitada.';
    header('Location: ../index.php');
    exit;
}

$sala = $reserva['sala'];

// Deleta a reserva
$stmt = $conn->prepare("DELETE FROM reservas WHERE id = ? AND estado = 'rejeitada'");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        // Libertar a sala (opcional - se a sala estava ocupada pela reserva rejeitada)
        $upd = $conn->prepare("UPDATE salas SET estado = 'livre' WHERE nome = ?");
        $upd->bind_param("s", $sala);
        $upd->execute();
        
        $_SESSION['success_message'] = 'Reserva rejeitada excluída com sucesso!';
    } else {
        $_SESSION['warning_message'] = 'Nenhuma reserva foi excluída. Verifique se a reserva está rejeitada.';
    }
} else {
    $_SESSION['error_message'] = 'Erro ao excluir reserva: ' . $stmt->error;
}

$stmt->close();
$stmtSala->close();

header('Location: ../index.php');
exit;