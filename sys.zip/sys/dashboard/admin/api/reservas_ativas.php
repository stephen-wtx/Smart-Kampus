<?php
// admin/api/reservas_ativas.php
session_start();
require_once __DIR__ . '/../../config/database.php';

// Verificar autenticação
if (!isset($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autorizado']);
    exit;
}

// Verificar conexão com banco
if (!$conn) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro de conexão com banco de dados']);
    exit;
}

try {
    $query = "
        SELECT 
            id,
            docente_nome,
            curso,
            disciplina,
            sala,
            turno,
            dia_semana,
            data,
            hora_inicio,
            hora_fim,
            finalidade,
            estado
        FROM reservas 
        WHERE estado = 'aprovada' 
        AND data >= CURDATE()
        ORDER BY data ASC, hora_inicio ASC
    ";
    
    $reservas = $conn->query($query);
    
    if (!$reservas) {
        throw new Exception("Erro na query: " . $conn->error);
    }
    
    if ($reservas->num_rows === 0) {
        echo '<div class="empty-state">
                <div class="empty-icon"><i class="far fa-calendar-times"></i></div>
                <p>Nenhuma reserva ativa encontrada.</p>
              </div>';
        exit;
    }
    
    $hoje = date('Y-m-d');
    $agora = date('H:i:s');
    
    while ($r = $reservas->fetch_assoc()):
        $ocupado_agora = ($r['data'] == $hoje && $agora >= $r['hora_inicio'] && $agora <= $r['hora_fim']);
    ?>
        <div class="event-card <?= $ocupado_agora ? 'ocupado' : '' ?>" 
             data-curso="<?= htmlspecialchars($r['curso']) ?>" 
             data-data="<?= $r['data'] ?>">
            <div class="event-header">
                <span class="event-sala">
                    <i class="fas fa-door-open"></i>
                    <?= htmlspecialchars($r['sala']) ?>
                </span>
                <span class="event-status">
                    <?= $ocupado_agora ? '🔴 OCUPADA AGORA' : '📅 AGENDADA' ?>
                </span>
            </div>
            <div class="event-details">
                <span><i class="fas fa-calendar-day"></i> <?= date('d/m/Y', strtotime($r['data'])) ?></span>
                <span><i class="fas fa-clock"></i> <?= substr($r['hora_inicio'], 0, 5) ?> - <?= substr($r['hora_fim'], 0, 5) ?></span>
                <span><i class="fas fa-graduation-cap"></i> <?= htmlspecialchars($r['curso']) ?></span>
                <span><i class="fas fa-book"></i> <?= htmlspecialchars($r['disciplina']) ?></span>
            </div>
            <div class="event-docente">
                <i class="fas fa-user"></i>
                <?= htmlspecialchars($r['docente_nome']) ?>
                <?php if ($r['finalidade']): ?>
                    <span style="margin-left: 0.75rem; color: var(--text-muted);">
                        <i class="fas fa-tag"></i> <?= htmlspecialchars($r['finalidade']) ?>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    <?php endwhile; ?>
    
<?php
} catch (Exception $e) {
    // Log do erro (opcional)
    error_log("Erro em reservas_ativas.php: " . $e->getMessage());
    
    // Mostrar mensagem amigável
    echo '<div class="empty-state">
            <div class="empty-icon"><i class="fas fa-exclamation-triangle" style="color: var(--warning);"></i></div>
            <p>Erro ao carregar reservas. Tente novamente mais tarde.</p>
          </div>';
}
?>