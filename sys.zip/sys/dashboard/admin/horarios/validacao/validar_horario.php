<?php
// validar_horario.php
function validarHorario(
    $conn,
    $tipo,
    $dia_semana,
    $data,
    $curso,
    $ano,
    $semestre,
    $turno,
    $sala,
    $hora_inicio,
    $hora_fim,
    $id_ignore = null
) {
    // Determinar tabela
    if ($tipo === 'aula') $tabela = 'horarios';
    elseif ($tipo === 'teste') $tabela = 'testes';
    elseif ($tipo === 'exame') $tabela = 'exames';
    else return "Tipo inválido: $tipo";

    // 1️⃣ Validar dias da semana (Apenas Segunda a Sexta para todos os tipos)
    $diasPermitidos = ['Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira'];
    if (in_array($tipo, ['aula', 'exame', 'teste']) && !in_array($dia_semana, $diasPermitidos)) {
        return "Eventos só podem ser marcados de Segunda a Sexta-feira.";
    }

    // 2️⃣ Validar horário início < fim
    $inicio = new DateTime($hora_inicio);
    $fim    = new DateTime($hora_fim);

    if ($inicio >= $fim) {
        return "O horário de início deve ser menor que o horário de fim.";
    }

    // 3️⃣ Validar apenas limite geral do horário (07:00 às 21:55)
    $inicioMin = ((int)$inicio->format('H')) * 60 + (int)$inicio->format('i');
    $fimMin    = ((int)$fim->format('H')) * 60 + (int)$fim->format('i');

    $limiteInicio = 7 * 60;       // 07:00
    $limiteFim    = 21 * 60 + 55; // 21:55

    if ($inicioMin < $limiteInicio || $fimMin > $limiteFim) {
        return "Os horários devem estar entre 07:00 e 21:55.";
    }

    // Mantém apenas a validação dos nomes dos turnos
    if (!in_array($turno, ['Manhã', 'Tarde', 'Noite'])) {
        return "Turno inválido. Utilize apenas: Manhã, Tarde ou Noite.";
    }

    // Campo de dia/data
    $campoDia = ($tipo === 'aula') ? 'dia_semana' : 'data';
    $valorDia = ($tipo === 'aula') ? $dia_semana : $data;

    // 4️⃣ Conflito de SALA
    if ($id_ignore) {
        $stmt = $conn->prepare("
            SELECT hora_inicio, hora_fim
            FROM $tabela
            WHERE sala = ? AND $campoDia = ? AND id != ?
        ");
        $stmt->bind_param("ssi", $sala, $valorDia, $id_ignore);
    } else {
        $stmt = $conn->prepare("
            SELECT hora_inicio, hora_fim
            FROM $tabela
            WHERE sala = ? AND $campoDia = ?
        ");
        $stmt->bind_param("ss", $sala, $valorDia);
    }

    if (!$stmt) return "Erro SQL sala: " . $conn->error;

    $stmt->execute();
    $res = $stmt->get_result();

    while ($row = $res->fetch_assoc()) {
        $eIni = new DateTime($row['hora_inicio']);
        $eFim = new DateTime($row['hora_fim']);
        $eFim->modify('+1 minute');

        if ($inicio < $eFim && $fim > $eIni) {
            return "Conflito de sala: esta sala já está ocupada nesse horário.";
        }
    }

    // 5️⃣ Conflito Académico (mesmo curso, ano e semestre)
    if ($id_ignore) {
        $stmt = $conn->prepare("
            SELECT hora_inicio, hora_fim
            FROM $tabela
            WHERE $campoDia = ?
              AND curso = ?
              AND ano = ?
              AND semestre = ?
              AND id != ?
        ");
        $stmt->bind_param("ssssi", $valorDia, $curso, $ano, $semestre, $id_ignore);
    } else {
        $stmt = $conn->prepare("
            SELECT hora_inicio, hora_fim
            FROM $tabela
            WHERE $campoDia = ?
              AND curso = ?
              AND ano = ?
              AND semestre = ?
        ");
        $stmt->bind_param("ssss", $valorDia, $curso, $ano, $semestre);
    }

    if (!$stmt) return "Erro SQL académico: " . $conn->error;

    $stmt->execute();
    $res = $stmt->get_result();

    while ($row = $res->fetch_assoc()) {
        $eIni = new DateTime($row['hora_inicio']);
        $eFim = new DateTime($row['hora_fim']);
        $eFim->modify('+1 minute');

        if ($inicio < $eFim && $fim > $eIni) {
            return "Conflito académico: o curso {$curso} ({$ano} {$semestre}) já tem outro evento nesse horário.";
        }
    }

    return null; // Tudo OK
}
?>