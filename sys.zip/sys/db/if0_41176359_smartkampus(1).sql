-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql101.infinityfree.com
-- Generation Time: Jul 06, 2026 at 07:16 AM
-- Server version: 11.4.12-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_41176359_smartkampus`
--

-- --------------------------------------------------------

--
-- Table structure for table `calendario_academico`
--

CREATE TABLE `calendario_academico` (
  `id` int(11) NOT NULL,
  `nome_ficheiro` varchar(255) NOT NULL,
  `caminho` varchar(255) NOT NULL,
  `data_publicacao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `calendario_academico`
--

INSERT INTO `calendario_academico` (`id`, `nome_ficheiro`, `caminho`, `data_publicacao`) VALUES
(14, 'daily-schedule-portrait-graded-red.pdf', '1781867631_daily-schedule-portrait-graded-red.pdf', '2026-06-19 04:13:51');

-- --------------------------------------------------------

--
-- Table structure for table `exames`
--

CREATE TABLE `exames` (
  `id` int(11) NOT NULL,
  `dia_semana` varchar(20) NOT NULL,
  `data` date NOT NULL,
  `curso` varchar(100) NOT NULL,
  `ano` varchar(5) NOT NULL,
  `semestre` varchar(5) NOT NULL,
  `disciplina` varchar(100) NOT NULL,
  `turno` enum('Manhã','Tarde','Noite') NOT NULL,
  `sala` varchar(100) NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fim` time NOT NULL,
  `duracao` int(11) NOT NULL COMMENT 'Duração em minutos',
  `docente_id` int(11) DEFAULT NULL,
  `docente_nome` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exames`
--

INSERT INTO `exames` (`id`, `dia_semana`, `data`, `curso`, `ano`, `semestre`, `disciplina`, `turno`, `sala`, `hora_inicio`, `hora_fim`, `duracao`, `docente_id`, `docente_nome`, `created_at`) VALUES
(9, 'Segunda-feira', '2026-06-15', 'Contabilidade & Auditoria', '2º', 'I', 'Matematica', 'Noite', 'Martin Luther King', '18:49:00', '20:00:00', 71, NULL, 'Madona Kriss', '2026-06-13 16:49:43');

-- --------------------------------------------------------

--
-- Table structure for table `horarios`
--

CREATE TABLE `horarios` (
  `id` int(11) NOT NULL,
  `dia_semana` varchar(20) NOT NULL,
  `curso` varchar(100) NOT NULL,
  `ano` varchar(5) NOT NULL,
  `semestre` enum('I','II') NOT NULL,
  `disciplina` varchar(100) NOT NULL,
  `turno` enum('Manhã','Tarde','Noite') NOT NULL,
  `sala` varchar(100) NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fim` time NOT NULL,
  `criado_por` int(11) DEFAULT NULL,
  `docente_id` int(11) DEFAULT NULL,
  `docente_nome` varchar(100) DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `horarios`
--

INSERT INTO `horarios` (`id`, `dia_semana`, `curso`, `ano`, `semestre`, `disciplina`, `turno`, `sala`, `hora_inicio`, `hora_fim`, `criado_por`, `docente_id`, `docente_nome`, `criado_em`) VALUES
(36, 'Segunda-feira', 'Tecnologia de Informação', '1º', 'I', 'Métodos De Pesquisa', 'Manhã', 'Sala Magna 1', '07:30:00', '08:15:00', NULL, NULL, 'Sónia Pinto', '2026-06-18 13:27:44'),
(37, 'Segunda-feira', 'Tecnologia de Informação', '1º', 'I', 'Métodos De Pesquisa', 'Manhã', 'Sala Magna 1', '08:20:00', '09:05:00', NULL, NULL, 'Sónia Pinto', '2026-06-18 13:29:47'),
(38, 'Segunda-feira', 'Tecnologia de Informação', '1º', 'I', 'Inglês I', 'Manhã', 'Sala Magna 1', '09:10:00', '09:55:00', NULL, NULL, 'José Vicente', '2026-06-18 13:31:05'),
(39, 'Segunda-feira', 'Tecnologia de Informação', '1º', 'I', 'Inglês I', 'Manhã', 'Sala Magna 1', '10:00:00', '10:45:00', NULL, NULL, 'José Vicente', '2026-06-18 13:33:53'),
(40, 'Terça-feira', 'Tecnologia de Informação', '1º', 'I', 'Álgebra', 'Manhã', 'São Tomás de Aquino', '07:30:00', '08:15:00', NULL, NULL, 'Jorge Lapi', '2026-06-18 13:36:50'),
(41, 'Terça-feira', 'Tecnologia de Informação', '1º', 'I', 'Álgebra', 'Manhã', 'Cipriano Parite 2', '08:20:00', '09:05:00', NULL, NULL, 'Jorge Lapi', '2026-06-18 13:37:51'),
(42, 'Terça-feira', 'Tecnologia de Informação', '1º', 'I', 'Fundamentos De Tecnologias De Informação', 'Manhã', 'Sala de Informática', '09:10:00', '09:55:00', NULL, NULL, 'Pascoal Camorai', '2026-06-18 13:40:53'),
(43, 'Terça-feira', 'Tecnologia de Informação', '1º', 'I', 'Fundamentos De Tecnologias De Informação', 'Manhã', 'Sala de Informática', '10:00:00', '10:45:00', NULL, NULL, 'Pascoal Camorai', '2026-06-18 13:42:10'),
(44, 'Quinta-feira', 'Tecnologia de Informação', '3º', 'I', 'Maths', 'Noite', 'Laboratório de SIG', '17:00:00', '18:00:00', NULL, NULL, 'Demo', '2026-06-18 14:52:34'),
(46, 'Sexta-feira', 'Direito', '3º', 'I', 'Direito I', 'Tarde', 'Nkwame Nkrumah', '12:00:00', '13:00:00', NULL, NULL, 'Valerio', '2026-06-19 08:09:22'),
(47, 'Sexta-feira', 'Direito', '2º', 'I', 'Direito I', 'Tarde', 'São Tomás de Aquino', '13:12:00', '14:00:00', NULL, NULL, 'Paulo', '2026-06-19 11:12:35'),
(48, 'Sexta-feira', 'Tecnologia de Informação', '4º', 'I', 'Base De Dados', 'Noite', 'Sala de Informática', '17:00:00', '18:00:00', NULL, NULL, 'Chande', '2026-06-19 11:55:43');

-- --------------------------------------------------------

--
-- Table structure for table `reservas`
--

CREATE TABLE `reservas` (
  `id` int(11) NOT NULL,
  `docente_id` int(11) NOT NULL,
  `docente_nome` varchar(100) NOT NULL,
  `curso` varchar(150) NOT NULL,
  `disciplina` varchar(150) NOT NULL,
  `turno` varchar(50) NOT NULL,
  `sala` varchar(100) NOT NULL,
  `dia_semana` varchar(20) NOT NULL,
  `data` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fim` time NOT NULL,
  `finalidade` varchar(255) DEFAULT NULL,
  `estado` enum('pendente','aprovada','rejeitada') DEFAULT 'pendente',
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `salas`
--

CREATE TABLE `salas` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `estado` enum('livre','ocupada') NOT NULL DEFAULT 'livre'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `salas`
--

INSERT INTO `salas` (`id`, `nome`, `estado`) VALUES
(1, 'Nelson Mandela 1', 'livre'),
(2, 'Nelson Mandela 2', 'livre'),
(3, 'Nkwame Nkrumah', 'livre'),
(4, 'Martin Luther King', 'livre'),
(5, 'Santo Agostinho', 'livre'),
(6, 'Dom Jaime Gonsalves', 'livre'),
(7, 'Josefina Bakhita 1', 'livre'),
(8, 'Josefina Bakhita 2', 'livre'),
(9, 'Blase Pascal', 'livre'),
(10, 'Sala de Informatica', 'livre'),
(11, 'Laboratorio de SIG', 'livre'),
(12, 'Cipriano Parite 1', 'livre'),
(13, 'Cipriano Parite 2', 'livre'),
(14, 'Laboratorio de Linguas', 'livre'),
(15, 'Sao Tomas de Aquino', 'livre'),
(16, 'Roberto Busa', 'livre'),
(17, 'Rosario Policarpo Napica', 'livre'),
(18, 'Beato Newman', 'livre'),
(19, 'Francisco de Assis', 'livre'),
(20, 'Sao Francisco de Victoria', 'livre'),
(21, 'Max Plank', 'livre'),
(22, 'Sala Magna 1', 'livre'),
(23, 'Sala Magna 2', 'livre');

-- --------------------------------------------------------

--
-- Table structure for table `testes`
--

CREATE TABLE `testes` (
  `id` int(11) NOT NULL,
  `dia_semana` varchar(20) NOT NULL,
  `data` date NOT NULL,
  `curso` varchar(100) NOT NULL,
  `ano` varchar(5) NOT NULL,
  `semestre` varchar(5) NOT NULL,
  `disciplina` varchar(100) NOT NULL,
  `turno` enum('Manhã','Tarde','Noite') NOT NULL,
  `sala` varchar(100) NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fim` time NOT NULL,
  `duracao` int(11) NOT NULL COMMENT 'Duração em minutos',
  `docente_id` int(11) DEFAULT NULL,
  `docente_nome` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `oauth_provider` varchar(20) NOT NULL,
  `oauth_uid` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `role` enum('estudante','docente','admin') NOT NULL DEFAULT 'estudante',
  `picture` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `oauth_provider`, `oauth_uid`, `name`, `email`, `role`, `picture`, `created_at`, `last_login`) VALUES
(2, 'google', '116705155560157601791', 'Stefeen Eugénio', '706220195@ucm.ac.mz', 'admin', 'https://lh3.googleusercontent.com/a/ACg8ocIuOlAqFH8k3U2iJm_NuY8IBwdlANX57FNFGtW70cEeFrnYPQ=s96-c', '2025-12-26 10:28:23', '2026-06-19 08:03:42'),
(3, 'google', '105657407690481198778', 'Agostinho Marques Sanli', '706230095@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocJq34enPgfc-f_Z-l-uEexRl30z_6uqKbZ3M7ewB5CZacwBzQ=s96-c', '2026-02-18 10:23:02', NULL),
(4, 'google', '103358857804677040091', 'Arlindo Borges da Costa ROSARIO', '706220228@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocIXeX_GqEOMpaeHhtXbGE-KmUWQL-2BwDLtzlr7Th0_dE19-iE=s96-c', '2026-02-18 19:08:10', NULL),
(5, 'google', '106354556389707067558', 'Antonio Moreira', '706240272@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocKVQS3-Gj98nVCM7lGXgOghOgWsSGLgZIu0NldkFOnBkDDwWg=s96-c', '2026-02-19 13:46:00', '2026-06-18 07:59:29'),
(6, 'google', '110851709505211840873', 'Zinedine Assirane MINTADE', '706220219@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocJNahdDZbeyJyzLZT46eOK8oO21spmSDUhzUd-gDmzUEjGu6A=s96-c', '2026-02-22 16:25:52', '2026-02-26 18:27:16'),
(7, 'google', '115083013372392709844', 'Ramadane Andinane', '706250280@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocJ42Jfh5tDzRWTqw0fCznX5X9lqrPOzxPyS1s7e_aVQSrkkFg=s96-c', '2026-02-25 18:13:01', '2026-02-27 03:01:48'),
(8, 'google', '103587957290753726086', 'Joy Joaquim Ambone', '706220067@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocJMod4zrjlXnK1SfGoVoXgTlcwFrySYEUJxvUo0nI_Y_UN1Y7Y=s96-c', '2026-02-26 15:23:40', NULL),
(9, 'google', '111689297608250681042', 'Pascoal Bernardo Sualehe', '706230369@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocIfB-dJ6BXpIraqeCKbJ-yKtRVDwlIMC_e5YX1hDMAtlKDiMQ=s96-c', '2026-02-26 15:51:53', '2026-02-26 15:57:14'),
(10, 'google', '102689368875761638824', 'Chissa Vuluwa Daniel Viriato', '706250286@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocKbA58u1oboJGjHOMc3dbj6-m9V37FGZ5RLiVcF3JhSum--Ygo=s96-c', '2026-02-26 17:23:24', NULL),
(11, 'google', '100484371505073715648', 'Valerio Moniua MULICANE', '706220028@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocKjP27PZyja1EO41-BloeGCkvqJUwR31pcH9nRILHepN8uugA=s96-c', '2026-02-26 17:31:55', NULL),
(12, 'google', '106429143608237151304', 'Rito Quinamine', '706230439@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocLr3yIvkqqaK27SsspylQofhCEPUCnztXfccN1DJJxmJOPFIg=s96-c', '2026-02-27 16:20:32', NULL),
(13, 'google', '101954456865192355401', 'Cassiano TAVARES', '706220200@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocLm2j36fbbEEx8RyR24Wal9jtiQC_bAN7ql_cpVfqrR5PBr9w=s96-c', '2026-02-28 11:39:50', '2026-02-28 11:46:10'),
(14, 'google', '112201748775019475746', 'Helizandra Victor', '706230435@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocKPpTUctVM9kADQ5I3kpRbnKEm-3w2wqd-mYJarW4D2mVOing=s96-c', '2026-02-28 14:26:27', NULL),
(15, 'google', '101087868565577456926', 'Ana Albertina Benjamin Saide', 'asaide@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocIdsTPzgCoBDeZReSdPrGmnHSNtPJYFAcqEenp3nsCh1d74Mw=s96-c', '2026-03-02 08:20:16', '2026-06-17 15:20:33'),
(16, 'google', '102222770996241712273', 'Joao Paulo da Gama Lobo', '706240237@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocKolm2y1MKsPZ5JTqDXrDevM3Ir2K8mqsy9P2OuUfUJ2F2nJQ=s96-c', '2026-03-26 08:55:45', NULL),
(17, '', '', 'Herkey H', '', 'docente', NULL, '2026-06-13 09:13:43', NULL),
(18, 'google', '114459071699971953799', 'Tobias Alberto Paulo Nambane', '706230204@ucm.ac.mz', 'estudante', 'https://lh3.googleusercontent.com/a/ACg8ocKIqdW9yc3HuqxcLnyfl65_ZM7tvozUsHQSr5TSpKlix679lA=s96-c', '2026-06-18 08:34:53', '2026-06-18 09:41:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `calendario_academico`
--
ALTER TABLE `calendario_academico`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exames`
--
ALTER TABLE `exames`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sala_dia` (`sala`,`dia_semana`),
  ADD KEY `idx_curso_ano` (`curso`,`ano`,`semestre`),
  ADD KEY `idx_docente` (`docente_id`);

--
-- Indexes for table `horarios`
--
ALTER TABLE `horarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_docente` (`docente_id`);

--
-- Indexes for table `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salas`
--
ALTER TABLE `salas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nome` (`nome`);

--
-- Indexes for table `testes`
--
ALTER TABLE `testes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sala_dia` (`sala`,`dia_semana`),
  ADD KEY `idx_curso_ano` (`curso`,`ano`,`semestre`),
  ADD KEY `idx_docente` (`docente_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `email_2` (`email`),
  ADD KEY `role` (`role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `calendario_academico`
--
ALTER TABLE `calendario_academico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `exames`
--
ALTER TABLE `exames`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `horarios`
--
ALTER TABLE `horarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `salas`
--
ALTER TABLE `salas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `testes`
--
ALTER TABLE `testes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
