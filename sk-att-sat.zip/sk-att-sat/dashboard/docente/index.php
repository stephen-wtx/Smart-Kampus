<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user'])) {
    header('Location: ../../public/index.php');
    exit;
}

$user = $_SESSION['user'];


// Verifica se já existe reserva ativa
$check = $conn->prepare("
    SELECT id, estado
    FROM reservas
    WHERE docente_id = ?
      AND estado IN ('pendente', 'aprovada')
    LIMIT 1
");
$check->bind_param("i", $user['id']);
$check->execute();
$reservaAtiva = $check->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Docente - SMART KAMPUS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="/public/assets/imgs/smartkampus-logo.png">
    <link rel="stylesheet" href="/public/assets/css/docente/dashboard.css">
</head>
<style>
    /* =========================================================
   TOAST NOTIFICATIONS - MODERNO E ELEGANTE
   ========================================================= */

.toast-container {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
    display: flex;
    flex-direction: column;
    gap: 10px;
    max-width: 350px;
    width: 100%;
    pointer-events: none;
}

.toast {
    background: white;
    border-radius: 12px;
    padding: 1rem 1.25rem;
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    display: flex;
    align-items: flex-start;
    gap: 1rem;
    animation: toastSlideIn 0.3s ease forwards;
    pointer-events: auto;
    border-left: 4px solid transparent;
    margin-bottom: 0.5rem;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
}

@keyframes toastSlideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes toastSlideOut {
    from {
        transform: translateX(0);
        opacity: 1;
    }
    to {
        transform: translateX(100%);
        opacity: 0;
    }
}

.toast.fade-out {
    animation: toastSlideOut 0.3s ease forwards;
}

.toast-success {
    background: #f0fdf4;
    border-left-color: #10b981;
    border: 1px solid #d1fae5;
}

.toast-success .toast-icon {
    background: #10b981;
    color: white;
}

.toast-error {
    background: #fef2f2;
    border-left-color: #ef4444;
    border: 1px solid #fee2e2;
}

.toast-error .toast-icon {
    background: #ef4444;
    color: white;
}

.toast-warning {
    background: #fffbeb;
    border-left-color: #f59e0b;
    border: 1px solid #fef3c7;
}

.toast-warning .toast-icon {
    background: #f59e0b;
    color: white;
}

.toast-info {
    background: #eff6ff;
    border-left-color: #3b82f6;
    border: 1px solid #dbeafe;
}

.toast-info .toast-icon {
    background: #3b82f6;
    color: white;
}

.toast-icon {
    width: 32px;
    height: 32px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    flex-shrink: 0;
}

.toast-content {
    flex: 1;
}

.toast-title {
    font-weight: 600;
    font-size: 0.95rem;
    color: #1e293b;
    margin-bottom: 0.25rem;
}

.toast-message {
    font-size: 0.85rem;
    color: #475569;
    line-height: 1.4;
}

.toast-close {
    background: transparent;
    border: none;
    color: #94a3b8;
    cursor: pointer;
    font-size: 1rem;
    padding: 0.25rem;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 6px;
    transition: all 0.2s ease;
    flex-shrink: 0;
}

.toast-close:hover {
    background: rgba(0, 0, 0, 0.05);
    color: #64748b;
}

/* Progress bar */
.toast-progress {
    position: absolute;
    bottom: 0;
    left: 0;
    height: 3px;
    background: rgba(255, 255, 255, 0.5);
    border-radius: 0 0 0 12px;
    animation: progress 5s linear forwards;
}

@keyframes progress {
    from { width: 100%; }
    to { width: 0%; }
}

.toast-success .toast-progress {
    background: #10b981;
}

.toast-error .toast-progress {
    background: #ef4444;
}

.toast-warning .toast-progress {
    background: #f59e0b;
}

.toast-info .toast-progress {
    background: #3b82f6;
}

/* Responsividade */
@media (max-width: 480px) {
    .toast-container {
        top: 10px;
        right: 10px;
        left: 10px;
        max-width: none;
    }
    
    .toast {
        padding: 0.875rem 1rem;
    }
}
</style>
<body>

<!-- Header -->
<header class="header">
    <div class="header-content">
        <div class="logo-container">
            <img src="../../public/assets/imgs/smartkampus-logo.png" alt="Logo" class="logo-img">
            <span class="logo-text">SMART KAMPUS</span>
        </div>
        
        <div class="nav-links">
            <a href="../dashboard.php" class="nav-button">
                <i class="fas fa-home"></i>
                <span>Painel Principal</span>
            </a>
            <a href="../../public/logout.php" class="nav-button logout">
                <i class="fas fa-sign-out-alt"></i>
                <span>Sair</span>
            </a>
        </div>
    </div>
</header>

<!-- Conteúdo principal -->
<main class="container">

    <!-- Welcome card -->
    <div class="welcome-card">
        <?php if (!empty($user['picture'])): ?>
            <div class="user-avatar">
                <img src="<?= htmlspecialchars($user['picture']) ?>" alt="Foto do docente">
            </div>
        <?php else: ?>
            <div class="avatar-placeholder">
                <i class="fas fa-user"></i>
            </div>
        <?php endif; ?>
        
        <div class="welcome-text">
            <h1>Painel do Docente</h1>
            <p>Bem-vindo, <strong><?= htmlspecialchars($user['name']) ?></strong></p>
            <p>Gerencie suas reservas de salas de forma rápida e eficiente.</p>
        </div>
    </div>

    <!-- Cards de ação -->
    <div class="actions-grid">
        <button class="action-button solicitar" onclick="abrirModal('modalSolicitar')">
            <div class="button-icon solicitar">
                <i class="fas fa-calendar-plus"></i>
            </div>
            <div>
                <strong>Solicitar Reserva</strong>
                <p>Solicite uma nova reserva de sala</p>
            </div>
        </button>
        
        <button class="action-button minhas" onclick="abrirModal('modalMinhas')">
            <div class="button-icon minhas">
                <i class="fas fa-list-alt"></i>
            </div>
            <div>
                <strong>Minhas Reservas</strong>
                <p>Consulte e gerencie suas reservas</p>
            </div>
        </button>
    </div>

    <!-- ================= MODAL SOLICITAR RESERVA ================= -->
    <div id="modalSolicitar" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">
                    <i class="fas fa-calendar-plus" style="color: #3b43ce;"></i>
                    Solicitar Reserva
                </h2>
                <button class="close-modal" onclick="fecharModal('modalSolicitar')">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <?php if ($reservaAtiva): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <div>
                        <strong>Reserva ativa encontrada</strong>
                        <p>Você já possui uma reserva <span class="status-badge status-<?= $reservaAtiva['estado'] ?>"><?= strtoupper($reservaAtiva['estado']) ?></span>.<br>
                        Para cancelar, acesse <strong>Minhas Reservas</strong>.</p>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button onclick="abrirModal('modalMinhas')" class="btn btn-primary">
                        <i class="fas fa-list-alt"></i>
                        Ver Minhas Reservas
                    </button>
                    <button onclick="fecharModal('modalSolicitar')" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        Fechar
                    </button>
                </div>
            <?php else: ?>
                <div class="form-container">
                    <form method="POST" action="solicitar_reserva.php">
                        <table class="form-table">
                            <tr>
                                <td>Curso</td>
                                <td>
                                    <select name="curso" class="form-select" required>
                                        <option value="">-- Selecionar Curso --</option>
                                        <option value="Administração Pública">Administração Pública</option>
                                        <option value="Contabilidade & Auditoria">Contabilidade & Auditoria</option>
                                        <option value="Direito">Direito</option>
                                        <option value="Economia e Gestão">Economia e Gestão</option>
                                        <option value="Gestão de Recursos Humanos">Gestão de Recursos Humanos</option>
                                        <option value="Meio Ambiente">Meio Ambiente</option>
                                        <option value="Tecnologia de Informação">Tecnologia de Informação</option>
                                    </select>
                                </td>
                            </tr>

                            <tr>
                                <td>Disciplina</td>
                                <td>
                                    <input type="text" name="disciplina" class="form-input" placeholder="Nome da disciplina" required>
                                </td>
                            </tr>

                            <tr>
                                <td>Turno</td>
                                <td>
                                    <select name="turno" class="form-select" required>
                                        <option value="Manhã">Manhã</option>
                                        <option value="Tarde">Tarde</option>
                                        <option value="Noite">Noite</option>
                                    </select>
                                </td>
                            </tr>

                            <tr>
                                <td>Sala</td>
                                <td>
                                    <select name="sala" class="form-select" required>
                                        <?php
                                        $salas = $conn->query("
                                            SELECT nome 
                                            FROM salas 
                                            WHERE estado = 'livre'
                                            ORDER BY nome
                                        ");
                                        while ($s = $salas->fetch_assoc()):
                                        ?>
                                            <option value="<?= htmlspecialchars($s['nome']) ?>">
                                                <?= htmlspecialchars($s['nome']) ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </td>
                            </tr>

                            <tr>
                                <td>Dia da Semana</td>
                                <td>
                                    <select name="dia_semana" class="form-select" required>
                                        <option value="Segunda-feira">Segunda-feira</option>
                                        <option value="Terça-feira">Terça-feira</option>
                                        <option value="Quarta-feira">Quarta-feira</option>
                                        <option value="Quinta-feira">Quinta-feira</option>
                                        <option value="Sexta-feira">Sexta-feira</option>
                                        <option value="Sábado">Sábado</option>
                                    </select>
                                </td>
                            </tr>

                            <tr>
                                <td>Data</td>
                                <td><input type="date" name="data" class="form-input" required></td>
                            </tr>

                            <tr>
                                <td>Hora início</td>
                                <td><input type="time" name="hora_inicio" class="form-input" required></td>
                            </tr>

                            <tr>
                                <td>Hora fim</td>
                                <td><input type="time" name="hora_fim" class="form-input" required></td>
                            </tr>

                            <tr>
                                <td>Finalidade (opcional)</td>
                                <td><input type="text" name="finalidade" class="form-input" placeholder="Ex: Aula prática, Reunião..."></td>
                            </tr>
                        </table>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-paper-plane"></i>
                                Solicitar Reserva
                            </button>
                            <button type="button" onclick="fecharModal('modalSolicitar')" class="btn btn-secondary">
                                <i class="fas fa-times"></i>
                                Cancelar
                            </button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ================= MODAL MINHAS RESERVAS ================= -->
    <div id="modalMinhas" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">
                    <i class="fas fa-list-alt" style="color: #10b981;"></i>
                    Minhas Reservas
                </h2>
                <button class="close-modal" onclick="fecharModal('modalMinhas')">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <?php
            $list = $conn->prepare("
                SELECT id, curso, disciplina, turno, sala, dia_semana, data, hora_inicio, hora_fim, finalidade, estado
                FROM reservas
                WHERE docente_id = ?
                ORDER BY criado_em DESC
            ");

            $list->bind_param("i", $user['id']);
            $list->execute();
            $result = $list->get_result();
            ?>

            <?php if ($result->num_rows === 0): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="far fa-calendar-times"></i>
                    </div>
                    <h3>Nenhuma reserva encontrada</h3>
                    <p>Você ainda não possui reservas cadastradas.</p>
                    <button onclick="abrirModal('modalSolicitar'); fecharModal('modalMinhas')" class="btn btn-primary" style="margin-top: 1rem;">
                        <i class="fas fa-calendar-plus"></i>
                        Solicitar Primeira Reserva
                    </button>
                </div>
            <?php else: ?>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Curso</th>
                                <th>Disciplina</th>
                                <th>Sala</th>
                                <th>Turno</th>
                                <th>Dia</th>
                                <th>Data</th>
                                <th>Hora</th>
                                <th>Finalidade</th>
                                <th>Estado</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($r = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($r['curso']) ?></td>
                                    <td><?= htmlspecialchars($r['disciplina']) ?></td>
                                    <td><strong><?= htmlspecialchars($r['sala']) ?></strong></td>
                                    <td><?= htmlspecialchars($r['turno']) ?></td>
                                    <td><?= htmlspecialchars($r['dia_semana']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($r['data'])) ?></td>
                                    <td><?= substr($r['hora_inicio'],0,5) ?> - <?= substr($r['hora_fim'],0,5) ?></td>
                                    <td><?= $r['finalidade'] ?: '-' ?></td>
                                    <td>
                                        <span class="status-badge status-<?= $r['estado'] ?>">
                                            <?= strtoupper($r['estado']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <?php if ($r['estado'] === 'aprovada' || $r['estado'] === 'pendente'): ?>
                                                <button type="button" 
                                                        class="btn btn-warning btn-small"
                                                        onclick="abrirModalCancelar(<?= $r['id'] ?>)">
                                                    <i class="fas fa-ban"></i>
                                                    Cancelar
                                                </button>
                                            <?php elseif ($r['estado'] === 'rejeitada'): ?>
                                                <form method="POST" action="excluir_reserva.php" style="display:inline;">
                                                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                                                    <button type="submit" class="btn btn-error btn-small"
                                                            onclick="return confirm('Deseja excluir esta reserva rejeitada?')">
                                                        <i class="fas fa-trash"></i>
                                                        Excluir
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <!-- MODAL CONFIRMAR CANCELAMENTO -->
                <div id="modalCancelar" class="modal">
                    <div class="modal-content" style="max-width: 500px;">
                        <div class="modal-header">
                            <h2 class="modal-title">
                                <i class="fas fa-exclamation-triangle" style="color:#f59e0b;"></i>
                                Confirmar Cancelamento
                            </h2>
                            <button class="close-modal" onclick="fecharModal('modalCancelar')">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>

                        <p style="margin: 1.5rem 0; color:#475569;">
                            Tem certeza que deseja cancelar esta reserva?
                            Esta ação não pode ser desfeita.
                        </p>

                        <form method="POST" action="cancelar_reserva.php">
                            <input type="hidden" name="id" id="reservaIdCancelar">

                            <div class="form-actions">
                                <button type="submit" class="btn btn-warning">
                                    <i class="fas fa-ban"></i>
                                    Sim, Cancelar
                                </button>

                                <button type="button" 
                                        class="btn btn-secondary"
                                        onclick="fecharModal('modalCancelar')">
                                    Voltar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="form-actions">
                    <button onclick="fecharModal('modalMinhas')" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        Fechar
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<!-- Footer -->
<footer class="footer">
    <p>© 2026 SMART KAMPUS • Universidade Católica de Moçambique</p>
</footer>

<script src="/public/assets/js/docente/script.js"></script>

<!-- Toast Notifications -->
<div class="toast-container" id="toastContainer"></div>

<script>
// Sistema de Toast Notifications
function showToast(message, type = 'success', duration = 5000) {
    const container = document.getElementById('toastContainer');
    
    // Criar elemento do toast
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    // Definir ícone baseado no tipo
    let icon = 'check-circle';
    let title = 'Sucesso';
    
    switch(type) {
        case 'error':
            icon = 'exclamation-circle';
            title = 'Erro';
            break;
        case 'warning':
            icon = 'exclamation-triangle';
            title = 'Aviso';
            break;
        case 'info':
            icon = 'info-circle';
            title = 'Informação';
            break;
        default:
            icon = 'check-circle';
            title = 'Sucesso';
    }
    
    // HTML do toast
    toast.innerHTML = `
        <div class="toast-icon">
            <i class="fas fa-${icon}"></i>
        </div>
        <div class="toast-content">
            <div class="toast-title">${title}</div>
            <div class="toast-message">${message}</div>
        </div>
        <button class="toast-close" onclick="this.closest('.toast').remove()">
            <i class="fas fa-times"></i>
        </button>
        <div class="toast-progress"></div>
    `;
    
    // Adicionar ao container
    container.appendChild(toast);
    
    // Remover após duration
    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 300);
    }, duration);
    
    // Fechar ao clicar no botão
    const closeBtn = toast.querySelector('.toast-close');
    closeBtn.addEventListener('click', () => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 300);
    });
}

// Mostrar mensagens da sessão
document.addEventListener('DOMContentLoaded', function() {
    <?php if (isset($_SESSION['success_message'])): ?>
        showToast('<?= htmlspecialchars($_SESSION['success_message']) ?>', 'success');
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error_message'])): ?>
        showToast('<?= htmlspecialchars($_SESSION['error_message']) ?>', 'error');
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['warning_message'])): ?>
        showToast('<?= htmlspecialchars($_SESSION['warning_message']) ?>', 'warning');
        <?php unset($_SESSION['warning_message']); ?>
    <?php endif; ?>
});
</script>

</body>
</html>