<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require_once __DIR__ . "/../../../../config/database.php";

if (!isset($_SESSION['user'])) {
    header('Location: ../../../../public/index.php');
    exit;
}
$user = $_SESSION['user'];

$sql = "SELECT * FROM exames ORDER BY data ASC, hora_inicio ASC";
$resultado = $conn->query($sql);
$total = $resultado ? $resultado->num_rows : 0;
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Listar Exames - SMART KAMPUS</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap');
:root {
    --primary: #8b5cf6;
    --primary-hover: #7c3aed;
    --primary-soft: #f3e8ff;
    --primary-glow: rgba(139, 92, 246, 0.15);
    --logo-color: #3b43ce;
}
* { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif; }
body { background-color: #f8fafc; color: #334155; line-height: 1.6; min-height: 100vh; }
.header { background: white; padding: 0 2rem; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05); position: sticky; top: 0; z-index: 100; border-bottom: 1px solid #f1f5f9; }
.header-content { display: flex; justify-content: space-between; align-items: center; max-width: 1400px; margin: 0 auto; height: 70px; }
.logo-container { display: flex; align-items: center; gap: 12px; }
.logo-img { height: 45px; width: auto; transition: transform 0.2s ease; }
.logo-img:hover { transform: scale(1.05); }
.logo-text { font-family: 'Bebas Neue', sans-serif; font-size: 1.9rem; font-weight: 400; color: var(--logo-color); letter-spacing: 0.5px; line-height: 1; }
.nav-links { display: flex; gap: 1.5rem; align-items: center; }
.nav-button { display: flex; align-items: center; gap: 8px; background: transparent; border: none; color: #64748b; font-size: 0.95rem; font-weight: 500; padding: 0.5rem 1rem; border-radius: 8px; cursor: pointer; transition: all 0.2s ease; text-decoration: none; }
.nav-button:hover { background-color: var(--primary-soft); color: var(--primary-hover); }
.nav-button.logout { color: #ef4444; }
.nav-button.logout:hover { background-color: #fee2e2; }
.container { max-width: 1400px; margin: 2rem auto; padding: 0 2rem; width: 100%; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem; }
.page-title { font-size: 1.75rem; font-weight: 700; color: #0f172a; display: flex; align-items: center; gap: 0.75rem; }
.page-title i { color: var(--primary); }
.counter-badge { background: var(--primary); color: white; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.875rem; font-weight: 500; }
.breadcrumb { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1.5rem; font-size: 0.9rem; color: #64748b; }
.breadcrumb a { color: var(--primary); text-decoration: none; transition: color 0.2s ease; }
.breadcrumb a:hover { color: var(--primary-hover); text-decoration: underline; }
.breadcrumb .separator { color: #cbd5e1; }
.alert { padding: 1rem 1.25rem; border-radius: 8px; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.75rem; animation: slideDown 0.3s ease; }
@keyframes slideDown { from { transform: translateY(-10px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
.alert-success { background: #d1fae5; border: 1px solid #a7f3d0; color: #065f46; }
.alert-error { background: #fee2e2; border: 1px solid #fecaca; color: #991b1b; }
.alert-info { background: #faf5ff; border: 1px solid #f3e8ff; color: #6b21a8; }
.table-container {
    background: white; border-radius: 12px; padding: 1.75rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
    border: 1px solid #e2e8f0; margin-bottom: 2rem; overflow-x: auto; -webkit-overflow-scrolling: touch;
}
.table-container::-webkit-scrollbar { height: 8px; }
.table-container::-webkit-scrollbar-track { background: #f1f5f9; border-radius: 4px; }
.table-container::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
.table-container::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
.data-table { width: 100%; border-collapse: separate; border-spacing: 0; min-width: 1100px; }
.data-table thead { background: #f8fafc; }
.data-table th {
    padding: 1.5rem 1.25rem; text-align: left; font-weight: 600; color: #475569;
    border-bottom: 2px solid #e2e8f0; font-size: 0.85rem; text-transform: uppercase;
    letter-spacing: 0.75px; white-space: nowrap;
}
.data-table td {
    padding: 1.5rem 1.25rem; border-bottom: 1px solid #f1f5f9; color: #334155;
    vertical-align: middle; transition: background 0.2s ease; white-space: nowrap;
}
.data-table tr:last-child td { border-bottom: none; }
.data-table tbody tr:hover { background-color: #faf5ff; }
.empty-state { text-align: center; padding: 3rem 1rem; color: #64748b; }
.empty-icon { font-size: 3rem; color: #cbd5e1; margin-bottom: 1rem; }
.data-badge { display: inline-block; padding: 0.35rem 0.85rem; border-radius: 20px; font-size: 0.75rem; font-weight: 600; background: #f1f5f9; color: #475569; }
.badge-curso { background: #faf5ff; color: #6b21a8; }
.badge-disciplina { background: #f3e8ff; color: #7e22ce; }
.badge-turno { background: #fef3c7; color: #92400e; }
.badge-sala { background: #dcfce7; color: #166534; }
.badge-dia { background: #f3e8ff; color: #7e22ce; }
.action-buttons { display: flex; gap: 0.75rem; flex-wrap: nowrap; align-items: center; }
.btn { display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.5rem 1rem; border-radius: 6px; font-weight: 500; font-size: 0.85rem; cursor: pointer; transition: all 0.2s ease; border: none; text-decoration: none; }
.btn-editar { background: #10b981; color: white; }
.btn-editar:hover { background: #059669; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(16, 185, 129, 0.2); }
.btn-excluir { background: #ef4444; color: white; }
.btn-excluir:hover { background: #dc2626; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(239, 68, 68, 0.2); }
.btn-primary { background: var(--primary); color: white; }
.btn-primary:hover { background: var(--primary-hover); transform: translateY(-2px); box-shadow: 0 4px 12px rgba(139, 92, 246, 0.2); }
.btn-secondary { background: #f1f5f9; color: #334155; border: 1px solid #e2e8f0; }
.btn-secondary:hover { background: #e2e8f0; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08); }
.page-actions { display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap; }
.footer { background: #0f172a; color: #cbd5e1; text-align: center; padding: 1.5rem; margin-top: 3rem; font-size: 0.9rem; }
.footer-logo { font-family: 'Bebas Neue', sans-serif; font-size: 1.3rem; letter-spacing: 0.5px; color: var(--logo-color); }
.modal-overlay {
    position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); backdrop-filter: blur(4px);
    display: none; align-items: center; justify-content: center; z-index: 1000;
    opacity: 0; transition: opacity 0.2s ease;
}
.modal-overlay.active { display: flex; opacity: 1; }
.modal-box {
    background: white; width: 100%; max-width: 420px; border-radius: 12px; padding: 2rem;
    box-shadow: 0 20px 40px rgba(0,0,0,0.15); transform: scale(0.95);
    transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.modal-overlay.active .modal-box { transform: scale(1); }
.modal-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem; }
.modal-icon {
    width: 48px; height: 48px; background: #fee2e2; color: #ef4444;
    border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.25rem;
}
.modal-header h3 { color: #0f172a; font-size: 1.1rem; font-weight: 600; }
.modal-body { color: #475569; font-size: 0.95rem; line-height: 1.5; margin-bottom: 1.5rem; }
.modal-warning { font-size: 0.85rem; color: #991b1b; margin-top: 0.5rem; display: flex; align-items: center; gap: 0.4rem; }
.modal-actions { display: flex; justify-content: flex-end; gap: 0.75rem; }
@media (max-width: 768px) {
    .header-content { flex-direction: column; height: auto; padding: 1rem 0; }
    .logo-container { flex-direction: column; align-items: center; gap: 6px; text-align: center; }
    .nav-links { margin-top: 1rem; flex-wrap: wrap; justify-content: center; }
    .container { padding: 0 1rem; }
    .page-header { flex-direction: column; align-items: flex-start; }
    .table-container { padding: 1rem; }
    .page-actions { flex-direction: column; }
    .btn { width: 100%; justify-content: center; }
}
</style>
</head>
<body>
<header class="header">
    <div class="header-content">
        <div class="logo-container">
            <img src="../../../../public/assets/imgs/smartkampus-logo.png" alt="Logo" class="logo-img">
            <span class="logo-text">SMARTKAMPUS</span>
        </div>
        <div class="nav-links">
            <a href="../../../dashboard.php" class="nav-button"><i class="fas fa-dashboard"></i><span>Painel Principal</span></a>
            <a href="../../../../public/logout.php" class="nav-button logout"><i class="fas fa-sign-out-alt"></i><span>Sair</span></a>
        </div>
    </div>
</header>
<main class="container">
    <div class="breadcrumb">
        <a href="../../index.php">Início</a><span class="separator">/</span><span>Listar Exames</span>
    </div>
    <div class="page-header">
        <h1 class="page-title"><i class="fas fa-file-contract"></i> Exames Agendados</h1>
        <div class="counter-badge"><i class="fas fa-clock"></i> <?= $total ?> exame(s)</div>
    </div>
    <div class="page-actions">
        <a href="criar_exame.php" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Agendar Novo Exame</a>
        <a href="../../index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Voltar ao meu painel</a>
    </div>
    <?php if (!empty($_SESSION['sucesso'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($_SESSION['sucesso']); ?></div>
    <?php unset($_SESSION['sucesso']); ?>
    <?php endif; ?>
    <?php if (!empty($_SESSION['erro'])): ?>
    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($_SESSION['erro']); ?></div>
    <?php unset($_SESSION['erro']); ?>
    <?php endif; ?>
    <?php if ($total === 0): ?>
    <div class="empty-state">
        <div class="empty-icon"><i class="far fa-calendar-times"></i></div>
        <h3>Nenhum exame agendado</h3>
        <p>Não há exames disponíveis no calendário no momento.</p>
        <a href="criar_exame.php" class="btn btn-primary" style="margin-top: 1rem;"><i class="fas fa-plus-circle"></i> Criar Primeiro Exame</a>
    </div>
    <?php else: ?>
    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Data / Dia</th>
                    <th>Curso</th>
                    <th>Ano</th>
                    <th>Semestre</th>
                    <th>Disciplina</th>
                    <th>Turno</th>
                    <th>Sala</th>
                    <th>Docente</th>
                    <th>Horário</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($linha = $resultado->fetch_assoc()): ?>
                <tr>
                    <td>
                        <span class="data-badge badge-dia">
                            <i class="fas fa-calendar-day"></i>
                            <?= date('d/m/Y', strtotime($linha['data'])); ?> (<?= htmlspecialchars($linha['dia_semana']); ?>)
                        </span>
                    </td>
                    <td><span class="data-badge badge-curso"><?= htmlspecialchars($linha['curso']); ?></span></td>
                    <td><span class="data-badge"><?= htmlspecialchars($linha['ano']); ?></span></td>
                    <td><span class="data-badge"><?= htmlspecialchars($linha['semestre']); ?></span></td>
                    <td><span class="data-badge badge-disciplina"><i class="fas fa-book"></i> <?= htmlspecialchars($linha['disciplina']); ?></span></td>
                    <td><span class="data-badge badge-turno"><i class="fas fa-sun"></i> <?= htmlspecialchars($linha['turno']); ?></span></td>
                    <td><span class="data-badge badge-sala"><i class="fas fa-door-open"></i> <?= htmlspecialchars($linha['sala']); ?></span></td>
                    <td>
                        <span class="data-badge" style="background: #fce7f3; color: #831843;">
                            <i class="fas fa-user-tie"></i>
                            <?= !empty($linha['docente_nome']) ? htmlspecialchars($linha['docente_nome']) : 'Não atribuído'; ?>
                        </span>
                    </td>
                    <td>
                        <span class="data-badge" style="background: #f3e8ff; color: #7e22ce;">
                            <i class="fas fa-clock"></i>
                            <?= htmlspecialchars(date('H:i', strtotime($linha['hora_inicio']))); ?> - <?= htmlspecialchars(date('H:i', strtotime($linha['hora_fim']))); ?>
                        </span>
                    </td>
                    <td>
                        <div class="action-buttons">
                            <a href="editar_exame.php?id=<?= $linha['id']; ?>" class="btn btn-editar"><i class="fas fa-edit"></i> Editar</a>
                            <a href="javascript:void(0)" class="btn btn-excluir" onclick="abrirModalExcluir(<?= $linha['id']; ?>)"><i class="fas fa-trash"></i> Excluir</a>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i> Exibindo <strong><?= $total ?></strong> exame(s) registado(s) no sistema.
    </div>
    <?php endif; ?>
</main>
<div id="modalExcluir" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <div class="modal-icon"><i class="fas fa-exclamation-triangle"></i></div>
            <h3>Confirmar Exclusão</h3>
        </div>
        <div class="modal-body">
            <p>Tem certeza absoluta que deseja excluir este exame do calendário?</p>
            <p class="modal-warning"><i class="fas fa-info-circle"></i> Esta ação não poderá ser desfeita.</p>
        </div>
        <div class="modal-actions">
            <button type="button" class="btn btn-secondary" onclick="fecharModal()">Cancelar</button>
            <a href="#" id="confirmarExclusao" class="btn btn-excluir">Sim, Excluir</a>
        </div>
    </div>
</div>
<footer class="footer">
    <p>© 2026 <span class="footer-logo">SMARTKAMPUS</span> • Universidade Católica de Moçambique</p>
</footer>
<script>
const modal = document.getElementById("modalExcluir");
const confirmarBtn = document.getElementById("confirmarExclusao");
function abrirModalExcluir(id) {
    confirmarBtn.href = "excluir_exame.php?id=" + id;
    modal.style.display = "flex";
    setTimeout(() => { modal.classList.add("active"); }, 10);
}
function fecharModal() {
    modal.classList.remove("active");
    setTimeout(() => { modal.style.display = "none"; }, 200);
}
window.onclick = function(event) {
    if (event.target === modal) { fecharModal(); }
}
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && modal.classList.contains('active')) { fecharModal(); }
});
</script>
</body>
</html>