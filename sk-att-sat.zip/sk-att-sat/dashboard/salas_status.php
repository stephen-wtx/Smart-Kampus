<?php
require_once __DIR__ . '/../config/database.php';

// Fuso horário de Moçambique
date_default_timezone_set('Africa/Maputo');

$hoje = date('Y-m-d');
$horaAtual = date('H:i:s');

// Dia da semana em português
$dias = [
    'Sunday'    => 'Domingo',
    'Monday'    => 'Segunda-feira',
    'Tuesday'   => 'Terça-feira',
    'Wednesday' => 'Quarta-feira',
    'Thursday'  => 'Quinta-feira',
    'Friday'    => 'Sexta-feira',
    'Saturday'  => 'Sábado',
];
$diaSemana = $dias[date('l')];

// Receber tipo de consulta (livres ou ocupadas)
$tipo = $_GET['tipo'] ?? 'livres';

// Função para normalizar nomes de salas
function normalizarNome($nome) {
    // Remover acentos
    $acentos = array(
        'á' => 'a', 'à' => 'a', 'ã' => 'a', 'â' => 'a',
        'é' => 'e', 'ê' => 'e',
        'í' => 'i',
        'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
        'ú' => 'u',
        'ç' => 'c',
        'Á' => 'A', 'À' => 'A', 'Ã' => 'A', 'Â' => 'A',
        'É' => 'E', 'Ê' => 'E',
        'Í' => 'I',
        'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O',
        'Ú' => 'U',
        'Ç' => 'C'
    );
    
    $nome = strtr($nome, $acentos);
    $nome = strtolower(trim($nome));
    $nome = preg_replace('/\s+/', ' ', $nome); // Remove espaços extras
    
    return $nome;
}

// ==========================
// 1. Buscar TODAS as salas da tabela salas
// ==========================
$mapaSalas = []; // nome normalizado => nome original

$resSalas = $conn->query("SELECT nome FROM salas ORDER BY nome");

while ($s = $resSalas->fetch_assoc()) {
    $nomeOriginal = $s['nome'];
    $nomeNorm = normalizarNome($nomeOriginal);
    $mapaSalas[$nomeNorm] = $nomeOriginal;
}

// ==========================
// 2. Buscar APENAS as salas ocupadas NO MOMENTO
// ==========================
$sqlOcupadas = "
    SELECT DISTINCT sala FROM (
        SELECT sala
        FROM horarios
        WHERE dia_semana = ?
          AND hora_inicio <= ?
          AND hora_fim > ?
        UNION
        SELECT sala
        FROM testes
        WHERE data = ?
          AND hora_inicio <= ?
          AND hora_fim > ?
        UNION
        SELECT sala
        FROM exames
        WHERE data = ?
          AND hora_inicio <= ?
          AND hora_fim > ?
    ) t
    WHERE sala IS NOT NULL AND sala != ''
";

$stmt = $conn->prepare($sqlOcupadas);
$stmt->bind_param(
    "sssssssss",
    $diaSemana, $horaAtual, $horaAtual,
    $hoje, $horaAtual, $horaAtual,
    $hoje, $horaAtual, $horaAtual
);
$stmt->execute();
$result = $stmt->get_result();

$salasOcupadas = [];
while ($r = $result->fetch_assoc()) {
    $salaOcupada = $r['sala'];
    $salaNorm = normalizarNome($salaOcupada);
    
    // Procurar a sala no mapa
    if (isset($mapaSalas[$salaNorm])) {
        $salasOcupadas[$salaNorm] = $mapaSalas[$salaNorm];
    }
}

// ==========================
// 3. Separar livres e ocupadas
// ==========================
$ocupadasFinal = array_values($salasOcupadas);
$livresFinal = [];

foreach ($mapaSalas as $norm => $original) {
    if (!isset($salasOcupadas[$norm])) {
        $livresFinal[] = $original;
    }
}

// ==========================
// 4. Mostrar apenas conforme o tipo solicitado
// ==========================
if ($tipo === 'livres') {
    $totalLivres = count($livresFinal);
    echo "<p><strong>Salas Livres:</strong> " . $totalLivres . "</p>";
    
    if ($totalLivres > 0) {
        echo "<ul>";
        sort($livresFinal);
        foreach ($livresFinal as $sala) {
            echo "<li style='color:green'>🟢 " . htmlspecialchars($sala) . "</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>Não existem salas livres neste momento.</p>";
    }
    
} else { // ocupadas
    $totalOcupadas = count($ocupadasFinal);
    echo "<p><strong>Salas Ocupadas:</strong> " . $totalOcupadas . "</p>";
    
    if ($totalOcupadas > 0) {
        echo "<ul>";
        sort($ocupadasFinal);
        foreach ($ocupadasFinal as $sala) {
            echo "<li style='color:red'>🔴 " . htmlspecialchars($sala) . "</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>Não existem salas ocupadas neste momento.</p>";
    }
}
?>